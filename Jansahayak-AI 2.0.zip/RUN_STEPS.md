# Quick run steps for Windows

Follow the detailed [README.md](README.md). Short version (PowerShell, from the extracted project folder):

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt -r requirements-dashboard.txt
```

Create a PostgreSQL database named `jansahayak_db`, then create `.env` in this folder:

```dotenv
DB_HOST=localhost
DB_PORT=5432
DB_NAME=jansahayak_db
DB_USER=postgres
DB_PASSWORD=YOUR_POSTGRES_PASSWORD
```

Load the scheme data (first import truncates/reloads the four scheme tables):

```powershell
python database/import_schemes.py
```

Start the dashboard:

```powershell
python run_dashboard.py
```

Open http://127.0.0.1:8001. Keep PostgreSQL running while using the app.


## Upload documents and find schemes

1. Start PostgreSQL and the dashboard as above.
2. Open `http://127.0.0.1:8001/`.
3. Choose **Tools → Upload documents**.
4. Select a supported document (synthetic sample files are in `tests/sample_documents/`), confirm the consent checkbox, and click **Extract details**.
5. Review the detected fields and sources, then click **Use these details & find schemes**.
6. The profile is saved in this browser and the existing scheme matcher returns recommendations. This does not require DigiLocker.

For scanned PDFs or photos, install Tesseract OCR and configure `TESSERACT_CMD` if it is not on PATH.
