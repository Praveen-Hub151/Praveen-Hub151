"""main.py: the whole JanSahayak pipeline as a small chat in the terminal.

    1. user's message (Hindi / Hinglish / English)
    2. agent/rule_based_extractor.py   -> CitizenProfile
    3. engine/scheme_matcher.py        -> eligible / maybe / not eligible
    4. agent/followup.py               -> at most 3 short questions, re-match after each
    5. engine/profile_store.py         -> saves profile + answers (PostgreSQL, or a JSON file)
    6. services/scheme_matcher.py      -> benefits, documents and apply link of the top schemes
    +  documents/                      -> optional: read Aadhaar / income certificate / passbook,
                                          fill the profile from them and tick off documents

Run from the JanSahayak-AI folder:
    python main.py                                       # chat: it asks for your situation
    python main.py "mai 23 saal ka hoon gaon mai rehta hu mujhe kaam chahiye"
    python main.py --questions 1 "..."                   # ask at most 1 question (0 = none)
    python main.py --doc aadhaar.jpg --doc income.pdf "..."   # also read documents
    At the end it asks you to upload documents: drag a file into the window, press Enter.
    python main.py --no-upload "..."                    # skip the upload step
"""
import sys

from agent.followup import MAX_QUESTIONS, ask_followups
from agent.rule_based_extractor import extract_profile, extract_profile_with_reasons, missing_fields
from documents.document_profile import LABELS, apply_documents, read_document, save_documents
from documents.ocr import OCRNotInstalled
from engine.db_rules import get_connection
from engine.profile_store import save_profile
from engine.scheme_matcher import match_schemes
from services.scheme_matcher import get_schemes_for_citizen, print_scheme

SHOW = 5           # how many scheme names to print per list
TOP_ELIGIBLE = 3   # how many eligible schemes to show with full details
TOP_MAYBE = 2      # how many maybe schemes to show with full details


def run(message: str, extractor=extract_profile) -> dict:
    """Message -> profile -> matched schemes (no questions)."""
    profile = extractor(message)
    conn = get_connection()
    try:
        results = match_schemes(conn, profile)
    finally:
        conn.close()
    return {"profile": profile, "ask_next": missing_fields(profile), "schemes": results}


def show(output: dict) -> None:
    profile = output["profile"]
    print("\n1) PROFILE")
    for field, value in profile.model_dump(exclude_none=True, mode="json").items():
        if field not in ("citizen_id", "need_text") and value != []:
            print(f"   {field:18} {value}")

    print("\n2) STILL UNKNOWN")
    print("   " + (", ".join(output["ask_next"]) or "nothing, profile is complete"))

    print("\n3) SCHEMES")
    for status in ("eligible", "maybe", "not_eligible", "no_rules"):
        schemes = output["schemes"][status]
        print(f"   {status.upper()} ({len(schemes)})")
        if status in ("not_eligible", "no_rules"):
            continue                            # long lists, the count is enough here
        for s in schemes[:SHOW]:
            extra = f"   (need: {', '.join(s['missing'])})" if s.get("missing") else ""
            print(f"     - {s['scheme_name'][:65]}{extra}")
        if len(schemes) > SHOW:
            print(f"     ... and {len(schemes) - SHOW} more")


def read_documents(paths: list[str], password: str | None = None) -> list[dict]:
    """Read each uploaded file; skip (with a message) any that can't be read."""
    docs = []
    for path in paths:
        try:
            doc = read_document(path, password)
        except OCRNotInstalled as e:
            print(f"\n{path}: {e}")
            continue
        except Exception as e:
            print(f"\n{path}: could not read it ({e})")
            continue
        docs.append(doc)
        found = ", ".join(f"{k} {v}" for k, v in doc["details"].items()) or "nothing found"
        print(f"   {LABELS.get(doc['type'], doc['type'])} ({doc['file']}): {found}")
    return docs


def chat(message: str, ask=input, max_questions: int = MAX_QUESTIONS,
         doc_paths: list[str] = (), password: str | None = None, upload: bool = True) -> dict:
    """First message (+ documents) -> profile -> a few questions -> final schemes -> saved."""
    profile, reasons = extract_profile_with_reasons(message)
    print("Samjha:")
    for r in reasons or ["kuch khaas words nahi mile"]:
        print("   -", r)

    docs = []
    if doc_paths:
        print("\nDocuments padh rahe hain:")
        docs = read_documents(list(doc_paths), password)
        profile, changes = apply_documents(profile, docs)
        for c in changes:
            print("   +", c)
    uploaded = {d["type"] for d in docs} if doc_paths else None

    conn = get_connection()
    try:
        def match(p):
            return match_schemes(conn, p)

        first = match(profile)
        print(f"\nAbhi: {len(first['eligible'])} eligible, {len(first['maybe'])} maybe.")
        if max_questions:
            print(f"Max {max_questions} sawal (Enter dabao skip karne ke liye):")
        profile, schemes, conversation = ask_followups(profile, match, ask=ask,
                                                       max_questions=max_questions)
        where = save_profile(profile, conversation, conn)
        if docs:
            save_documents(profile.citizen_id, docs, conn)
        details = get_schemes_for_citizen(profile, conn, statuses=("eligible", "maybe"))
    finally:
        conn.close()

    output = {"profile": profile, "ask_next": missing_fields(profile), "schemes": schemes,
              "details": details, "conversation": conversation, "saved_to": where, "documents": docs}
    show(output)
    show_top(details, uploaded or set())

    if upload and details:
        new_docs = ask_for_documents(ask, password)
        if new_docs:
            docs += new_docs
            profile, changes = apply_documents(profile, new_docs)
            for c in changes:
                print("   +", c)
            conn = get_connection()
            try:
                save_profile(profile, conversation, conn)
                save_documents(profile.citizen_id, new_docs, conn)
                details = get_schemes_for_citizen(profile, conn, statuses=("eligible", "maybe"))
            finally:
                conn.close()
            uploaded = {d["type"] for d in docs}
            print(f"\nUpdated: {sum(d['status'] == 'eligible' for d in details)} eligible, "
                  f"{sum(d['status'] == 'maybe' for d in details)} maybe")
            show_top(details, uploaded)
            output.update(profile=profile, details=details, documents=docs)

    print(f"\nSaved to: {where}   (session_id = {profile.citizen_id})")
    return output


def show_top(details: list[dict], uploaded: set[str]) -> None:
    """Full details (with document checkmarks) of the top eligible and maybe schemes."""
    top = ([d for d in details if d["status"] == "eligible"][:TOP_ELIGIBLE] +
           [d for d in details if d["status"] == "maybe"][:TOP_MAYBE])
    if top:
        print("\n4) DETAILS OF TOP SCHEMES")
        for i, d in enumerate(top, start=1):
            print_scheme(d, i, uploaded)


def ask_for_documents(ask=input, password: str | None = None) -> list[dict]:
    """Let the person add document files one by one (drag the file into the terminal)."""
    print("\n5) DOCUMENTS UPLOAD KARO (Aadhaar, income certificate, bank passbook ...)")
    print("   File ko is window mein drag karo (ya path likho) aur Enter dabao.")
    print("   Khatam karne ke liye sirf Enter dabao.")
    docs = []
    while True:
        path = ask("   File > ").strip()
        if not path:
            break
        path = path.removeprefix("& ").strip().strip("'\"")    # PowerShell adds & '...' when dragging
        docs += read_documents([path], password)
    return docs


if __name__ == "__main__":
    sys.stdout.reconfigure(errors="replace")    # some scheme names have special characters
    args = sys.argv[1:]
    max_questions, doc_paths, password, words, upload = MAX_QUESTIONS, [], None, [], True
    while args:                                 # read the options, the rest is the message
        arg = args.pop(0)
        if arg in ("--questions", "-q"):        # python main.py -q 1 "..."
            max_questions = int(args.pop(0))
        elif arg in ("--doc", "-d"):            # python main.py --doc aadhaar.jpg "..."
            doc_paths.append(args.pop(0))
        elif arg == "--password":               # password of an e-Aadhaar PDF
            password = args.pop(0)
        elif arg == "--no-upload":              # don't ask for documents at the end
            upload = False
        else:
            words.append(arg)
    message = " ".join(words) or input("Apni situation likhiye:\n> ")
    chat(message, max_questions=max_questions, doc_paths=doc_paths, password=password, upload=upload)
