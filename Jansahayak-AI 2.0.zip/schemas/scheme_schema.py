"""scheme_schema.py: what information every government scheme contains.

The criteria (age, income, rural/urban, education, employment ...) are not
separate text fields. They are written as EligibilityRule objects in
eligibility_rules, so the code can check them automatically.
"""
from enum import Enum
from typing import Optional

from pydantic import BaseModel

from citizen_schema import CitizenProfile, Need
from eligibility_schema import EligibilityRule, check_rules


class SchemeLevel(str, Enum):
    central = "central"
    state = "state"


class Scheme(BaseModel):
    scheme_id: str                          # "SCHEME001"
    scheme_name: str
    description: str
    purpose: list[Need]                     # which citizen needs it helps with
    target_beneficiaries: str               # "Adults in rural households"
    level: SchemeLevel
    state: Optional[str] = None             # None = all India
    benefits: str
    required_documents: list[str]           # ["aadhaar", "photo", "bank_passbook"]
    eligibility_rules: list[EligibilityRule]
    application_process: str
    official_website: str
    official_application_url: Optional[str] = None
    ministry: str                           # source / ministry

    def check(self, citizen: CitizenProfile) -> str:
        """Returns "eligible", "not_eligible" or "maybe"."""
        if self.state and citizen.state and self.state != citizen.state:
            return "not_eligible"           # state scheme for another state
        return check_rules(self.eligibility_rules, citizen.model_dump())


if __name__ == "__main__":
    mgnrega = Scheme(
        scheme_id="SCHEME001",
        scheme_name="MGNREGA (Mahatma Gandhi National Rural Employment Guarantee Scheme)",
        description="Guarantees up to 100 days of paid manual work a year to rural households.",
        purpose=["employment"],
        target_beneficiaries="Adult members of rural households willing to do unskilled manual work",
        level="central",
        benefits="Up to 100 days of wage employment per household per year",
        required_documents=["aadhaar", "photo", "bank_passbook"],
        eligibility_rules=[
            EligibilityRule(rule_id="RULE001", scheme_id="SCHEME001", field="age",
                            operator=">=", value=18, condition_group=1,
                            description="Applicant must be 18+"),
            EligibilityRule(rule_id="RULE002", scheme_id="SCHEME001", field="area",
                            operator="==", value="rural", condition_group=2,
                            description="Applicant must live in a rural area"),
        ],
        application_process="Apply for a job card at your Gram Panchayat, then ask for work.",
        official_website="https://nrega.nic.in",
        ministry="Ministry of Rural Development",
    )

    tests = {
        "23, village":    CitizenProfile(age=23, area="rural"),
        "23, city":       CitizenProfile(age=23, area="urban"),
        "23, area unknown": CitizenProfile(age=23),
    }
    for label, person in tests.items():
        print(f"{label:18} -> {mgnrega.check(person)}")
