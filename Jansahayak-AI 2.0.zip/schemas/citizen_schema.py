"""citizen_schema.py: what information a citizen profile can contain.

Every field except citizen_id can be None, which means "we don't know yet".
The AI fills in what it learns from the user's message and asks for the rest.
"""
from enum import Enum
from typing import Optional
from uuid import uuid4

from pydantic import BaseModel, Field


class Gender(str, Enum):
    male = "male"
    female = "female"
    transgender = "transgender"
    prefer_not_to_say = "prefer_not_to_say"


class Area(str, Enum):
    rural = "rural"
    urban = "urban"


class Education(str, Enum):
    none = "none"
    primary = "primary"            # class 1-5
    middle = "middle"              # class 6-8
    class_10 = "class_10"
    class_12 = "class_12"
    diploma_iti = "diploma_iti"
    graduate = "graduate"
    postgraduate = "postgraduate"


class EmploymentStatus(str, Enum):
    unemployed = "unemployed"
    wage_labourer = "wage_labourer"
    self_employed = "self_employed"
    farmer = "farmer"
    salaried_private = "salaried_private"
    salaried_govt = "salaried_govt"
    student = "student"
    homemaker = "homemaker"
    retired = "retired"


class Category(str, Enum):
    general = "general"
    obc = "obc"
    sc = "sc"
    st = "st"
    ews = "ews"


class Need(str, Enum):
    employment = "employment"
    skill_training = "skill_training"
    loan = "loan"
    housing = "housing"
    education = "education"
    health = "health"
    pension = "pension"
    agriculture = "agriculture"
    land = "land"                  # has no land and wants some (e.g. for farming)


class MaritalStatus(str, Enum):
    single = "single"
    married = "married"
    widowed = "widowed"
    divorced = "divorced"


class Skill(str, Enum):
    agriculture = "agriculture"
    animal_husbandry = "animal_husbandry"   # dairy, goats, poultry
    fishing = "fishing"
    tailoring = "tailoring"
    weaving_handicraft = "weaving_handicraft"
    construction = "construction"           # mason, mistri
    carpentry = "carpentry"
    electrician = "electrician"
    plumbing = "plumbing"
    welding = "welding"
    painting = "painting"
    driving = "driving"
    mechanic = "mechanic"                   # vehicle / mobile repair
    computer = "computer"
    cooking = "cooking"
    beauty = "beauty"                       # beauty parlour, mehendi


class CitizenProfile(BaseModel):
    citizen_id: str = Field(default_factory=lambda: str(uuid4()))   # unique user
    age: Optional[int] = Field(None, ge=0, le=120)                  # age-based eligibility
    gender: Optional[Gender] = None                                 # gender-specific schemes
    state: Optional[str] = None                                     # state schemes
    district: Optional[str] = None                                  # local schemes
    area: Optional[Area] = None                                     # rural / urban
    education: Optional[Education] = None                          # education eligibility
    employment_status: Optional[EmploymentStatus] = None            # employment schemes
    annual_income: Optional[float] = Field(None, ge=0)              # rupees per year
    category: Optional[Category] = None                             # SC/ST/OBC/EWS
    has_disability: Optional[bool] = None                           # disability schemes
    disability_percent: Optional[int] = Field(None, ge=0, le=100)   # disability eligibility
    is_farmer: Optional[bool] = None                                # agriculture schemes
    land_owned_acres: Optional[float] = Field(None, ge=0)           # agriculture eligibility
    has_bank_account: Optional[bool] = None                         # financial schemes
    has_bpl_card: Optional[bool] = None                             # BPL-only schemes
    has_aadhaar: Optional[bool] = None                              # document requirement
    marital_status: Optional[MaritalStatus] = None                  # widow / single-woman schemes
    skills: list[Skill] = []                                        # what the person can already do
    owns_land: Optional[bool] = None                                # landless-farmer schemes
    has_house: Optional[bool] = None                                # housing schemes (PMAY)
    needs: list[Need] = []                                          # main requirement(s)
    need_text: Optional[str] = None                                 # user's own words


if __name__ == "__main__":
    # "mai 23 saal ka hoon gaon mai rehta hu mujhe kaam chahiye"
    person = CitizenProfile(
        age=23,
        area="rural",
        employment_status="unemployed",
        needs=["employment"],
        need_text="mai 23 saal ka hoon gaon mai rehta hu mujhe kaam chahiye",
    )
    print(person.model_dump_json(indent=2, exclude_none=True))
