"""eligibility_schema.py: how a scheme expresses its requirements.

One rule = one small check on one citizen field, e.g. age >= 18.

How rules combine:
- Rules with the SAME condition_group are OR'ed (passing any one is enough).
- DIFFERENT condition_groups are AND'ed (every group must pass).
- required=False rules are "nice to have": they never block eligibility.
"""
from enum import Enum
from typing import Any, Union

from pydantic import BaseModel


class Operator(str, Enum):
    eq = "=="
    ne = "!="
    gt = ">"
    gte = ">="
    lt = "<"
    lte = "<="
    is_in = "in"            # value is a list, e.g. ["sc", "st"]
    not_in = "not_in"
    is_true = "is_true"     # no value needed
    is_false = "is_false"


class EligibilityRule(BaseModel):
    rule_id: str                        # "RULE001"
    scheme_id: str                      # "SCHEME001"
    field: str                          # a CitizenProfile field, e.g. "age"
    operator: Operator                  # ">="
    value: Any = None                   # 18, "rural", ["sc", "st"]
    required: bool = True
    condition_group: Union[int, str] = 1
    description: str = ""               # "Applicant must be 18+"


class Result(str, Enum):
    passed = "pass"
    failed = "fail"
    unknown = "unknown"                 # we don't know this field yet


def check_rule(rule: EligibilityRule, citizen: dict) -> Result:
    actual = citizen.get(rule.field)
    if actual is None:
        return Result.unknown
    if isinstance(actual, Enum):        # enum -> plain text like "rural"
        actual = actual.value
    v = rule.value
    op = rule.operator
    if op == Operator.eq:
        ok = actual == v
    elif op == Operator.ne:
        ok = actual != v
    elif op == Operator.gt:
        ok = actual > v
    elif op == Operator.gte:
        ok = actual >= v
    elif op == Operator.lt:
        ok = actual < v
    elif op == Operator.lte:
        ok = actual <= v
    elif op == Operator.is_in:
        ok = actual in v
    elif op == Operator.not_in:
        ok = actual not in v
    elif op == Operator.is_true:
        ok = actual is True
    else:  # is_false
        ok = actual is False
    return Result.passed if ok else Result.failed


def check_rules(rules: list[EligibilityRule], citizen: dict) -> str:
    """Returns "eligible", "not_eligible" or "maybe" (some info missing)."""
    groups: dict = {}
    for rule in rules:
        if rule.required:
            groups.setdefault(rule.condition_group, []).append(check_rule(rule, citizen))

    any_unknown = False
    for results in groups.values():
        if Result.passed in results:
            continue                    # this group is satisfied
        if Result.unknown in results:
            any_unknown = True          # might pass once we know more
        else:
            return "not_eligible"       # every rule in this group failed
    return "maybe" if any_unknown else "eligible"


if __name__ == "__main__":
    rule = EligibilityRule(rule_id="RULE001", scheme_id="SCHEME001", field="age",
                           operator=">=", value=18, description="Applicant must be 18+")
    print(rule.description, "->", check_rule(rule, {"age": 23}).value)   # pass
    print(rule.description, "->", check_rule(rule, {"age": 16}).value)   # fail
    print(rule.description, "->", check_rule(rule, {}).value)            # unknown
