"""test_schemes.py: fake schemes used only to test the eligibility engine.

These are NOT real government schemes. Later they get replaced by rules
loaded from PostgreSQL.
"""
from schemas.eligibility_schema import EligibilityRule, Operator


# Scheme 1: age >= 18 AND rural AND income <= 2 lakh
# (different condition_group on every rule -> all must pass)
TEST_SCHEME_ID = "TEST_EMPLOYMENT_001"
TEST_SCHEME_NAME = "Test Rural Employment Scheme"

TEST_RULES = [
    EligibilityRule(
        rule_id="R1",
        scheme_id=TEST_SCHEME_ID,
        field="age",
        operator=Operator.gte,
        value=18,
        required=True,
        condition_group="1",
        description="Applicant must be at least 18 years old",
    ),
    EligibilityRule(
        rule_id="R2",
        scheme_id=TEST_SCHEME_ID,
        field="area",
        operator=Operator.eq,
        value="rural",
        required=True,
        condition_group="2",
        description="Applicant must live in a rural area",
    ),
    EligibilityRule(
        rule_id="R3",
        scheme_id=TEST_SCHEME_ID,
        field="annual_income",
        operator=Operator.lte,
        value=200000,
        required=True,
        condition_group="3",
        description="Annual income must not exceed ₹2 lakh",
    ),
]


# Scheme 2: category is SC OR ST
# (same condition_group on both rules -> passing either one is enough)
CATEGORY_SCHEME_ID = "TEST_CATEGORY_001"
CATEGORY_SCHEME_NAME = "Test SC/ST Scheme"

CATEGORY_RULES = [
    EligibilityRule(
        rule_id="C1",
        scheme_id=CATEGORY_SCHEME_ID,
        field="category",
        operator=Operator.eq,
        value="sc",
        required=True,
        condition_group="1",
        description="Applicant can be SC",
    ),
    EligibilityRule(
        rule_id="C2",
        scheme_id=CATEGORY_SCHEME_ID,
        field="category",
        operator=Operator.eq,
        value="st",
        required=True,
        condition_group="1",
        description="Applicant can be ST",
    ),
]
