"""verify_apply_mode.py: shows apply_mode counts and 3 random schemes per mode,
so you can check by eye that online / offline / both / unknown look right.

Run from the JanSahayak-AI folder (after database/add_apply_mode.py):
    python database/verify_apply_mode.py
Run it again to see 3 different random schemes.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(errors="replace")

from engine.db_rules import get_connection
from services.apply_mode import where_to_submit

SAMPLES = 3


def snippet(text, n=220):
    text = " ".join((text or "").split())
    return text if len(text) <= n else text[:n - 3] + "..."


def main():
    conn = get_connection()
    with conn.cursor() as cur:
        cur.execute("""SELECT apply_mode, COUNT(*), COUNT(online_url),
                              COUNT(*) FILTER (WHERE apply_via_csc)
                       FROM schemes GROUP BY 1 ORDER BY 2 DESC""")
        print("MODE      SCHEMES  WITH PORTAL LINK  VIA CSC")
        for mode, count, with_url, csc in cur.fetchall():
            print(f"{mode or 'not set':9} {count:>7}  {with_url:>16}  {csc:>7}")

        for mode in ("online", "offline", "both", "unknown"):
            cur.execute("""SELECT scheme_id, scheme_name, online_url, application_process
                           FROM schemes WHERE apply_mode = %s ORDER BY random() LIMIT %s""",
                        (mode, SAMPLES))
            print(f"\n===== {mode.upper()} =====")
            for sid, name, url, text in cur.fetchall():
                print(f"\n- {name}  ({sid})")
                print(f"  text      : {snippet(text)}")
                if url:
                    print(f"  portal    : {url}")
                if mode in ("offline", "both"):
                    print(f"  submit at : {snippet(where_to_submit(text), 160) or '-'}")
    conn.close()


if __name__ == "__main__":
    main()
