"""add_apply_mode.py: adds apply_mode (online / offline / both / unknown) to the schemes table.

Safe to run again at any time. Run it again after database/import_schemes.py,
because the import reloads the schemes table.

Run from the JanSahayak-AI folder:
    python database/add_apply_mode.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from psycopg2.extras import execute_values

from engine.db_rules import get_connection
from services.apply_mode import classify

ADD_COLUMNS = """
ALTER TABLE schemes ADD COLUMN IF NOT EXISTS apply_mode    VARCHAR(10);  -- online / offline / both / unknown
ALTER TABLE schemes ADD COLUMN IF NOT EXISTS apply_via_csc BOOLEAN;      -- online at a CSC centre
ALTER TABLE schemes ADD COLUMN IF NOT EXISTS online_url    TEXT;         -- portal link found in the text
"""


def main():
    conn = get_connection()
    with conn, conn.cursor() as cur:
        cur.execute(ADD_COLUMNS)
        cur.execute("SELECT scheme_id, application_process FROM schemes")
        rows = [(sid, *classify(text).values()) for sid, text in cur.fetchall()]
        execute_values(cur, """
            UPDATE schemes AS s
            SET apply_mode = v.mode, apply_via_csc = v.csc, online_url = v.url
            FROM (VALUES %s) AS v(scheme_id, mode, csc, url)
            WHERE s.scheme_id = v.scheme_id""", rows, page_size=1000)
        cur.execute("SELECT apply_mode, COUNT(*) FROM schemes GROUP BY 1 ORDER BY 2 DESC")
        print("apply_mode saved for", len(rows), "schemes:")
        for mode, count in cur.fetchall():
            print(f"  {mode:8} {count:>5}")
    conn.close()


if __name__ == "__main__":
    main()
