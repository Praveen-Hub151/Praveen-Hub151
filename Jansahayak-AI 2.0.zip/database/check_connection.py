"""check_connection.py: checks that Python can reach jansahayak_db.

Run from the JanSahayak-AI folder:
    python database/check_connection.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine.db_rules import get_connection

TABLES = ["schemes", "scheme_purposes", "scheme_documents", "eligibility_rules"]

try:
    conn = get_connection()
except Exception as e:
    print("Could not connect to PostgreSQL:")
    print("  ", str(e).strip().splitlines()[-1])
    print("Fix DB_PASSWORD (or DB_NAME) in your .env file and run this again.")
    sys.exit(1)

print("Connected to PostgreSQL.")
with conn.cursor() as cur:
    for table in TABLES:
        try:
            cur.execute(f"SELECT COUNT(*) FROM {table}")
            print(f"  {table:18} {cur.fetchone()[0]:>6} rows")
        except Exception:
            conn.rollback()
            print(f"  {table:18} missing (run: python database/import_schemes.py)")
conn.close()
