-- JanSahayak AI: scheme tables
-- Run once to create the tables:  psql -U postgres -d jansahayak_db -f database/schema.sql
-- (import_schemes.py also runs this file for you, so you can skip it.)

-- 1. schemes: one row per scheme
CREATE TABLE IF NOT EXISTS schemes (
    scheme_id                VARCHAR(100) PRIMARY KEY,   -- myScheme slug, e.g. 'pm-kisan'
    scheme_name              TEXT NOT NULL,
    description              TEXT,
    level                    VARCHAR(20) NOT NULL CHECK (level IN ('central', 'state')),
    state                    TEXT,                       -- NULL for central schemes
    ministry                 TEXT,
    department               TEXT,
    beneficiary_type         TEXT,                       -- 'Individual', 'Family', 'Institution' ...
    benefits                 TEXT,
    eligibility_text         TEXT,                       -- full eligibility in words (fallback for the agent)
    application_process      TEXT,
    official_website         TEXT,                       -- myScheme page for the scheme
    official_application_url TEXT,                       -- where to apply / the official form
    scraped_at               TIMESTAMPTZ
);

-- 2. scheme_purposes: one row per (scheme, purpose)
CREATE TABLE IF NOT EXISTS scheme_purposes (
    purpose_id  SERIAL PRIMARY KEY,
    scheme_id   VARCHAR(100) NOT NULL REFERENCES schemes(scheme_id) ON DELETE CASCADE,
    category    TEXT NOT NULL,          -- myScheme category, e.g. 'Skills & Employment'
    purpose     VARCHAR(50)             -- our Need value, e.g. 'employment' (NULL if no match)
);

-- 3. scheme_documents: one row per (scheme, document)
CREATE TABLE IF NOT EXISTS scheme_documents (
    document_id   SERIAL PRIMARY KEY,
    scheme_id     VARCHAR(100) NOT NULL REFERENCES schemes(scheme_id) ON DELETE CASCADE,
    document_name TEXT NOT NULL
);

-- 4. eligibility_rules: one row per check, same shape as EligibilityRule in schemas/
CREATE TABLE IF NOT EXISTS eligibility_rules (
    rule_id         VARCHAR(100) PRIMARY KEY,
    scheme_id       VARCHAR(100) NOT NULL REFERENCES schemes(scheme_id) ON DELETE CASCADE,
    field           VARCHAR(100) NOT NULL,   -- a CitizenProfile field: age, gender, area ...
    operator        VARCHAR(20)  NOT NULL,   -- '>=', '<=', '==', 'in', 'is_true' ...
    value           JSONB,                   -- 18, "female", ["sc", "st"]
    required        BOOLEAN NOT NULL DEFAULT TRUE,
    condition_group VARCHAR(50)  NOT NULL,   -- same group = OR, different groups = AND
    description     TEXT
);

-- Indexes make lookups by scheme / purpose / state fast
CREATE INDEX IF NOT EXISTS idx_schemes_state       ON schemes(state);
CREATE INDEX IF NOT EXISTS idx_purposes_scheme     ON scheme_purposes(scheme_id);
CREATE INDEX IF NOT EXISTS idx_purposes_purpose    ON scheme_purposes(purpose);
CREATE INDEX IF NOT EXISTS idx_documents_scheme    ON scheme_documents(scheme_id);
CREATE INDEX IF NOT EXISTS idx_rules_scheme        ON eligibility_rules(scheme_id);

-- Added by database/fix_links.py (safe to run again)
ALTER TABLE schemes ADD COLUMN IF NOT EXISTS original_application_url TEXT;   -- the old PDF / broken link
ALTER TABLE schemes ADD COLUMN IF NOT EXISTS link_status VARCHAR(30);         -- ok, pdf->site, broken->myscheme ...
