"""import_schemes.py: turn data/Schemes.csv into the 4 PostgreSQL tables.

    schemes  |  scheme_purposes  |  scheme_documents  |  eligibility_rules

Run from the project folder:
    python database/import_schemes.py              # load into PostgreSQL
    python database/import_schemes.py --csv-only   # just write the 4 tables as CSVs to data/output/

Safe to run again: it empties the 4 tables and reloads them.
"""
import argparse
import json
import os
import re
from pathlib import Path

import pandas as pd

PROJECT_DIR = Path(__file__).resolve().parent.parent
CSV_PATH = PROJECT_DIR / "data" / "Schemes.csv"
SCHEMA_SQL = PROJECT_DIR / "database" / "schema.sql"
OUTPUT_DIR = PROJECT_DIR / "data" / "output"

# myScheme category  ->  our Need values (schemas/citizen_schema.py)
CATEGORY_TO_PURPOSES = {
    "Agriculture,Rural & Environment": ["agriculture"],
    "Education & Learning": ["education"],
    "Skills & Employment": ["employment", "skill_training"],
    "Business & Entrepreneurship": ["loan"],
    "Banking,Financial Services and Insurance": ["loan"],
    "Health & Wellness": ["health"],
    "Housing & Shelter": ["housing"],
}

CASTE_MAP = {"SC": "sc", "ST": "st", "OBC": "obc", "General": "general"}


def clean(value):
    """Turn pandas NaN into None and strip extra spaces."""
    if pd.isna(value):
        return None
    if isinstance(value, str):
        value = value.strip()
        return value or None
    return value


# ---------- 1. schemes ----------
def build_schemes(df):
    rows = []
    for _, r in df.iterrows():
        is_central = clean(r["state"]) == "Central"
        rows.append({
            "scheme_id": clean(r["slug"]),
            "scheme_name": clean(r["name"]),
            "description": clean(r["description"]),
            "level": "central" if is_central else "state",
            "state": None if is_central else clean(r["state"]),
            "ministry": clean(r["ministry"]),
            "department": clean(r["department"]),
            "beneficiary_type": clean(r["beneficiary_type"]),
            "benefits": clean(r["benefits"]),
            "eligibility_text": clean(r["eligibility_text"]),
            "application_process": clean(r["application_process"]),
            "official_website": clean(r["official_url"]),
            "official_application_url": clean(r["apply_url"]),
            "scraped_at": clean(r["scraped_at"]),
            # filled by database/fix_links.py (empty if it was never run)
            "original_application_url": clean(r.get("original_apply_url")),
            "link_status": clean(r.get("link_status")),
        })
    return pd.DataFrame(rows)


# ---------- 2. scheme_purposes ----------
def split_categories(text):
    # Categories are separated by ", ". "Science, IT & Communications" is one category.
    text = (text or "").replace("Science, IT & Communications", "Science/IT & Communications")
    return [c.strip().replace("Science/IT", "Science, IT") for c in text.split(", ") if c.strip()]


def build_purposes(df):
    rows = []
    for _, r in df.iterrows():
        for category in split_categories(clean(r["category"])):
            for purpose in CATEGORY_TO_PURPOSES.get(category, [None]):
                rows.append({"scheme_id": r["slug"], "category": category, "purpose": purpose})
    return pd.DataFrame(rows)


# ---------- 3. scheme_documents ----------
def build_documents(df):
    rows = []
    for _, r in df.iterrows():
        text = clean(r["documents_required"]) or ""
        seen = set()
        for line in text.split("\n"):
            # remove bullets like "- ", "* ", "1. ", "2) "
            name = re.sub(r"^\s*([-*•]|\d+[.)])\s*", "", line).strip()
            if name and name.lower() not in seen:
                seen.add(name.lower())
                rows.append({"scheme_id": r["slug"], "document_name": name})
    return pd.DataFrame(rows)


# ---------- 4. eligibility_rules ----------
def parse_list(text):
    try:
        return json.loads(text) if isinstance(text, str) else []
    except json.JSONDecodeError:
        return []


def build_rules(df):
    rows = []
    for _, r in df.iterrows():
        sid = r["slug"]
        rules = []  # (field, operator, value, description)

        if pd.notna(r["eligibility_age_min"]):
            age = int(r["eligibility_age_min"])
            rules.append(("age", ">=", age, f"Applicant must be at least {age} years old"))
        if pd.notna(r["eligibility_age_max"]):
            age = int(r["eligibility_age_max"])
            rules.append(("age", "<=", age, f"Applicant must be at most {age} years old"))

        gender = clean(r["eligibility_gender"])
        if gender in ("female", "male"):
            rules.append(("gender", "==", gender, f"Only for {gender} applicants"))

        castes = [CASTE_MAP[c] for c in parse_list(r["eligibility_caste"]) if c in CASTE_MAP]
        if castes:
            rules.append(("category", "in", castes,
                          "Applicant must belong to: " + ", ".join(c.upper() for c in castes)))

        if pd.notna(r["eligibility_income_max"]):
            income = int(r["eligibility_income_max"])
            rules.append(("annual_income", "<=", income,
                          f"Annual income must be at most Rs {income:,}"))

        residence = clean(r["eligibility_residence"])
        if residence in ("rural", "urban"):
            rules.append(("area", "==", residence, f"Applicant must live in a {residence} area"))

        states = [s for s in parse_list(r["eligibility_state"]) if s and s != "All"]
        if states:
            rules.append(("state", "in", states, "Applicant must be a resident of " + ", ".join(states)))

        if r["eligibility_disability"] is True or str(r["eligibility_disability"]) == "True":
            rules.append(("has_disability", "is_true", None, "Applicant must have a disability"))

        if r["eligibility_bpl"] is True or str(r["eligibility_bpl"]) == "True":
            rules.append(("has_bpl_card", "is_true", None, "Applicant must be from a BPL family"))

        # Every rule gets its own group, so ALL of them must pass (AND).
        for i, (field, op, value, desc) in enumerate(rules, start=1):
            rows.append({
                "rule_id": f"{sid}_R{i:02d}",
                "scheme_id": sid,
                "field": field,
                "operator": op,
                "value": value,
                "required": True,
                "condition_group": str(i),
                "description": desc,
            })
    return pd.DataFrame(rows)


# ---------- load into PostgreSQL ----------
def load_to_postgres(tables):
    import psycopg2
    from psycopg2.extras import Json, execute_values
    import sys
    sys.path.insert(0, str(PROJECT_DIR))
    from engine.db_rules import connection_settings

    conn = psycopg2.connect(**connection_settings())   # DATABASE_URL or the DB_* settings
    with conn, conn.cursor() as cur:
        cur.execute(SCHEMA_SQL.read_text())
        cur.execute("TRUNCATE eligibility_rules, scheme_documents, scheme_purposes, schemes "
                    "RESTART IDENTITY CASCADE")
        for name, df in tables.items():
            df = df.astype(object).where(pd.notna(df), None)
            if name == "eligibility_rules":
                df["value"] = df["value"].apply(Json)
            cols = list(df.columns)
            sql = f"INSERT INTO {name} ({', '.join(cols)}) VALUES %s"
            execute_values(cur, sql, df.itertuples(index=False, name=None), page_size=1000)
            print(f"  {name:18} {len(df):>6} rows loaded")
    conn.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv-only", action="store_true",
                        help="write the 4 tables to data/output/ instead of PostgreSQL")
    args = parser.parse_args()

    print(f"Reading {CSV_PATH} ...")
    df = pd.read_csv(CSV_PATH)
    df = df.drop_duplicates(subset="slug")
    print(f"  {len(df)} schemes found")

    tables = {   # order matters: schemes first, because the others point to it
        "schemes": build_schemes(df),
        "scheme_purposes": build_purposes(df),
        "scheme_documents": build_documents(df),
        "eligibility_rules": build_rules(df),
    }

    if args.csv_only:
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        for name, table in tables.items():
            if name == "eligibility_rules":
                table = table.assign(value=table["value"].apply(json.dumps))
            table.to_csv(OUTPUT_DIR / f"{name}.csv", index=False)
            print(f"  {name:18} {len(table):>6} rows -> data/output/{name}.csv")
    else:
        print("Loading into PostgreSQL ...")
        load_to_postgres(tables)
    print("Done.")


if __name__ == "__main__":
    main()
