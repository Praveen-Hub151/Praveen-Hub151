"""fix_links.py: checks every apply link in data/Schemes.csv and fixes broken and PDF links.

For each scheme:
    link works and is a web page            -> kept
    link is a PDF / Word file               -> replaced by that website's home page (if it opens),
                                               otherwise by the scheme's myScheme page.
                                               The PDF is kept in column original_apply_url.
    link is broken (404, site gone ...)     -> replaced by the website's home page (if it opens),
                                               otherwise by the myScheme page
    link did not answer in time             -> kept, marked "unchecked"
    no link                                 -> myScheme page

It also checks the portal links found in the application text (online_url) and lists the
broken ones in data/broken_links.txt so the app never shows them.

Run from the JanSahayak-AI folder (takes a while: ~5,000 links, a few at a time, politely):
    python database/fix_links.py              # check, fix Schemes.csv (backup first), update the database
    python database/fix_links.py --report     # only print the counts from the last run

Safe to run again: results are cached in data/link_check_cache.json, so only new links are checked.
"""
import argparse
import json
import os
import re
import shutil
import sys
import threading
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

import httpx
import pandas as pd

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))

CSV = PROJECT / "data" / "Schemes.csv"
CACHE = PROJECT / "data" / "link_check_cache.json"
BROKEN_TXT = PROJECT / "data" / "broken_links.txt"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) JanSahayak-AI link checker (student project)"
WORKERS = 8                # links checked at the same time (never two on the same website)
TIMEOUT = 15
PAUSE_SAME_SITE = 1.0      # seconds between two requests to the same website
DOCUMENT = re.compile(r"\.(pdf|docx?|xlsx?|odt|pptx?|zip|rar)(?=$|[?#&/])|\.pdf|"
                      r"/(download|downloadfile|viewfile|writereaddata|uploaded|uploads|uploadfile|upload)/", re.I)

_site_locks: dict[str, threading.Lock] = defaultdict(threading.Lock)
_last_hit: dict[str, float] = {}


def site_home(url: str) -> str | None:
    p = urlparse(url or "")
    return f"{p.scheme}://{p.netloc}/" if p.scheme in ("http", "https") and p.netloc else None


def check(url: str) -> dict:
    """{"result": ok | broken | timeout, "code", "final", "document"}"""
    host = urlparse(url).netloc.lower()
    with _site_locks[host]:                                  # one request at a time per website
        wait = PAUSE_SAME_SITE - (time.time() - _last_hit.get(host, 0))
        if wait > 0:
            time.sleep(wait)
        try:
            out = _fetch(url, verify=True)
        except httpx.ConnectError as e:
            if "CERTIFICATE" in str(e).upper() or "SSL" in str(e).upper():
                try:                                         # many government sites have certificate issues
                    out = _fetch(url, verify=False)
                    out["ssl_warning"] = True
                except Exception as e2:
                    out = {"result": "broken", "code": None, "error": type(e2).__name__}
            else:
                out = {"result": "broken", "code": None, "error": "cannot connect"}
        except httpx.TimeoutException:
            out = {"result": "timeout", "code": None}
        except Exception as e:
            out = {"result": "broken", "code": None, "error": type(e).__name__}
        _last_hit[host] = time.time()
    return out


def _fetch(url: str, verify: bool) -> dict:
    with httpx.Client(follow_redirects=True, timeout=TIMEOUT, verify=verify, headers={"User-Agent": UA}) as c:
        with c.stream("GET", url) as r:                      # only the headers + first bytes are read
            code, final, ctype = r.status_code, str(r.url), r.headers.get("content-type", "")
    if code in (404, 410) or code >= 500:
        result = "broken"
    else:
        result = "ok"                                         # 2xx/3xx, and 401/403 (page exists, needs login)
    return {"result": result, "code": code, "final": final,
            "document": bool(DOCUMENT.search(final)) or any(t in ctype for t in ("pdf", "msword", "officedocument"))}


def check_all(urls: list[str], cache: dict) -> dict:
    todo = [u for u in dict.fromkeys(urls) if u and u not in cache]
    print(f"{len(urls)} links, {len(todo)} not checked yet. Checking {WORKERS} at a time ...")
    done = 0
    with ThreadPoolExecutor(WORKERS) as pool:
        futures = {pool.submit(check, u): u for u in todo}
        for f in as_completed(futures):
            cache[futures[f]] = f.result()
            done += 1
            if done % 100 == 0 or done == len(todo):
                print(f"  {done}/{len(todo)} checked")
                CACHE.write_text(json.dumps(cache, indent=0), encoding="utf-8")   # progress is never lost
    CACHE.write_text(json.dumps(cache, indent=0), encoding="utf-8")
    return cache


def decide(row, cache) -> tuple[str, str, str | None]:
    """-> (new apply url, link_status, original url to keep or None)"""
    apply_url = row["apply_url"] if isinstance(row["apply_url"], str) and row["apply_url"].strip() else None
    myscheme = row["official_url"]
    if not apply_url:
        return myscheme, "missing->myscheme", None
    c = cache.get(apply_url, {})
    is_doc = bool(DOCUMENT.search(apply_url)) or c.get("document", False)
    if c.get("result") == "timeout":
        return apply_url, "unchecked", None
    if c.get("result") == "ok" and not is_doc:
        return apply_url, "ok", None
    home = site_home(c.get("final") or apply_url)
    reason = "pdf" if c.get("result") == "ok" else "broken"
    if home and cache.get(home, {}).get("result") == "ok":
        return home, f"{reason}->site", apply_url
    return myscheme, f"{reason}->myscheme", apply_url


def update_database(df: pd.DataFrame, broken_online: list[str]) -> None:
    from engine.db_rules import get_connection
    from psycopg2.extras import execute_values
    conn = get_connection()
    with conn, conn.cursor() as cur:
        cur.execute("ALTER TABLE schemes ADD COLUMN IF NOT EXISTS original_application_url TEXT")
        cur.execute("ALTER TABLE schemes ADD COLUMN IF NOT EXISTS link_status VARCHAR(30)")
        rows = [(r.slug, r.apply_url, r.original_apply_url if isinstance(r.original_apply_url, str) else None,
                 r.link_status) for r in df.itertuples()]
        execute_values(cur, """UPDATE schemes AS s SET official_application_url = v.url,
                                   original_application_url = v.orig, link_status = v.status
                               FROM (VALUES %s) AS v(id, url, orig, status) WHERE s.scheme_id = v.id""",
                       rows, page_size=1000)
        cur.execute("SELECT 1 FROM information_schema.columns WHERE table_name='schemes' AND column_name='online_url'")
        if cur.fetchone() and broken_online:
            cur.execute("UPDATE schemes SET online_url = NULL WHERE online_url = ANY(%s)", (broken_online,))
    conn.close()
    print("Database updated (schemes.official_application_url, original_application_url, link_status).")


def report(df: pd.DataFrame) -> None:
    counts = Counter(df["link_status"])
    print("\nRESULT")
    labels = {"ok": "already working", "pdf->site": "PDF replaced by the official website",
              "pdf->myscheme": "PDF replaced by the myScheme page (website did not open)",
              "broken->site": "broken link replaced by the official website",
              "broken->myscheme": "broken link replaced by the myScheme page",
              "missing->myscheme": "no link, now the myScheme page", "unchecked": "did not answer in time (kept)"}
    for key, label in labels.items():
        print(f"  {counts.get(key, 0):>5}  {label}")
    print(f"  {len(df):>5}  schemes in total")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", action="store_true", help="only show the counts of the last run")
    args = ap.parse_args()
    df = pd.read_csv(CSV)

    if args.report:
        if "link_status" not in df.columns:
            print("No run yet. Run: python database/fix_links.py")
            return
        report(df)
        return

    cache = json.loads(CACHE.read_text(encoding="utf-8")) if CACHE.exists() else {}
    source = df["original_apply_url"].where(df["original_apply_url"].notna(), df["apply_url"]) \
        if "original_apply_url" in df.columns else df["apply_url"]
    df["apply_url"] = source                                   # always start from the original links
    apply_urls = [u for u in df["apply_url"] if isinstance(u, str) and u.strip()]

    # Online portal links written in the application text (see services/apply_mode.py)
    from services.apply_mode import classify
    online = [classify(t if isinstance(t, str) else None)["online_url"] for t in df["application_process"]]
    online = [u for u in online if u]

    # 1) every apply link + every online link
    cache = check_all(apply_urls + online, cache)
    # 2) the home page of every site whose link is a PDF or broken
    homes = []
    for u in apply_urls:
        c = cache.get(u, {})
        if c.get("result") == "broken" or (c.get("result") == "ok" and (DOCUMENT.search(u) or c.get("document"))):
            if h := site_home(c.get("final") or u):
                homes.append(h)
    cache = check_all(homes, cache)

    decisions = [decide(r, cache) for _, r in df.iterrows()]
    if not (PROJECT / "data" / "Schemes.backup.csv").exists():
        shutil.copy(CSV, PROJECT / "data" / "Schemes.backup.csv")
        print("Backup saved: data/Schemes.backup.csv")
    df["apply_url"] = [d[0] for d in decisions]
    df["link_status"] = [d[1] for d in decisions]
    df["original_apply_url"] = [d[2] for d in decisions]
    df["link_checked_at"] = datetime.now().strftime("%Y-%m-%d")
    df.to_csv(CSV, index=False)
    print("Saved: data/Schemes.csv")

    broken_online = sorted({u for u in online if cache.get(u, {}).get("result") == "broken"})
    BROKEN_TXT.write_text("\n".join(broken_online) + "\n", encoding="utf-8")
    print(f"{len(broken_online)} broken portal links from the application text -> data/broken_links.txt")

    try:
        update_database(df, broken_online)
    except Exception as e:
        print("Could not update the database:", e, "\nRun python database/import_schemes.py, then this script again.")
    report(df)


if __name__ == "__main__":
    main()
