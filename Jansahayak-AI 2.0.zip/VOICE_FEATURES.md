# JanSahayak AI – Voice Assistant

## Voice features added

The citizen AI scheme assistant now supports:
- Speech-to-text input using the browser Web Speech API.
- Separate English and Hindi voice-input selection.
- Text-to-speech playback for assistant replies.
- Existing chat API, conversation history, scheme matching and database behavior remain unchanged.

## How to use

1. Start JanSahayak AI using the same steps in `RUN_STEPS.md`.
2. Open the citizen dashboard in Google Chrome or Microsoft Edge.
3. Open **AI scheme assistant**.
4. Choose **English** or **हिंदी** beside the microphone.
5. Select the microphone button and allow microphone access when the browser asks.
6. Speak your question. The recognized text appears in the message box.
7. Review the transcription and press Send.
8. Press **Listen** below an assistant reply to hear it spoken aloud.

## Browser and language notes

- Voice input uses the browser's built-in Web Speech recognition. It is supported in current Chromium-based browsers such as Google Chrome and Microsoft Edge, but support can vary by browser and platform.
- Microphone access generally requires `localhost` or an HTTPS website and explicit browser permission.
- Hindi and English are selectable separately for recognition. For best results, speak in the selected language.
- Spoken replies use the browser's SpeechSynthesis voices. The available Hindi/English voices depend on the operating system and browser.
- Voice input and spoken replies are browser-side features; no new Python package or API key is required.
- If the microphone is unavailable, the existing typed chat continues to work normally.

## Privacy reminder

Speech recognition may be processed by the browser's speech service depending on browser and device settings. Do not speak or type Aadhaar numbers, bank details, OTPs, passwords, or other sensitive information into the assistant.

## Environment configuration in this ZIP

For safety, the original `.env` file (which contained credentials) is not included. Copy `.env.example` to `.env` and enter your own database password and AI API key. Keep `.env` private and never commit it to GitHub.
