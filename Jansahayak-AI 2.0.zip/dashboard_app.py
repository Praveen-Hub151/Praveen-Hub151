"""JanSahayak-AI web dashboard. Run from the project root with:
python -m uvicorn dashboard_app:app --reload --port 8000
Existing scheme tables and eligibility engine are read-only from this app.
"""
from __future__ import annotations

import base64
import hmac
import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException, Query, status
from fastapi.responses import FileResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from engine.db_rules import get_connection
from engine.scheme_matcher import match_schemes
from schemas.citizen_schema import CitizenProfile
from services.scheme_matcher import get_schemes_for_citizen
from agent.rule_based_extractor import extract_profile_with_reasons

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
FRONTEND_DIR = ROOT / "frontend"
FRONTEND_DIR.mkdir(exist_ok=True)

app = FastAPI(title="JanSahayak-AI Dashboard", version="1.0.0")
app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")
security = HTTPBasic(auto_error=False)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=3000)


class MatchRequest(BaseModel):
    age: Optional[int] = Field(default=None, ge=0, le=120)
    state: Optional[str] = None
    district: Optional[str] = None
    area: Optional[str] = None
    education: Optional[str] = None
    employment_status: Optional[str] = None
    annual_income: Optional[float] = Field(default=None, ge=0)
    category: Optional[str] = None
    gender: Optional[str] = None
    needs: list[str] = []
    is_farmer: Optional[bool] = None
    has_disability: Optional[bool] = None
    has_bpl_card: Optional[bool] = None
    has_bank_account: Optional[bool] = None
    has_aadhaar: Optional[bool] = None


def admin_auth(credentials: HTTPBasicCredentials | None = Depends(security)) -> str:
    """Protect admin APIs with credentials from .env; never hardcode passwords."""
    expected_user = os.getenv("ADMIN_USERNAME", "admin")
    expected_password = os.getenv("ADMIN_PASSWORD", "")
    if not expected_password:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Admin login is not configured. Add ADMIN_USERNAME and ADMIN_PASSWORD to .env, then restart.",
        )
    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Admin login required",
            headers={"WWW-Authenticate": "Basic"},
        )
    user_ok = hmac.compare_digest(credentials.username, expected_user)
    pass_ok = hmac.compare_digest(credentials.password, expected_password)
    if not (user_ok and pass_ok):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect admin username or password",
            headers={"WWW-Authenticate": "Basic"},
        )
    return credentials.username


def rows_as_dicts(cur):
    names = [c.name for c in cur.description]
    return [dict(zip(names, row)) for row in cur.fetchall()]


def json_safe(value):
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    return str(value)


@app.get("/", include_in_schema=False)
def home():
    index = FRONTEND_DIR / "index.html"
    if not index.exists():
        return {"message": "Dashboard UI missing. Put index.html in the frontend folder."}
    return FileResponse(index)


@app.get("/api/health")
def health():
    try:
        conn = get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM schemes")
                count = cur.fetchone()[0]
        finally:
            conn.close()
        return {"status": "ok", "database": "connected", "schemes": count}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Database connection failed: {type(exc).__name__}. Check .env and PostgreSQL.")


@app.get("/api/public-counts")
def public_counts():
    """Small public counters for the citizen landing page; no personal data."""
    try:
        conn = get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM eligibility_rules")
                rules = cur.fetchone()[0]
        finally:
            conn.close()
        return {"rules": rules}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Could not load public counters: {type(exc).__name__}")


@app.get("/api/dashboard/summary")
def dashboard_summary(_: str = Depends(admin_auth)):
    """Read-only metrics for admin dashboard."""
    try:
        conn = get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM schemes")
                scheme_count = cur.fetchone()[0]
                cur.execute("SELECT COUNT(*) FROM eligibility_rules")
                rule_count = cur.fetchone()[0]
                cur.execute("SELECT COUNT(*) FROM scheme_documents")
                document_count = cur.fetchone()[0]
                cur.execute("SELECT COUNT(*) FROM scheme_purposes")
                purpose_count = cur.fetchone()[0]
                cur.execute("SELECT level, COUNT(*) AS total FROM schemes GROUP BY level ORDER BY level")
                levels = rows_as_dicts(cur)
                cur.execute("SELECT COALESCE(NULLIF(state, ''), 'Central') AS state_name, COUNT(*) AS total FROM schemes GROUP BY 1 ORDER BY total DESC LIMIT 10")
                states = rows_as_dicts(cur)
                cur.execute("SELECT COALESCE(purpose, 'Uncategorised') AS purpose, COUNT(DISTINCT scheme_id) AS total FROM scheme_purposes GROUP BY 1 ORDER BY total DESC LIMIT 8")
                purposes = rows_as_dicts(cur)
                # Optional table: this project creates it only after a profile is saved.
                try:
                    cur.execute("SELECT COUNT(*) FROM citizen_profiles")
                    citizen_profiles = cur.fetchone()[0]
                except Exception:
                    conn.rollback()
                    citizen_profiles = 0
        finally:
            conn.close()
        return {"schemes": scheme_count, "rules": rule_count, "documents": document_count,
                "purpose_links": purpose_count, "citizen_profiles": citizen_profiles,
                "levels": json_safe(levels), "states": json_safe(states), "purposes": json_safe(purposes)}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Could not load admin metrics: {type(exc).__name__}")


@app.get("/api/schemes")
def search_schemes(
    q: str = Query(default="", max_length=200),
    state: str = Query(default="", max_length=100),
    level: str = Query(default="", max_length=20),
    limit: int = Query(default=20, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    clauses, params = [], []
    if q.strip():
        pattern = f"%{q.strip()}%"
        clauses.append("(s.scheme_name ILIKE %s OR COALESCE(s.description,'') ILIKE %s OR COALESCE(s.benefits,'') ILIKE %s OR COALESCE(s.ministry,'') ILIKE %s OR COALESCE(s.eligibility_text,'') ILIKE %s)")
        params.extend([pattern] * 5)
    if state.strip():
        clauses.append("(s.state ILIKE %s OR s.level = 'central')")
        params.append(state.strip())
    if level.strip() in ("central", "state"):
        clauses.append("s.level = %s")
        params.append(level.strip())
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    try:
        conn = get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT COUNT(*) FROM schemes s" + where, tuple(params))
                total = cur.fetchone()[0]
                cur.execute(
                    "SELECT s.scheme_id, s.scheme_name, s.level, s.state, s.ministry, s.description, s.benefits, s.eligibility_text, s.official_website, s.official_application_url FROM schemes s" + where + " ORDER BY s.scheme_name LIMIT %s OFFSET %s",
                    tuple(params + [limit, offset]),
                )
                results = rows_as_dicts(cur)
        finally:
            conn.close()
        return {"total": total, "limit": limit, "offset": offset, "items": json_safe(results)}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Scheme search failed: {type(exc).__name__}. Check database connection.")


@app.post("/api/citizen/match")
def citizen_match(payload: MatchRequest):
    try:
        data = payload.model_dump(exclude_none=True)
        profile = CitizenProfile(**data)
        conn = get_connection()
        try:
            results = get_schemes_for_citizen(profile, conn=conn, statuses=("eligible", "maybe", "needs_review"))
        finally:
            conn.close()
        counts = {name: sum(item.get("status") == name for item in results)
                  for name in ("eligible", "maybe", "needs_review")}
        return {"profile": profile.model_dump(exclude_none=True, mode="json"), "counts": counts,
                "items": json_safe(results[:30]), "total": len(results)}
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Could not match schemes: {type(exc).__name__}. Check profile values and database.")


@app.post("/api/chat")
def citizen_chat(payload: ChatRequest):
    """Uses the project's existing offline extractor + database eligibility engine."""
    try:
        profile, reasons = extract_profile_with_reasons(payload.message.strip())
        profile.need_text = payload.message.strip()
        conn = get_connection()
        try:
            results = get_schemes_for_citizen(profile, conn=conn, statuses=("eligible", "maybe", "needs_review"))
        finally:
            conn.close()
        counts = {name: sum(item.get("status") == name for item in results)
                  for name in ("eligible", "maybe", "needs_review")}
        top = results[:8]
        if not results:
            reply = "Abhi is message se matching schemes nahi mili. Apni state, age aur zaroorat (scholarship, job, housing, health, agriculture, pension ya loan) bata dein."
        else:
            reply = (f"Aapki baat se maine profile ke kuch details identify kiye. Database mein {len(results)} relevant scheme(s) mili: "
                     f"{counts['eligible']} eligible, {counts['maybe']} more details needed, aur {counts['needs_review']} manual review. "
                     "Neeche schemes aur official links dekhein. Eligibility final karne se pehle scheme ki official guidelines verify karein.")
        return {"reply": reply, "extracted": json_safe(profile.model_dump(exclude_none=True, mode="json")),
                "reasons": reasons, "counts": counts, "items": json_safe(top), "total": len(results)}
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Chat matching failed: {type(exc).__name__}. Check PostgreSQL connection and project dependencies.")


@app.get("/api/admin/check")
def admin_check(_: str = Depends(admin_auth)):
    return {"authenticated": True}
