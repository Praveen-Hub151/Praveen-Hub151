"""profile_store.py: saves each chat (profile + questions + answers).

Where it is saved:
    1. PostgreSQL table citizen_profiles (created automatically the first time)
    2. If the database can't be reached: a JSON file in data/profiles/<session_id>.json

Look at saved chats in pgAdmin:
    SELECT session_id, profile, conversation, updated_at
    FROM citizen_profiles ORDER BY updated_at DESC;
"""
import json
from datetime import datetime, timezone
from pathlib import Path

from engine.db_rules import get_connection

PROFILES_DIR = Path(__file__).resolve().parent.parent / "data" / "profiles"

CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS citizen_profiles (
    session_id    VARCHAR(100) PRIMARY KEY,   -- = CitizenProfile.citizen_id
    first_message TEXT,                       -- what the user typed first
    profile       JSONB NOT NULL,             -- the full CitizenProfile
    conversation  JSONB NOT NULL,             -- follow-up questions and answers
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
)"""


def save_profile(profile, conversation: list[dict], conn=None) -> str:
    """Save to PostgreSQL, or to a JSON file if that fails. Returns where it was saved."""
    profile_json = profile.model_dump(mode="json")
    try:
        own_conn = conn is None
        conn = conn or get_connection()
        with conn, conn.cursor() as cur:
            cur.execute(CREATE_TABLE)
            cur.execute(
                """INSERT INTO citizen_profiles (session_id, first_message, profile, conversation)
                   VALUES (%s, %s, %s, %s)
                   ON CONFLICT (session_id) DO UPDATE
                   SET profile = EXCLUDED.profile, conversation = EXCLUDED.conversation,
                       updated_at = now()""",
                (profile.citizen_id, profile.need_text,
                 json.dumps(profile_json, ensure_ascii=False),
                 json.dumps(conversation, ensure_ascii=False)),
            )
        if own_conn:
            conn.close()
        return "PostgreSQL table citizen_profiles"
    except Exception:
        PROFILES_DIR.mkdir(parents=True, exist_ok=True)
        path = PROFILES_DIR / f"{profile.citizen_id}.json"
        path.write_text(json.dumps({
            "session_id": profile.citizen_id,
            "first_message": profile.need_text,
            "profile": profile_json,
            "conversation": conversation,
            "saved_at": datetime.now(timezone.utc).isoformat(),
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)


def load_profile(session_id: str, conn=None) -> dict | None:
    """Read a saved chat back (database first, then the JSON file)."""
    try:
        own_conn = conn is None
        conn = conn or get_connection()
        with conn.cursor() as cur:
            cur.execute("SELECT profile, conversation FROM citizen_profiles WHERE session_id = %s",
                        (session_id,))
            row = cur.fetchone()
        if own_conn:
            conn.close()
        if row:
            return {"profile": row[0], "conversation": row[1]}
    except Exception:
        pass
    path = PROFILES_DIR / f"{session_id}.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return None
