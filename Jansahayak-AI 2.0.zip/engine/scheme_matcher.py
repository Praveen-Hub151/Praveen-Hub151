"""scheme_matcher.py: finds every scheme a citizen may qualify for.

db_rules.py checks ONE scheme. This file checks ALL schemes at once:

    CitizenProfile
        -> load schemes (filtered by the citizen's needs) + their rules from PostgreSQL
        -> check each scheme with the eligibility engine
        -> eligible / maybe (with missing info) / not_eligible / no_rules

Run from the JanSahayak-AI folder:
    python engine/scheme_matcher.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from schemas.citizen_schema import CitizenProfile
from schemas.eligibility_schema import EligibilityRule, Result, check_rule
from engine.eligibility_engine import evaluate_eligibility
from engine.db_rules import get_connection


def load_schemes(conn, needs: list[str]) -> list[dict]:
    """All schemes, or only those that help with one of the citizen's needs."""
    sql = """SELECT scheme_id, scheme_name, level, state, official_website,
                    official_application_url, beneficiary_type
             FROM schemes"""
    params = ()
    if needs:
        sql += """ WHERE scheme_id IN (SELECT scheme_id FROM scheme_purposes
                                       WHERE purpose = ANY(%s))"""
        params = (needs,)
    with conn.cursor() as cur:
        cur.execute(sql + " ORDER BY scheme_name", params)
        columns = [c.name for c in cur.description]
        return [dict(zip(columns, row)) for row in cur.fetchall()]


def load_rules_for(conn, scheme_ids: list[str]) -> dict[str, list[EligibilityRule]]:
    """Rules of many schemes in ONE query, grouped as {scheme_id: [rules]}."""
    rules: dict[str, list[EligibilityRule]] = {sid: [] for sid in scheme_ids}
    with conn.cursor() as cur:
        cur.execute(
            """SELECT rule_id, scheme_id, field, operator, value, required,
                      condition_group, description
               FROM eligibility_rules WHERE scheme_id = ANY(%s) ORDER BY rule_id""",
            (scheme_ids,),
        )
        for rule_id, sid, field, operator, value, required, group, desc in cur.fetchall():
            rules[sid].append(EligibilityRule(
                rule_id=rule_id, scheme_id=sid, field=field, operator=operator,
                value=value, required=required, condition_group=group,
                description=desc or "",
            ))
    return rules


def missing_fields(rules: list[EligibilityRule], citizen: dict) -> list[str]:
    """Citizen fields we still need to ask about to decide a "maybe" scheme."""
    groups: dict = {}
    for rule in rules:
        if rule.required:
            groups.setdefault(rule.condition_group, []).append(rule)
    missing = []
    for group_rules in groups.values():
        results = [check_rule(r, citizen) for r in group_rules]
        if Result.passed in results:
            continue                            # group already satisfied
        for rule, result in zip(group_rules, results):
            if result == Result.unknown and rule.field not in missing:
                missing.append(rule.field)
    return missing


POPULAR_CSV = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "popular_schemes.csv")
_popular = None


def popular_schemes() -> dict[str, list[str]]:
    """data/popular_schemes.csv: well-known schemes (shown first) and the names people use for them."""
    global _popular
    if _popular is None:
        import csv
        _popular = {}
        if os.path.exists(POPULAR_CSV):
            with open(POPULAR_CSV, encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    if row.get("scheme_id"):
                        _popular[row["scheme_id"].strip()] = [a.strip().lower() for a in
                                                              (row.get("aliases") or "").split(";") if a.strip()]
    return _popular


PERSON_TYPES = ("individual", "family")

# Words in a scheme's NAME that show it is really about the need (not just tagged with it)
NEED_WORDS = {
    "employment": ["employment", "rozgar", "rojgar", "job", "kaushal", "skill", "livelihood", "internship", "nrega"],
    "skill_training": ["skill", "kaushal", "training", "apprentice"],
    "loan": ["loan", "credit", "mudra", "svanidhi", "finance", "rin", "stand-up"],
    "housing": ["awas", "awaas", "housing", "house", "griha", "ghar"],
    "education": ["scholarship", "education", "student", "shiksha", "vidya"],
    "health": ["health", "arogya", "medical", "ayushman", "bima", "insurance", "treatment"],
    "pension": ["pension", "maandhan", "maan-dhan"],
    "agriculture": ["kisan", "krishi", "farmer", "farm", "agri", "fasal", "crop", "irrigation"],
    "land": ["land", "bhoomi", "bhumi"],
}


def relevance(scheme: dict, rules: list[EligibilityRule], citizen: dict) -> int:
    """Higher = shown earlier. Before this, lists were A-Z, so 'Agnipath' and 'Agri-Clinics'
    came first for almost every person.
        + 60  the scheme's name is about what the person asked for (loan, pension, awas ...)
        + 50  well-known scheme (data/popular_schemes.csv), e.g. MGNREGA, PM-KISAN
        + 30  state scheme of the person's own state
        + 10  for every rule the person actually passed, except "lives in state X"
              (a scheme that checks age + income + category fits better than one with no checks)
        - 40  only for organisations (NGO, company, institution), not for a person or family
    """
    score = 50 if scheme["scheme_id"] in popular_schemes() else 0
    name = scheme["scheme_name"].lower()
    needs = [getattr(n, "value", n) for n in citizen.get("needs") or []]
    if any(w in name for n in needs for w in NEED_WORDS.get(n, [])):
        score += 60
    if scheme.get("state") and scheme["state"] == citizen.get("state"):
        score += 30
    score += 10 * sum(1 for r in rules if r.field != "state" and check_rule(r, citizen) == Result.passed)
    who = (scheme.get("beneficiary_type") or "").lower()
    if who and not any(t in who for t in PERSON_TYPES):
        score -= 40
    return score


def match_schemes(conn, citizen: CitizenProfile) -> dict[str, list[dict]]:
    """Sort every relevant scheme into eligible / maybe / not_eligible / no_rules."""
    needs = [n.value for n in citizen.needs]
    schemes = load_schemes(conn, needs)
    rules_by_scheme = load_rules_for(conn, [s["scheme_id"] for s in schemes])
    citizen_dict = citizen.model_dump()

    results = {"eligible": [], "maybe": [], "not_eligible": [], "no_rules": []}
    for scheme in schemes:
        rules = rules_by_scheme[scheme["scheme_id"]]
        if scheme["state"] and citizen.state and scheme["state"] != citizen.state:
            # A state scheme for another state, even if it has no written rules
            results["not_eligible"].append(scheme)
            continue
        if not rules:
            # No structured rules: the agent must read the eligibility text later.
            results["no_rules"].append(scheme)
            continue
        status = evaluate_eligibility(citizen_dict, rules)
        if status == "maybe":
            scheme = {**scheme, "missing": missing_fields(rules, citizen_dict)}
        results[status].append(scheme)

    # Most relevant first (not A-Z); ties stay alphabetical
    for status, items in results.items():
        items.sort(key=lambda sc: -relevance(sc, rules_by_scheme[sc["scheme_id"]], citizen_dict))
    return results


if __name__ == "__main__":
    sys.stdout.reconfigure(errors="replace")   # some scheme names have special characters

    # "mai 23 saal ka hoon gaon mai rehta hu mujhe kaam chahiye" (Bihar)
    citizen = CitizenProfile(
        age=23,
        area="rural",
        state="Bihar",
        employment_status="unemployed",
        needs=["employment"],
    )
    print("Citizen:", citizen.model_dump(exclude_none=True, exclude={"citizen_id"}, mode="json"))

    conn = get_connection()
    results = match_schemes(conn, citizen)
    conn.close()

    for status in ("eligible", "maybe", "not_eligible", "no_rules"):
        schemes = results[status]
        print(f"\n{status.upper()} ({len(schemes)})")
        for s in schemes[:10]:
            extra = f"   missing: {', '.join(s['missing'])}" if s.get("missing") else ""
            print(f"  - {s['scheme_name'][:70]}{extra}")
        if len(schemes) > 10:
            print(f"  ... and {len(schemes) - 10} more")
