"""eligibility_engine.py: checks one citizen against one scheme's rules.

The real rule logic lives in schemas/eligibility_schema.py (check_rule and
check_rules). This file only prepares the input and calls it.
"""
from pydantic import BaseModel

from schemas.eligibility_schema import EligibilityRule, check_rules


def evaluate_eligibility(citizen, rules: list[EligibilityRule]) -> str:
    """Returns "eligible", "not_eligible" or "maybe".

    citizen can be a CitizenProfile or a plain dict.
    """
    if not rules:
        return "maybe"                      # no rules known, can't decide

    if isinstance(citizen, BaseModel):      # check_rules expects a dict
        citizen = citizen.model_dump()

    return check_rules(rules, citizen)
