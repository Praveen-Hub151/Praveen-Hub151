"""db_rules.py: loads a scheme and its eligibility rules from PostgreSQL.

Before (stage 1):  rules came from data/test_schemes.py (fake, typed by hand)
Now   (stage 3):   rules come from the eligibility_rules table in jansahayak_db

The rule checking itself does not change: it is still check_rules() from
schemas/eligibility_schema.py, called through engine/eligibility_engine.py.
"""
import os
from pathlib import Path

import psycopg2
from dotenv import load_dotenv

from schemas.eligibility_schema import EligibilityRule
from engine.eligibility_engine import evaluate_eligibility

PROJECT_DIR = Path(__file__).resolve().parent.parent


def connection_settings() -> dict:
    """Connection details from .env. DATABASE_URL (what Render and most hosts give you)
    wins over DB_HOST / DB_PORT / DB_NAME / DB_USER / DB_PASSWORD."""
    load_dotenv(PROJECT_DIR / ".env")
    url = os.getenv("DATABASE_URL")
    if url:
        kwargs = {"dsn": url}
        if os.getenv("DB_SSLMODE"):
            kwargs["sslmode"] = os.getenv("DB_SSLMODE")
        return kwargs
    kwargs = {
        "host": os.getenv("DB_HOST", "localhost"),
        "port": os.getenv("DB_PORT", "5432"),
        "dbname": os.getenv("DB_NAME", "jansahayak_db"),
        "user": os.getenv("DB_USER", "postgres"),
        "password": os.getenv("DB_PASSWORD", ""),
    }
    if os.getenv("DB_SSLMODE"):
        kwargs["sslmode"] = os.getenv("DB_SSLMODE")   # e.g. "require" for a hosted database
    return kwargs


def get_connection():
    """Open a connection using the details in the .env file."""
    return psycopg2.connect(**connection_settings())


def load_scheme(conn, scheme_id: str) -> dict | None:
    """Basic details of one scheme, or None if the scheme_id doesn't exist."""
    with conn.cursor() as cur:
        cur.execute(
            """SELECT scheme_id, scheme_name, level, state, official_website,
                      official_application_url
               FROM schemes WHERE scheme_id = %s""",
            (scheme_id,),
        )
        row = cur.fetchone()
        if row is None:
            return None
        columns = [c.name for c in cur.description]
        return dict(zip(columns, row))


def load_rules(conn, scheme_id: str) -> list[EligibilityRule]:
    """All eligibility rules of one scheme, as EligibilityRule objects."""
    with conn.cursor() as cur:
        cur.execute(
            """SELECT rule_id, scheme_id, field, operator, value, required,
                      condition_group, description
               FROM eligibility_rules WHERE scheme_id = %s ORDER BY rule_id""",
            (scheme_id,),
        )
        rules = []
        for rule_id, sid, field, operator, value, required, group, desc in cur.fetchall():
            rules.append(EligibilityRule(
                rule_id=rule_id,
                scheme_id=sid,
                field=field,
                operator=operator,      # text like ">=" becomes Operator.gte
                value=value,            # JSONB comes back as 18, "rural", ["sc", "st"]
                required=required,
                condition_group=group,
                description=desc or "",
            ))
        return rules


def check_scheme(conn, citizen, scheme_id: str) -> str:
    """Load a scheme's rules from the database and check the citizen."""
    rules = load_rules(conn, scheme_id)
    return evaluate_eligibility(citizen, rules)
