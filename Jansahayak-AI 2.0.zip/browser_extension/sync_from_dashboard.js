/* Runs only on your JanSahayak dashboard (127.0.0.1 / localhost, or your Render site).
   If Render gave your site a different address, change the https:// line in manifest.json to it.
   Never use a wildcard like *.onrender.com: any site there could then feed the extension data.
   Copies the details you verified on a scheme page into the extension's storage,
   so the extension can fill the official form later. Nothing is sent anywhere. */
"use strict";

const KEY = "jansahayak.autofill.v1";

function syncNow() {
  let data = null;
  try { data = JSON.parse(localStorage.getItem(KEY) || "null"); } catch (e) { data = null; }
  if (!data || !data.fields) return;
  chrome.storage.local.set({ [KEY]: data });
}

// Only act on pages that are the JanSahayak dashboard
if (document.querySelector('meta[name="api-base"]')) {
  syncNow();
  window.addEventListener("message", (e) => {
    if (e.source === window && e.data && e.data.source === "jansahayak-dashboard" && e.data.type === "autofill-updated") {
      syncNow();
    }
  });
}
