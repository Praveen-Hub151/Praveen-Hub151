"use strict";

const KEY = "jansahayak.autofill.v1";
const who = document.getElementById("who");
const fillBtn = document.getElementById("fill");

chrome.storage.local.get(KEY, (store) => {
  const data = store[KEY];
  if (!data || !data.fields || !Object.keys(data.fields).length) {
    who.textContent = "No details yet. In the JanSahayak dashboard, open a scheme, upload your documents and click "
      + "\"Verify documents\" (with the dashboard open in this browser).";
    fillBtn.disabled = true;
    return;
  }
  const f = data.fields;
  who.textContent = "";
  const b = document.createElement("b");
  b.textContent = f.name || "Saved profile";
  who.append(b, document.createElement("br"),
    `Scheme: ${data.scheme_name || "—"}`, document.createElement("br"),
    `${Object.keys(f).length} details saved on ${new Date(data.saved_at).toLocaleDateString()}`);
});

fillBtn.addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  try {
    // fill.js: the matching logic; run.js: loads the saved details and starts it
    await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, files: ["fill.js", "run.js"] });
    window.close();
  } catch (e) {
    who.textContent = "This page cannot be filled (Chrome blocks extensions on some pages, e.g. the Chrome Web Store). " + e.message;
  }
});

document.getElementById("clear").addEventListener("click", () => {
  chrome.storage.local.remove([KEY, "jansahayak.extra.v1"], () => { who.textContent = "Saved details removed."; fillBtn.disabled = true; });
});
