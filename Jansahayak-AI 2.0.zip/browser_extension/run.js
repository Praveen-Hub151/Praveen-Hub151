/* Loads your saved details from the extension's storage and starts filling (see fill.js). */
"use strict";

(function () {
  const KEY = "jansahayak.autofill.v1";
  const EXTRA = "jansahayak.extra.v1";     // mobile / email you chose to remember
  chrome.storage.local.get([KEY, EXTRA], (store) => {
    const data = store[KEY];
    if (!data || !data.fields) return;
    const fields = Object.assign({}, data.fields, store[EXTRA] || {});
    window.JanSahayakFill.run(fields, {
      remember(values) { chrome.storage.local.set({ [EXTRA]: Object.assign({}, store[EXTRA] || {}, values) }); },
      onlyTopFrameShowsPanel: window.top === window,
    });
  });
})();
