/* JanSahayak AI Autofill: fills an application form on the current page.

   How it decides what a box is: it reads the box's label, placeholder, name, id and the text
   next to it, and matches words like "Father's name", "Date of birth", "IFSC", "मोबाइल".
   What it never does: it never fills password / OTP / captcha boxes, never clicks Submit and
   never submits the form. Aadhaar and bank account numbers are only kept as their last 4
   digits, so it asks you to type the full number.
   Anything the form needs that we don't know (mobile, email, disability ...) is asked in a
   small panel, with the form's own options when the box is a list or Yes/No choice. */
"use strict";

(function () {
  if (window.JanSahayakFill) return;          // injected twice: keep the first copy

  // key -> words that identify the box (checked top to bottom; more specific first)
  const KEYS = [
    ["skip", /captcha|otp|one[\s-]?time|password|passcode|verification code|security code|user\s*name|login id|user id/],
    ["income_certificate_no", /income\s*certificate\s*(no|number|num)/],
    ["father_name", /father|husband|guardian|spouse|पिता|पति|अभिभावक/],
    ["aadhaar", /aadha?a?r|\buid\b|आधार/],
    ["account_number", /account\s*(no|number|num)|a\/c\s*(no|number)?|bank\s*account|खाता/],
    ["ifsc", /ifsc/],
    ["bank_name", /bank\s*name|name of (the )?bank|bank\b|बैंक/],
    ["mobile", /mobile|phone|contact\s*(no|number)|मोबाइल|फ़ोन|फोन/],
    ["email", /e-?mail|ई-?मेल/],
    ["dob", /date of birth|\bdob\b|birth\s*date|जन्म/],
    ["age", /\bage\b|आयु|उम्र/],
    ["gender", /gender|\bsex\b|लिंग/],
    ["category", /category|caste|social group|जाति|वर्ग/],
    ["disability", /disab|divyang|handicap|pwd|दिव्यांग|विकलांग/],
    ["marital_status", /marital|विवाह/],
    ["pincode", /pin\s*code|pincode|postal|zip|पिन/],
    ["district", /district|जिला|ज़िला/],
    ["state", /\bstate\b|राज्य/],
    ["address", /address|पता/],
    ["annual_income", /income|आय|आमदनी/],
    ["area", /rural|urban|area type|locality type|ग्रामीण|शहरी/],
    ["name", /name|नाम/],
  ];
  const ASK_TEXT = {
    mobile: "Your mobile number (linked to Aadhaar)", email: "Your email ID", aadhaar: "Your full 12-digit Aadhaar number",
    account_number: "Your full bank account number", disability: "Do you have a disability?", gender: "Gender",
    category: "Your category", marital_status: "Marital status", district: "Your district", dob: "Date of birth",
    age: "Your age", name: "Your full name", father_name: "Father's / husband's name", address: "Your address",
    pincode: "PIN code", state: "State", annual_income: "Yearly family income (Rs)", ifsc: "IFSC code",
    bank_name: "Bank name", area: "Rural or urban?", income_certificate_no: "Income certificate number",
  };
  const REMEMBER_OK = new Set(["mobile", "email"]);   // never stored: Aadhaar and account numbers

  const norm = (s) => (s || "").replace(/\s+/g, " ").trim().toLowerCase();

  function visible(el) {
    if (el.disabled || el.readOnly) return false;
    const st = getComputedStyle(el);
    return st.display !== "none" && st.visibility !== "hidden" && el.getClientRects().length > 0;
  }

  /** All the text that describes a box: label, aria, placeholder, name, id, text before it. */
  function describe(el) {
    const parts = [];
    if (el.labels) el.labels.forEach((l) => parts.push(l.innerText));
    parts.push(el.getAttribute("aria-label"), el.placeholder, el.name, el.id, el.title);
    const by = el.getAttribute("aria-labelledby");
    if (by) by.split(/\s+/).forEach((id) => { const n = document.getElementById(id); if (n) parts.push(n.innerText); });
    const cell = el.closest("td, .form-group, .col, div");
    if (cell) {
      const prev = cell.previousElementSibling;
      if (prev && prev.innerText && prev.innerText.length < 80) parts.push(prev.innerText);
    }
    if (el.type === "radio" || el.type === "checkbox") {
      const fs = el.closest("fieldset");
      if (fs && fs.querySelector("legend")) parts.push(fs.querySelector("legend").innerText);
      const group = el.closest(".form-group, tr, p, div");
      if (group && group.innerText.length < 120) parts.push(group.innerText);
    }
    return norm(parts.filter(Boolean).join(" | ").replace(/[_\-]+/g, " "));
  }

  function matchKey(text) {
    for (const [key, re] of KEYS) if (re.test(text)) return key;
    return null;
  }

  /** Form controls on the page, radio buttons grouped by name. */
  function controls() {
    const out = [], radios = {};
    document.querySelectorAll("input, select, textarea").forEach((el) => {
      const t = (el.type || "").toLowerCase();
      if (["hidden", "submit", "button", "image", "reset", "file", "password"].includes(t) || !visible(el)) return;
      if (t === "radio") { (radios[el.name || el.id] = radios[el.name || el.id] || []).push(el); return; }
      out.push({ kind: el.tagName === "SELECT" ? "select" : t === "checkbox" ? "checkbox" : "text", el, els: [el], text: describe(el) });
    });
    Object.values(radios).forEach((els) => out.push({ kind: "radio", el: els[0], els, text: describe(els[0]) }));
    return out;
  }

  function optionLabel(o) { return norm(o.label || o.innerText || o.value); }

  function radioLabel(r) {
    const l = (r.labels && r.labels[0] && r.labels[0].innerText) || (r.nextSibling && r.nextSibling.textContent) || r.value;
    return norm(l);
  }

  function choices(c) {
    if (c.kind === "select") return [...c.el.options].filter((o) => o.value !== "" && !/^-+|select|choose|चुन/i.test(o.text)).map((o) => o.text.trim());
    if (c.kind === "radio") return c.els.map((r) => radioLabel(r)).filter(Boolean);
    if (c.kind === "checkbox") return ["Yes", "No"];
    return null;
  }

  const SYN = { female: ["female", "f", "महिला", "स्त्री"], male: ["male", "m", "पुरुष"], yes: ["yes", "y", "हाँ", "हां", "true"],
                no: ["no", "n", "नहीं", "false"], rural: ["rural", "village", "ग्रामीण"], urban: ["urban", "city", "शहरी"] };

  function fits(optionText, value) {
    const o = norm(optionText), v = norm(String(value));
    if (!o || !v) return false;
    if (o === v) return true;
    for (const words of Object.values(SYN)) if (words.includes(v) && words.includes(o)) return true;
    // whole words only: "male" must not match "female"
    const word = (a, b) => new RegExp(`(^|[^a-z\\u0900-\\u097f])${a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}($|[^a-z\\u0900-\\u097f])`).test(b);
    if (v.length > 2 && (word(v, o) || (o.length > 2 && word(o, v)))) return true;
    return false;
  }

  function setNative(el, value) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : el.tagName === "SELECT" ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    setter.call(el, value);                     // works with React / Angular forms too
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function toDateInput(v) {                        // 12/03/2004 -> 2004-03-12
    const m = String(v).match(/(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})/);
    return m ? `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}` : null;
  }

  function valueFor(key, f) {
    const map = { aadhaar: f.aadhaar_full, account_number: f.account_number_full,
                  disability: f.has_disability === true ? "Yes" : f.has_disability === false ? "No" : f.disability };
    let v = key in map ? map[key] : f[key];
    if (v === undefined || v === null || v === "") return null;
    if (String(v).includes("XXXX")) return null;   // masked: the person must type it
    return String(v);
  }

  /** Put one value into a box. Returns true if it worked. */
  function put(c, key, value) {
    const el = c.el;
    if (c.kind === "select") {
      const opt = [...el.options].find((o) => fits(o.text, value) || fits(o.value, value));
      if (!opt) return false;
      setNative(el, opt.value);
      return true;
    }
    if (c.kind === "radio") {
      const r = c.els.find((x) => fits(radioLabel(x), value) || fits(x.value, value));
      if (!r) return false;
      r.click();                                    // selects the option (never a submit button)
      return true;
    }
    if (c.kind === "checkbox") {
      const want = fits("yes", value);
      if (el.checked !== want) el.click();
      return true;
    }
    if (el.type === "date") { const d = toDateInput(value); if (!d) return false; setNative(el, d); return true; }
    if (key === "mobile") value = value.replace(/\D/g, "").slice(-10);
    if (key === "aadhaar" || key === "account_number") value = value.replace(/\s/g, "");
    if (el.maxLength > 0 && value.length > el.maxLength) value = value.slice(0, el.maxLength);
    setNative(el, value);
    return true;
  }

  function mark(c, state) {
    const colors = { filled: "#16a34a", ask: "#d97706", check: "#d97706" };
    c.els.forEach((e) => {
      e.style.outline = `2px ${state === "check" ? "dashed" : "solid"} ${colors[state]}`;
      e.style.outlineOffset = "2px";
      e.title = state === "filled" ? "Filled by JanSahayak AI: please check" : "JanSahayak AI could not fill this: please fill it yourself";
    });
  }

  function empty(c) {
    if (c.kind === "radio") return !c.els.some((r) => r.checked);
    if (c.kind === "checkbox") return true;
    return !c.el.value || (c.kind === "select" && c.el.selectedIndex <= 0);
  }

  // ------------------------------------------------------------------ the question panel
  function panel(questions, summary, onFill) {
    document.getElementById("jansahayak-panel")?.remove();
    const host = document.createElement("div");
    host.id = "jansahayak-panel";
    host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `<style>
      .p{width:340px;max-height:80vh;overflow:auto;background:#fff;border-radius:14px;box-shadow:0 10px 40px rgba(15,23,42,.3);
         font:14px/1.4 Segoe UI,Arial,sans-serif;color:#0f172a;border:1px solid #e2e8f0}
      .h{background:#2563eb;color:#fff;padding:10px 14px;font-weight:700;display:flex;justify-content:space-between;align-items:center}
      .h button{background:none;border:0;color:#fff;font-size:18px;cursor:pointer}
      .b{padding:12px 14px} .s{font-size:13px;color:#334155;margin:0 0 10px}
      .q{margin:0 0 12px} .q label{display:block;font-weight:600;margin:0 0 4px}
      .q input[type=text],.q select{width:100%;box-sizing:border-box;padding:7px 9px;border:1px solid #cbd5e1;border-radius:8px;font-size:14px}
      .opts{display:flex;flex-wrap:wrap;gap:6px} .opts label{font-weight:500;border:1px solid #cbd5e1;border-radius:20px;padding:4px 10px;cursor:pointer}
      .rem{font-size:12px;color:#475569;font-weight:400;margin-top:4px}
      .go{width:100%;padding:9px;border:0;border-radius:8px;background:#2563eb;color:#fff;font-weight:700;cursor:pointer}
      .n{font-size:12px;color:#64748b;margin-top:8px}</style>
      <div class="p" role="dialog" aria-label="JanSahayak AI autofill"><div class="h">JanSahayak AI<button title="Close" id="x">×</button></div>
      <div class="b"><p class="s" id="sum"></p><form id="f"></form>
      <p class="n">You do the login, OTP, captcha and the final <b>Submit</b>. Check every value before submitting.</p></div></div>`;
    root.getElementById("sum").textContent = summary;
    const form = root.getElementById("f");
    questions.forEach((q, i) => {
      const box = document.createElement("div");
      box.className = "q";
      const lab = document.createElement("label");
      lab.textContent = ASK_TEXT[q.key] || q.key;
      box.appendChild(lab);
      if (q.options && q.options.length && q.options.length <= 8) {
        const wrap = document.createElement("div");
        wrap.className = "opts";
        q.options.forEach((o) => {
          const l = document.createElement("label");
          const r = document.createElement("input");
          r.type = "radio"; r.name = "q" + i; r.value = o;
          l.append(r, " " + o);
          wrap.appendChild(l);
        });
        box.appendChild(wrap);
      } else if (q.options && q.options.length) {
        const sel = document.createElement("select");
        sel.name = "q" + i;
        sel.append(new Option("Choose…", ""), ...q.options.map((o) => new Option(o, o)));
        box.appendChild(sel);
      } else {
        const inp = document.createElement("input");
        inp.type = "text"; inp.name = "q" + i; inp.autocomplete = "off";
        if (q.key === "mobile") { inp.inputMode = "numeric"; inp.maxLength = 10; }
        box.appendChild(inp);
      }
      if (REMEMBER_OK.has(q.key)) {
        const rem = document.createElement("label");
        rem.className = "rem";
        const cb = document.createElement("input");
        cb.type = "checkbox"; cb.name = "r" + i;
        rem.append(cb, " Remember on this computer");
        box.appendChild(rem);
      }
      form.appendChild(box);
    });
    if (questions.length) {
      const go = document.createElement("button");
      go.type = "submit"; go.className = "go"; go.textContent = "Fill these in the form";
      form.appendChild(go);
    }
    form.addEventListener("submit", (e) => {           // the PANEL's own button, not the page's form
      e.preventDefault();
      const answers = {};
      const remember = {};
      questions.forEach((q, i) => {
        const el = form.querySelector(`[name="q${i}"]:checked`) || form.querySelector(`input[type=text][name="q${i}"], select[name="q${i}"]`);
        const v = el && el.value.trim();
        if (v) {
          answers[q.key] = v;
          const cb = form.querySelector(`[name="r${i}"]`);
          if (cb && cb.checked) remember[q.key] = v;
        }
      });
      onFill(answers, remember);
    });
    root.getElementById("x").addEventListener("click", () => host.remove());
    document.documentElement.appendChild(host);
    return { setSummary: (t) => { root.getElementById("sum").textContent = t; } };
  }

  // ------------------------------------------------------------------ main
  function run(fields, opts = {}) {
    const all = controls();
    if (!all.length) return { filled: 0, asked: 0, skipped: 0 };
    const filled = [], ask = [], left = [];
    const used = new Set();
    for (const c of all) {
      const key = matchKey(c.text);
      if (key === "skip") continue;                    // password / OTP / captcha: always the person's job
      if (!key) { if (empty(c)) { mark(c, "check"); left.push(c); } continue; }
      if (!empty(c) && c.kind !== "checkbox") { used.add(c); continue; }   // never overwrite what's there
      const v = valueFor(key, fields);
      if (v !== null && put(c, key, v)) { mark(c, "filled"); filled.push(c); continue; }
      mark(c, "ask");
      ask.push({ key, c, options: choices(c) });
    }
    // one question per key (e.g. two "mobile" boxes get the same answer)
    const questions = [];
    const byKey = {};
    ask.forEach((a) => { if (!byKey[a.key]) { byKey[a.key] = []; questions.push(a); } byKey[a.key].push(a); });

    const summary = () => `Filled ${filled.length} box${filled.length === 1 ? "" : "es"}` +
      (questions.length ? `. ${questions.length} question${questions.length === 1 ? "" : "s"} below.` : ".") +
      (left.length ? ` ${left.length} other box${left.length === 1 ? "" : "es"} (dashed orange) are for you.` : "");
    const ui = panel(questions, summary(), (answers, remember) => {
      Object.entries(answers).forEach(([key, v]) => (byKey[key] || []).forEach((a) => {
        if (put(a.c, key, v)) { mark(a.c, "filled"); filled.push(a.c); }
      }));
      if (opts.remember && Object.keys(remember).length) opts.remember(remember);
      ui.setSummary(summary() + " Now check everything, then do the captcha / OTP and press Submit yourself.");
    });
    return { filled: filled.length, asked: questions.length, left: left.length, keys: filled.map((c) => matchKey(c.text)) };
  }

  window.JanSahayakFill = { run, describe, matchKey };
})();
