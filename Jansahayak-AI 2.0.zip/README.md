# JanSahayak AI

**An AI-assisted government-scheme discovery platform** that helps citizens describe their needs, build a profile, check scheme eligibility, and review benefits, required documents, and official application links.

JanSahayak AI includes a citizen-facing web dashboard, Hindi/English voice input, document-assisted profile extraction, a PostgreSQL-backed eligibility engine, an admin dashboard, and an optional Chrome autofill extension.

> **Important:** This is an informational prototype, not a government service or an eligibility approval authority. Scheme rules and links can change. Users should verify all details with the relevant official department before applying.

## Features

- **Citizen profile extraction:** Extracts useful profile details from a citizen's message.
- **Scheme matching:** Matches profile data against the eligibility rules stored in PostgreSQL.
- **Follow-up questions:** Asks for missing information to improve matching.
- **Scheme details:** Displays benefits, required documents, and application links where available.
- **Document-assisted profile creation:** Reads supported PDF, image, and text documents and proposes profile fields for citizen review.
- **Hindi and English voice interface:** Browser-based speech recognition and spoken responses where supported.
- **Dashboard and API:** FastAPI-based citizen interface, admin interface, and API documentation.
- **Optional browser extension:** Helps autofill supported web forms; it does not automatically submit forms.
- **Terminal assistant:** An optional command-line flow is available through `main.py`.

## Technology stack

| Area | Technologies |
|---|---|
| Backend/API | Python, FastAPI, Uvicorn |
| Data validation | Pydantic |
| Database | PostgreSQL, psycopg2 |
| Data processing | pandas |
| Document extraction/OCR | pdfplumber, Tesseract OCR, pytesseract, OpenCV, Pillow |
| AI responses | Optional Groq API integration |
| Frontend | HTML, CSS, JavaScript, Web Speech API |
| Browser extension | Chrome Extension APIs |
| Deployment | Docker, Render Blueprint |

## Project structure

```text
JanSahayak-AI/
├── agent/                 # Profile extraction and follow-up questions
├── browser_extension/     # Optional Chrome autofill extension
├── dashboard/             # FastAPI dashboard, routes, auth and database access
├── data/                  # Scheme datasets and supporting data files
├── database/              # SQL schema and scheme-data importer
├── deploy/                # Deployment startup scripts
├── documents/             # Document reading, OCR and profile extraction
├── engine/                # Eligibility rules, scheme matching and profile storage
├── frontend/              # Citizen-facing web interface
├── schemas/               # Pydantic data schemas
├── scripts/               # Setup and administration utilities
├── services/              # Scheme and document services
├── tests/                 # Automated tests and sample documents
├── main.py                # Optional terminal assistant
├── run_dashboard.py       # Local dashboard launcher
├── requirements.txt
├── requirements-dashboard.txt
├── Dockerfile
└── render.yaml
```

## Getting started (Windows 10/11)

### 1. Prerequisites

Install:

- Python **3.11 or 3.12** (64-bit)
- PostgreSQL **14 or newer**
- Tesseract OCR for image/scanned-PDF extraction (optional for text-based PDFs and TXT files)

For Hindi OCR, install the Hindi language data for Tesseract as well.

### 2. Create a virtual environment

Open PowerShell in the extracted repository folder (the folder containing `main.py`):

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

If PowerShell blocks activation in the current terminal:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

### 3. Install dependencies

```powershell
python -m pip install -r requirements.txt -r requirements-dashboard.txt
```

### 4. Configure environment variables

Copy the example file:

```powershell
Copy-Item .env.example .env
```

Edit `.env` and enter your local PostgreSQL credentials:

```dotenv
DB_HOST=localhost
DB_PORT=5432
DB_NAME=jansahayak_db
DB_USER=postgres
DB_PASSWORD=YOUR_POSTGRES_PASSWORD
```

Optional AI assistant configuration:

```dotenv
GROQ_API_KEY=YOUR_GROQ_API_KEY
GROQ_MODEL=llama-3.3-70b-versatile
```

Additional dashboard/admin options are documented in `.env.dashboard.example`. Generate an admin password hash with:

```powershell
python scripts/hash_admin_password.py
```

Never commit `.env`, passwords, API keys, or production secrets.

### 5. Create the database and import scheme data

Create a PostgreSQL database named `jansahayak_db`, then run:

```powershell
python database/import_schemes.py
```

**Warning:** The importer truncates and reloads the scheme tables. Do not run it against a database containing data you need to preserve.

### 6. Run the dashboard

```powershell
python run_dashboard.py
```

Open:

- Citizen dashboard: <http://127.0.0.1:8001/>
- Admin dashboard: <http://127.0.0.1:8001/admin>
- API documentation: <http://127.0.0.1:8001/docs>
- Health check: <http://127.0.0.1:8001/api/health>

Stop the server with `Ctrl+C`.

### 7. Optional: Run the terminal assistant

```powershell
python main.py
```

Or provide a message directly:

```powershell
python main.py --no-upload "I am 23 years old, live in a rural area, and need employment support"
```

### 8. Optional: Configure OCR

If Tesseract is not available on `PATH`, add its executable location to `.env`:

```dotenv
TESSERACT_CMD=C:\Program Files\Tesseract-OCR\tesseract.exe
```

Text-based PDFs and TXT files can be processed without OCR. Photos and scanned PDFs require the Tesseract program. See `VOICE_FEATURES.md` for voice usage and browser notes.

## Run tests

With dependencies installed:

```powershell
python run_all_tests.py
```

Some tests require a running PostgreSQL database with imported scheme data. OCR-related checks may be skipped when Tesseract is not installed.

## Optional Chrome autofill extension

1. Start the dashboard.
2. Open `chrome://extensions` in Chrome.
3. Enable **Developer mode**.
4. Select **Load unpacked** and choose the `browser_extension/` directory.
5. Test against the supported local test form described in the project documentation.
6. Review all populated fields. The extension is designed not to submit forms automatically.

## Deployment

A `Dockerfile` and `render.yaml` are included for deployment on Render with PostgreSQL. Before deploying:

1. Create the Render service from the Blueprint.
2. Configure `ADMIN_PASSWORD_HASH` and any optional `GROQ_API_KEY` in the service environment.
3. Review database persistence, service limits, CORS settings, logging, and privacy/security requirements for your deployment.
4. Never use real citizens' identity documents or sensitive personal data for public demos or testing.

Deployment availability and free-tier limits are controlled by the hosting provider and may change.

## Privacy and responsible use

- Do not upload or enter Aadhaar numbers, bank account details, OTPs, passwords, or other sensitive information unless you have a secure, lawful reason and understand how the data is processed.
- OCR can make mistakes. Users must review extracted values before using them.
- Voice recognition may use browser/platform speech services depending on browser and device settings.
- Scheme matching is a decision-support aid, not a guarantee of eligibility or benefit approval.
- Confirm current eligibility, deadlines, documents, and application links with official government sources.

## Documentation

- `RUN_STEPS.md` — concise local setup instructions
- `VOICE_FEATURES.md` — Hindi/English voice feature guide
- `.env.example` — basic environment variable template
- `.env.dashboard.example` — optional dashboard/admin settings

## Contributing

Bug reports and pull requests are welcome. Please include reproducible steps, avoid committing secrets or personal data, and add or update tests when changing application behavior.

## License

No license file is currently included. Unless a license is added by the project owner, all rights are reserved and reuse, modification, and redistribution are not automatically granted.
