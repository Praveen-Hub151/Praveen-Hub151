"""Start the JanSahayak-AI dashboard.

    python run_dashboard.py                 # http://127.0.0.1:8001
    python run_dashboard.py --port 9000 --reload
    On Render / Docker: HOST and PORT come from the environment (0.0.0.0 and $PORT).

Citizen dashboard: /            Admin dashboard: /admin            API docs: /docs
"""
import argparse
import logging
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))  # lets the dashboard reuse schemas/ from the project root

import uvicorn  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the JanSahayak-AI dashboard")
    hosted = bool(os.getenv("RENDER") or os.getenv("PORT"))
    parser.add_argument("--host", default=os.getenv("HOST", "0.0.0.0" if hosted else "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "8001")))
    parser.add_argument("--workers", type=int, default=int(os.getenv("WEB_CONCURRENCY", "1")))
    parser.add_argument("--reload", action="store_true")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    uvicorn.run("dashboard.app:app", host=args.host, port=args.port, reload=args.reload,
                workers=None if args.reload else args.workers,
                proxy_headers=True, forwarded_allow_ips="*" if hosted else "127.0.0.1")


if __name__ == "__main__":
    main()
