"""FastAPI application for the JanSahayak-AI dashboard.

Run from the JanSahayak-AI folder:   python run_dashboard.py
To add it to another FastAPI app:    from dashboard.app import mount_dashboard; mount_dashboard(app)
"""
from __future__ import annotations

import logging
from contextlib import asynccontextmanager

import psycopg2
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from . import routes_admin, routes_documents, routes_public
from .config import PACKAGE_DIR, settings
from .db import DatabaseUnavailable, close_pool, schema_info
from .profile import ProfileError

log = logging.getLogger("dashboard")
STATIC_DIR = PACKAGE_DIR / "static"

CSP = ("default-src 'self'; script-src 'self'; "
       "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; "
       "img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")


def _register_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(DatabaseUnavailable)
    async def db_unavailable(_: Request, exc: DatabaseUnavailable):
        log.error("Database unavailable: %s", exc)
        return JSONResponse({"detail": "The scheme database is unavailable. Please try again shortly."}, status_code=503)

    @app.exception_handler(psycopg2.Error)
    async def db_error(_: Request, exc: psycopg2.Error):
        log.exception("Database error: %s", exc)
        return JSONResponse({"detail": "A database error occurred."}, status_code=500)

    @app.exception_handler(ProfileError)
    async def profile_validation(_: Request, exc: ProfileError):
        return JSONResponse({"detail": "Some profile fields are not valid", "errors": exc.errors}, status_code=422)

    @app.exception_handler(RequestValidationError)
    async def request_validation(_: Request, exc: RequestValidationError):
        errors = [{"field": ".".join(str(p) for p in e["loc"] if p != "body"), "message": e["msg"]} for e in exc.errors()]
        return JSONResponse({"detail": "Invalid input", "errors": errors}, status_code=422)


def mount_dashboard(app: FastAPI, *, serve_pages: bool = True) -> FastAPI:
    """Attach the dashboard API (under settings.api_prefix) and pages to an existing app."""
    app.include_router(routes_public.router, prefix=settings.api_prefix)
    app.include_router(routes_documents.router, prefix=settings.api_prefix)
    app.include_router(routes_admin.router, prefix=settings.api_prefix)
    app.include_router(routes_admin.protected, prefix=settings.api_prefix)
    _register_error_handlers(app)

    if serve_pages:
        app.mount("/dashboard-static", StaticFiles(directory=STATIC_DIR), name="dashboard-static")

        @app.get("/dashboard", include_in_schema=False)
        def citizen_page():
            return FileResponse(STATIC_DIR / "index.html")

        @app.get("/admin", include_in_schema=False)
        def admin_page():
            return FileResponse(STATIC_DIR / "admin.html")

    @app.middleware("http")
    async def limit_body_size(request: Request, call_next):
        # Uploads arrive as base64 JSON; refuse huge bodies before they are read into memory.
        length = request.headers.get("content-length")
        if length and length.isdigit() and int(length) > settings.max_body_mb * 1024 * 1024:
            return JSONResponse({"detail": f"Request is larger than {settings.max_body_mb} MB."}, status_code=413)
        return await call_next(request)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("X-Frame-Options", "DENY")
        if request.url.path in ("/", "/dashboard", "/admin"):
            response.headers.setdefault("Content-Security-Policy", CSP)
        if settings.cookie_secure:
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
        if request.url.path.startswith(settings.api_prefix + "/admin"):
            response.headers["Cache-Control"] = "no-store"
        return response

    return app


@asynccontextmanager
async def lifespan(_: FastAPI):
    try:
        schema_info.load()
        log.info("Tables found: %s", ", ".join(schema_info.columns))
    except DatabaseUnavailable as exc:
        log.error("Database not reachable at startup (%s). The dashboard will retry on each request.", exc)
    yield
    close_pool()


def create_app() -> FastAPI:
    app = FastAPI(title="JanSahayak-AI Dashboard API", version="1.0.0", lifespan=lifespan)
    if settings.cors_origins:
        app.add_middleware(CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=True,
                           allow_methods=["GET", "POST"], allow_headers=["Content-Type"])
    mount_dashboard(app)

    @app.get("/", include_in_schema=False)
    def root():
        return FileResponse(STATIC_DIR / "index.html")

    return app


app = create_app()
