"""Admin API routes. Every route except login depends on ``require_admin``.
No route here writes to the database."""
from __future__ import annotations

from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from pydantic import BaseModel, Field

from . import ai, auth, queries
from .config import settings
from .db import get_schema, schema_info
from .eligibility import explain_scheme_rules

router = APIRouter(prefix="/admin", tags=["admin"])
protected = APIRouter(prefix="/admin", tags=["admin"], dependencies=[Depends(auth.require_admin)])


class LoginRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=100)
    password: str = Field(..., min_length=1, max_length=200)


@router.post("/login")
def login(body: LoginRequest, request: Request, response: Response):
    if not settings.admin_configured:
        raise HTTPException(503, "Admin access is not configured. Set ADMIN_USERNAME, ADMIN_PASSWORD_HASH and DASHBOARD_SECRET_KEY in .env.")
    ip = auth.client_ip(request)
    auth.check_login_allowed(ip)
    if not auth.authenticate(body.username, body.password):
        auth.record_failure(ip)
        raise HTTPException(401, "Invalid username or password")
    auth.clear_failures(ip)
    response.set_cookie(auth.COOKIE_NAME, auth.make_token(body.username), httponly=True, samesite="strict",
                        secure=settings.cookie_secure, max_age=settings.admin_session_minutes * 60, path="/")
    return {"ok": True, "username": body.username, "expires_in_minutes": settings.admin_session_minutes}


@router.post("/logout")
def logout(response: Response):
    response.delete_cookie(auth.COOKIE_NAME, path="/")
    return {"ok": True}


@router.get("/config-status")
def config_status():
    """Tells the login page whether admin login is set up (no secrets returned)."""
    return {"admin_configured": settings.admin_configured}


@protected.get("/me")
def me(user: dict = Depends(auth.require_admin)):
    return {"username": user["u"], "expires_at": user["exp"]}


@protected.get("/overview")
def overview():
    summary = queries.public_summary()
    return {
        **summary,
        "by_state": queries.schemes_by_state(),
        "purposes": queries.purpose_counts(),
        "categories": queries.category_counts(20),
        "rules": queries.rule_statistics(),
        "documents": queries.document_statistics(10),
    }


@protected.get("/rules/stats")
def rules_stats():
    return queries.rule_statistics()


@protected.get("/documents/stats")
def documents_stats(limit: int = Query(20, ge=1, le=100)):
    return queries.document_statistics(limit)


@protected.get("/system")
def system_status():
    return {"database": queries.database_health(), "ai": ai.ai_status(), "schema": get_schema().columns,
            "settings": {"read_only_connections": settings.db_read_only,
                         "max_page_size": settings.max_page_size,
                         "admin_session_minutes": settings.admin_session_minutes}}


@protected.post("/ai/ping")
def ai_ping():
    return ai.ping()


@protected.post("/cache/refresh")
def refresh_cache():
    """Clears the dashboard's in-memory caches only. The database is not touched."""
    queries.clear_stats_cache()
    schema_info.load(force=True)
    return {"ok": True}


@protected.get("/schemes")
def admin_schemes(
    q: Optional[str] = Query(None, max_length=120),
    state: Optional[str] = Query(None, max_length=80),
    level: Optional[Literal["central", "state"]] = None,
    purpose: Optional[str] = Query(None, max_length=50),
    category: Optional[str] = Query(None, max_length=120),
    sort: Literal["name", "name_desc", "recent"] = "name",
    page: int = Query(1, ge=1, le=10_000),
    page_size: int = Query(20, ge=1, le=100),
):
    return queries.search_schemes(q=(q or "").strip() or None, state=state, level=level, purpose=purpose,
                                  category=category, sort=sort, page=page, page_size=page_size)


@protected.get("/schemes/{scheme_id}")
def admin_scheme_detail(scheme_id: str):
    try:
        detail = queries.scheme_detail(scheme_id)
    except queries.NotFound:
        raise HTTPException(404, "Scheme not found")
    detail["rules"] = explain_scheme_rules(scheme_id)
    detail["raw_rules"] = queries.raw_rules(scheme_id)
    return detail
