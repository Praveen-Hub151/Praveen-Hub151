"""Public (citizen) API routes. None of them write to the database."""
from __future__ import annotations

import logging
from typing import Any, Literal, Optional

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel, Field

from . import ai, auth, queries
from engine.scheme_matcher import popular_schemes

from .config import settings
from .db import DatabaseUnavailable, fetch_value
from .eligibility import DASHBOARD_STATUS, check_scheme, explain_scheme_rules, match
from .profile import build_profile, profile_fields, profile_is_empty

log = logging.getLogger("dashboard")
router = APIRouter(tags=["citizen"])

SchemeId = Field(..., min_length=1, max_length=100)


class EligibilityCheckRequest(BaseModel):
    scheme_id: str = SchemeId
    profile: dict[str, Any] = Field(default_factory=dict)


class MatchRequest(BaseModel):
    profile: dict[str, Any] = Field(default_factory=dict)
    status: Literal["recommended", "eligible", "needs_more_info", "not_eligible", "all"] = "recommended"
    level: Optional[Literal["central", "state"]] = None
    page: int = Field(1, ge=1, le=1000)
    page_size: int = Field(10, ge=1, le=50)


class ChatTurn(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(..., max_length=4000)


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=1000)
    history: list[ChatTurn] = Field(default_factory=list, max_length=20)
    language: Optional[Literal["auto", "en", "hi"]] = "auto"


@router.get("/health")
def health():
    try:
        fetch_value("SELECT 1")
        db = "ok"
    except DatabaseUnavailable as exc:
        log.warning("Health check: %s", exc)
        db = "unavailable"
    return {"status": "ok" if db == "ok" else "degraded", "database": db,
            "ai": "configured" if settings.groq_api_key else "not_configured"}


@router.get("/public-counts")
def public_counts():
    return queries.table_counts()


@router.get("/dashboard/summary")
def dashboard_summary():
    return queries.public_summary()


@router.get("/filters")
def filters():
    return queries.filter_options()


@router.get("/schemes")
def list_schemes(
    q: Optional[str] = Query(None, max_length=120),
    state: Optional[str] = Query(None, max_length=80),
    level: Optional[Literal["central", "state"]] = None,
    purpose: Optional[str] = Query(None, max_length=50),
    category: Optional[str] = Query(None, max_length=120),
    ministry: Optional[str] = Query(None, max_length=300),
    beneficiary_type: Optional[str] = Query(None, max_length=60),
    apply_mode: Optional[Literal["online", "offline", "both", "unknown"]] = None,
    include_central: bool = False,
    sort: Literal["name", "name_desc", "recent"] = "name",
    page: int = Query(1, ge=1, le=10_000),
    page_size: int = Query(12, ge=1),
):
    return queries.search_schemes(q=(q or "").strip() or None, state=state, level=level, purpose=purpose,
                                  category=category, ministry=ministry, beneficiary_type=beneficiary_type,
                                  apply_mode=apply_mode, include_central=include_central, sort=sort, page=page,
                                  page_size=min(page_size, settings.max_page_size))


@router.get("/schemes/{scheme_id}")
def get_scheme(scheme_id: str):
    if len(scheme_id) > 100:
        raise HTTPException(404, "Scheme not found")
    try:
        detail = queries.scheme_detail(scheme_id)
    except queries.NotFound:
        raise HTTPException(404, "Scheme not found")
    detail["rules"] = explain_scheme_rules(scheme_id)
    return detail


@router.get("/eligibility/fields")
def eligibility_fields():
    return {"fields": profile_fields(), "profile_model": "schemas.citizen_schema.CitizenProfile"}


@router.post("/eligibility/check")
def eligibility_check(body: EligibilityCheckRequest):
    profile = build_profile(body.profile)
    result = check_scheme(profile, body.scheme_id)
    if result is None:
        raise HTTPException(404, "Scheme not found")
    return result


@router.post("/citizen/match")
def citizen_match(body: MatchRequest):
    """Runs engine/scheme_matcher.match_schemes() and pages through its result."""
    profile = build_profile(body.profile)
    if profile_is_empty(profile):
        raise HTTPException(422, "Fill in at least one profile field to get recommendations.")
    native = match(profile)
    # engine order inside each list = most relevant first (engine/scheme_matcher.relevance)
    rows = [(DASHBOARD_STATUS[k], k, s, i) for k in ("eligible", "maybe", "no_rules", "not_eligible")
            for i, s in enumerate(native[k])]
    counts = {"eligible": len(native["eligible"]), "needs_more_info": len(native["maybe"]) + len(native["no_rules"]),
              "maybe": len(native["maybe"]), "no_rules": len(native["no_rules"]), "not_eligible": len(native["not_eligible"])}
    if body.status == "recommended":
        popular = popular_schemes()
        rows = [r for r in rows if r[1] in ("eligible", "maybe")
                or (r[1] == "no_rules" and r[2]["scheme_id"] in popular)]   # e.g. PM-KISAN has no written rules
    elif body.status != "all":
        rows = [r for r in rows if r[0] == body.status]
    if body.level:
        rows = [r for r in rows if r[2]["level"] == body.level]
    # eligible first, then "maybe" with the fewest missing fields, then schemes without rules
    rank = {"eligible": 0, "maybe": 1, "no_rules": 2, "not_eligible": 3}
    popular = popular_schemes()
    # a well-known scheme without written rules (e.g. PM-KISAN) comes right after the eligible ones
    rows.sort(key=lambda r: (0.5 if r[1] == "no_rules" and r[2]["scheme_id"] in popular else rank[r[1]],
                             len(r[2].get("missing", [])), r[3]))
    total = len(rows)
    start = (body.page - 1) * body.page_size
    page_rows = rows[start:start + body.page_size]
    details = queries.schemes_by_ids([r[2]["scheme_id"] for r in page_rows])
    items = []
    for status, native_status, s, _ in page_rows:
        d = details.get(s["scheme_id"], {"id": s["scheme_id"], "name": s["scheme_name"],
                                         "level_label": queries.level_label(s["level"]), "state": s["state"]})
        if native_status == "maybe":
            summary = "Needs more information: " + ", ".join(s.get("missing", []))
        elif native_status == "no_rules":
            summary = "No structured rules recorded: read the scheme's eligibility text."
        elif native_status == "not_eligible":
            summary = "A recorded rule is not met, or it is a state scheme for another state."
        else:
            summary = "Meets every required rule recorded for this scheme."
        items.append({"scheme": d, "status": status, "project_status": native_status,
                      "missing_fields": s.get("missing", []), "summary": summary})
    return {"counts": counts, "total": total, "page": body.page, "page_size": body.page_size,
            "pages": max(1, -(-total // body.page_size)), "items": items,
            "needs_filter": [n.value for n in profile.needs],
            "engine": "engine.scheme_matcher.match_schemes"}


@router.get("/ai/status")
def ai_public_status():
    return {"configured": bool(settings.groq_api_key), "provider": "Groq"}


@router.post("/chat")
def chat(body: ChatRequest, request: Request):
    if ai.rate_limited(auth.client_ip(request)):
        raise HTTPException(429, "Too many messages. Please wait a minute and try again.")
    lang = None if body.language in (None, "auto") else body.language
    return ai.answer(body.message.strip(), [t.model_dump() for t in body.history], lang)

