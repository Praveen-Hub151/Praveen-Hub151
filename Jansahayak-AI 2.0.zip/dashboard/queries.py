"""Read-only SQL for the dashboard, written against the project's real tables
(database/schema.sql). Every value is a bound parameter."""
from __future__ import annotations

import re
import time
from typing import Any

from engine.scheme_matcher import popular_schemes

from .db import TABLES, fetch_all, fetch_one, fetch_value, get_schema

LIST_LIMIT_TEXT = 280


class NotFound(LookupError):
    pass


def level_label(level: Any) -> str:
    return "Central" if str(level or "").lower() == "central" else "State"


def _like(term: str) -> str:
    return "%" + re.sub(r"([\\%_])", r"\\\1", term) + "%"


def _list_select() -> str:
    apply_mode = "s.apply_mode" if get_schema().has("schemes", "apply_mode") else "NULL::text"
    return f"""
        s.scheme_id AS id, s.scheme_name AS name, left(s.description, {LIST_LIMIT_TEXT}) AS description,
        s.level, s.state, s.ministry, s.department, s.beneficiary_type,
        s.official_website, s.official_application_url, {apply_mode} AS apply_mode,
        (SELECT array_agg(DISTINCT p.category) FROM scheme_purposes p WHERE p.scheme_id = s.scheme_id) AS categories,
        (SELECT array_agg(DISTINCT p.purpose) FROM scheme_purposes p
          WHERE p.scheme_id = s.scheme_id AND p.purpose IS NOT NULL) AS purposes"""


def decorate(row: dict) -> dict:
    row["level_label"] = level_label(row.get("level"))
    row["categories"] = sorted(row.get("categories") or [])
    row["purposes"] = sorted(row.get("purposes") or [])
    # The myScheme page is the stable link for a list view; detail view adds apply links.
    row["official_url"] = row.get("official_website") or row.get("official_application_url")
    return row


SEARCH_COLUMNS = ("s.scheme_name", "s.description", "s.ministry", "s.department", "s.benefits",
                  "s.eligibility_text", "s.beneficiary_type", "s.scheme_id")


def search_schemes(*, q: str | None = None, state: str | None = None, level: str | None = None,
                   purpose: str | None = None, category: str | None = None, ministry: str | None = None,
                   beneficiary_type: str | None = None, apply_mode: str | None = None,
                   include_central: bool = False, sort: str = "name", page: int = 1, page_size: int = 12) -> dict:
    where: list[str] = []
    params: list[Any] = []

    alias_ids = alias_matches(q) if q else []
    if q:
        for term in [t for t in re.split(r"\s+", q.strip()) if t][:8]:
            like = _like(term)
            ors = [f"{c} ILIKE %s" for c in SEARCH_COLUMNS]
            ors.append("EXISTS (SELECT 1 FROM scheme_purposes p WHERE p.scheme_id = s.scheme_id "
                       "AND (p.category ILIKE %s OR p.purpose ILIKE %s))")
            params.extend([like] * len(SEARCH_COLUMNS) + [like, like])
            if alias_ids:                     # "mnrega" finds MGNREGA even though its name has no such word
                ors.append("s.scheme_id = ANY(%s)")
                params.append(alias_ids)
            where.append("(" + " OR ".join(ors) + ")")
    if level in ("central", "state"):
        where.append("s.level = %s")
        params.append(level)
    if state:
        where.append("(s.state = %s OR s.level = 'central')" if include_central else "s.state = %s")
        params.append(state)
    if purpose:
        where.append("EXISTS (SELECT 1 FROM scheme_purposes p WHERE p.scheme_id = s.scheme_id AND p.purpose = %s)")
        params.append(purpose)
    if category:
        where.append("EXISTS (SELECT 1 FROM scheme_purposes p WHERE p.scheme_id = s.scheme_id AND p.category = %s)")
        params.append(category)
    if ministry:
        where.append("s.ministry = %s")
        params.append(ministry)
    if beneficiary_type:
        where.append("s.beneficiary_type ILIKE %s")
        params.append(_like(beneficiary_type))
    if apply_mode and get_schema().has("schemes", "apply_mode"):
        where.append("s.apply_mode = %s")
        params.append(apply_mode)

    where_sql = (" WHERE " + " AND ".join(where)) if where else ""
    order = {"name_desc": "s.scheme_name DESC",
             "recent": "s.scraped_at DESC NULLS LAST, s.scheme_name"}.get(sort, "s.scheme_name ASC")
    order_params: list[Any] = []
    if q and sort == "name":
        # Relevance first: the scheme people mean by that name (MNREGA -> MGNREGA), well-known schemes,
        # schemes whose name contains the whole query, then the other matches A-Z.
        order = ("(s.scheme_id = ANY(%s)) DESC, (s.scheme_id = ANY(%s)) DESC, (s.scheme_name ILIKE %s) DESC, "
                 + order)
        order_params += [alias_ids, list(popular_schemes()), _like(q.strip())]
    total = fetch_value("SELECT count(*) FROM schemes s" + where_sql, params)
    rows = fetch_all(f"SELECT {_list_select()} FROM schemes s{where_sql} ORDER BY {order} LIMIT %s OFFSET %s",
                     params + order_params + [page_size, (page - 1) * page_size])
    return {"items": [decorate(r) for r in rows], "total": total, "page": page, "page_size": page_size,
            "pages": max(1, -(-total // page_size))}


def schemes_by_ids(ids: list[str]) -> dict[str, dict]:
    if not ids:
        return {}
    rows = fetch_all(f"SELECT {_list_select()} FROM schemes s WHERE s.scheme_id = ANY(%s)", (ids,))
    return {r["id"]: decorate(r) for r in rows}


def scheme_detail(scheme_id: str) -> dict:
    """Everything stored about one scheme, plus the project's own "how to apply" logic."""
    from services.apply_mode import classify, next_step, where_to_submit
    from services.scheme_matcher import scheme_links

    row = fetch_one("SELECT * FROM schemes WHERE scheme_id = %s", (scheme_id,))
    if not row:
        raise NotFound(scheme_id)
    for k, v in list(row.items()):
        if v is not None and not isinstance(v, (str, int, float, bool, list)):
            row[k] = str(v)
    categories = fetch_all("SELECT category, array_agg(purpose ORDER BY purpose) FILTER (WHERE purpose IS NOT NULL) AS purposes "
                           "FROM scheme_purposes WHERE scheme_id = %s GROUP BY category ORDER BY category", (scheme_id,))
    documents = [r["document_name"] for r in fetch_all(
        "SELECT document_name FROM scheme_documents WHERE scheme_id = %s ORDER BY document_id", (scheme_id,))]

    links = scheme_links(row)
    how = classify(row.get("application_process"))
    from services.scheme_matcher import load_overrides
    if row["scheme_id"] in load_overrides():          # a hand-checked link (data/link_overrides.csv) wins
        how["online_url"] = links["apply_link"]
    where = where_to_submit(row.get("application_process"))
    return {
        "scheme": {**row, "id": row["scheme_id"], "name": row["scheme_name"], "level_label": level_label(row.get("level"))},
        "categories": [c["category"] for c in categories],
        "purposes": sorted({p for c in categories for p in (c["purposes"] or [])}),
        "documents": documents,
        "apply": {**links, **how, "where_submit": where,
                  "next_steps": next_step(how["apply_mode"], how["apply_via_csc"], how["online_url"],
                                          links["apply_link"], links["guidelines_link"], where, links["portal_link"])},
    }


# ---------------------------------------------------------------------------
# Assistant retrieval
# ---------------------------------------------------------------------------

STOPWORDS = {
    "the", "and", "for", "are", "what", "which", "who", "how", "can", "get", "any", "scheme", "schemes",
    "yojana", "yojna", "government", "govt", "india", "indian", "about", "with", "from", "this", "that",
    "there", "have", "has", "will", "want", "need", "tell", "please", "apply", "eligible", "eligibility",
    "list", "show", "find", "give", "some", "all", "best", "under", "into", "your", "you", "mujhe", "kya",
    "hai", "hain", "liye", "kaise", "koi", "kaun", "aur", "mein", "mai", "main", "hoon", "hu", "chahiye",
    "batao", "bataye", "saal", "milega", "milegi", "wala", "wali", "ke", "ki", "ka",
    "क्या", "है", "हैं", "के", "लिए", "की", "का", "को", "में", "योजना", "योजनाएं", "योजनाओं", "सरकारी", "मुझे",
    "कौन", "कैसे", "और", "से", "पर", "कोई", "बताओ", "बताइए", "चाहिए", "मैं", "हूँ", "हूं",
}

# Hindi / Hinglish words -> English words that appear in the (English) scheme records.
TRANSLATE = {
    "किसान": "farmer", "kisan": "farmer", "kisaan": "farmer", "खेती": "agriculture", "kheti": "agriculture",
    "छात्रवृत्ति": "scholarship", "scholarship": "scholarship", "chhatravritti": "scholarship",
    "पेंशन": "pension", "pension": "pension", "वृद्ध": "old age", "budhapa": "old age",
    "आवास": "housing", "घर": "housing", "makan": "housing", "ghar": "housing", "awas": "housing",
    "महिला": "women", "mahila": "women", "औरत": "women", "विधवा": "widow", "vidhwa": "widow",
    "दिव्यांग": "disability", "विकलांग": "disability", "divyang": "disability", "viklang": "disability",
    "शिक्षा": "education", "padhai": "education", "छात्र": "student", "स्वास्थ्य": "health", "ilaj": "health",
    "इलाज": "treatment", "रोजगार": "employment", "rozgar": "employment", "naukri": "employment", "kaam": "employment",
    "ऋण": "loan", "लोन": "loan", "karz": "loan", "loan": "loan", "मछली": "fisheries", "पशुपालन": "animal husbandry",
    "बेटी": "girl", "beti": "girl", "लड़की": "girl", "ladki": "girl", "मजदूर": "labour", "mazdoor": "labour",
    "बीमा": "insurance", "bima": "insurance", "प्रशिक्षण": "training", "silai": "tailoring",
}


def alias_matches(text: str) -> list[str]:
    """Scheme ids whose common names (data/popular_schemes.csv) appear in the text: 'mnrega' -> ['mgnrega']."""
    low = " " + re.sub(r"[^\wऀ-ॿ-]+", " ", (text or "").lower()) + " "
    return [sid for sid, names in popular_schemes().items() if any(f" {n} " in low for n in names)]


def retrieval_terms(text: str) -> list[str]:
    words = re.findall(r"[\wऀ-ॿ]+", text.lower())
    out: list[str] = []
    for w in words:
        w2 = TRANSLATE.get(w, w)
        if len(w2) > 2 and w2 not in STOPWORDS and not w2.isdigit():
            out.append(w2)
    return list(dict.fromkeys(out))[:8]


def keyword_search_for_chat(text: str, limit: int = 5, state: str | None = None) -> list[dict]:
    """Rank schemes by how many query words appear in their name (x3), categories (x2) and text."""
    words = retrieval_terms(text)
    if not words:
        return []
    score_parts, params = [], []
    for w in words:
        like = _like(w)
        score_parts.append("(CASE WHEN s.scheme_name ILIKE %s THEN 3 ELSE 0 END)"
                           " + (CASE WHEN EXISTS (SELECT 1 FROM scheme_purposes p WHERE p.scheme_id = s.scheme_id"
                           " AND (p.category ILIKE %s OR p.purpose ILIKE %s)) THEN 2 ELSE 0 END)"
                           " + (CASE WHEN s.description ILIKE %s OR s.benefits ILIKE %s THEN 1 ELSE 0 END)")
        params.extend([like] * 5)
    state_sql = ""
    if state:
        state_sql = " WHERE (s.state = %s OR s.level = 'central')"
    # +10 for the scheme the person named (MNREGA -> MGNREGA), +2 for well-known schemes
    score_parts.append("(CASE WHEN s.scheme_id = ANY(%s) THEN 10 ELSE 0 END)")
    params.append(alias_matches(text))
    params.append(list(popular_schemes()))
    q = (f"SELECT * FROM (SELECT {_list_select()}, ({' + '.join(score_parts)}) AS score,"
         " (CASE WHEN s.scheme_id = ANY(%s) THEN 2 ELSE 0 END) AS bonus"
         f" FROM schemes s{state_sql}) r WHERE score > 0 ORDER BY score + bonus DESC, name LIMIT %s")
    params_all = params + ([state] if state else []) + [limit]
    # state param belongs after the score params because the WHERE comes after the SELECT list
    return [decorate(r) for r in fetch_all(q, params_all)]


# ---------------------------------------------------------------------------
# Statistics (always computed from the live database)
# ---------------------------------------------------------------------------

_cache: dict[str, tuple[float, Any]] = {}


def _cached(key: str, ttl: int, fn):
    hit = _cache.get(key)
    if hit and time.time() - hit[0] < ttl:
        return hit[1]
    value = fn()
    _cache[key] = (time.time(), value)
    return value


def clear_stats_cache() -> None:
    _cache.clear()


def table_counts() -> dict:
    def run():
        schema = get_schema()
        return {t: (fetch_value(f"SELECT count(*) FROM {t}") if schema.has(t) else None) for t in TABLES}
    return _cached("table_counts", 60, run)


def level_distribution() -> dict:
    rows = fetch_all("SELECT level, count(*) AS n FROM schemes GROUP BY level")
    d = {r["level"]: r["n"] for r in rows}
    return {"central": d.get("central", 0), "state": d.get("state", 0)}


def schemes_by_state() -> list[dict]:
    return fetch_all("SELECT state, count(*) AS count FROM schemes WHERE level = 'state' AND state IS NOT NULL "
                     "GROUP BY state ORDER BY count DESC, state")


def purpose_counts() -> list[dict]:
    """The project's Need values (scheme_purposes.purpose)."""
    return fetch_all("SELECT purpose, count(DISTINCT scheme_id) AS count FROM scheme_purposes "
                     "WHERE purpose IS NOT NULL GROUP BY purpose ORDER BY count DESC, purpose")


def category_counts(limit: int = 50) -> list[dict]:
    """myScheme categories (scheme_purposes.category)."""
    return fetch_all("SELECT category, count(DISTINCT scheme_id) AS count FROM scheme_purposes "
                     "GROUP BY category ORDER BY count DESC, category LIMIT %s", (limit,))


def filter_options() -> dict:
    def run():
        schema = get_schema()
        out = {
            "levels": ["central", "state"],
            "states": [r["state"] for r in fetch_all("SELECT DISTINCT state FROM schemes WHERE state IS NOT NULL ORDER BY state")],
            "purposes": [r["purpose"] for r in purpose_counts()],
            "categories": [r["category"] for r in category_counts(100)],
            "ministries": [r["ministry"] for r in fetch_all(
                "SELECT ministry, count(*) FROM schemes WHERE ministry IS NOT NULL GROUP BY 1 ORDER BY 2 DESC, 1 LIMIT 200")],
            "beneficiary_types": [r["v"] for r in fetch_all(
                "SELECT DISTINCT trim(x) AS v FROM schemes, unnest(string_to_array(beneficiary_type, ',')) AS x "
                "WHERE beneficiary_type IS NOT NULL AND trim(x) <> '' ORDER BY 1 LIMIT 50")],
            "apply_modes": [],
        }
        if schema.has("schemes", "apply_mode"):
            out["apply_modes"] = [r["apply_mode"] for r in fetch_all(
                "SELECT DISTINCT apply_mode FROM schemes WHERE apply_mode IS NOT NULL ORDER BY 1")]
        return out
    return _cached("filters", 300, run)


def public_summary() -> dict:
    def run():
        counts = table_counts()
        levels = level_distribution()
        states = schemes_by_state()
        return {
            "total_schemes": counts.get("schemes"),
            "central_schemes": levels["central"],
            "state_schemes": levels["state"],
            "states_covered": len(states),
            "categories_total": fetch_value("SELECT count(DISTINCT category) FROM scheme_purposes"),
            "schemes_with_rules": fetch_value("SELECT count(DISTINCT scheme_id) FROM eligibility_rules"),
            "top_purposes": purpose_counts(),
            "top_categories": category_counts(10),
            "top_states": states[:10],
            "counts": counts,
        }
    return _cached("public_summary", 120, run)


def rule_statistics() -> dict:
    total_schemes = table_counts().get("schemes") or 0
    with_rules = fetch_value("SELECT count(DISTINCT scheme_id) FROM eligibility_rules")
    total = fetch_value("SELECT count(*) FROM eligibility_rules")
    return {
        "total_rules": total,
        "schemes_with_rules": with_rules,
        "schemes_without_rules": max(0, total_schemes - (with_rules or 0)),
        "avg_rules_per_scheme": round(total / with_rules, 2) if with_rules else 0,
        "required": fetch_value("SELECT count(*) FROM eligibility_rules WHERE required"),
        "optional": fetch_value("SELECT count(*) FROM eligibility_rules WHERE NOT required"),
        "by_field": fetch_all("SELECT field, count(*) AS count, count(DISTINCT scheme_id) AS schemes "
                              "FROM eligibility_rules GROUP BY field ORDER BY count DESC"),
        "by_field_operator": fetch_all("SELECT field, operator, count(*) AS count FROM eligibility_rules "
                                       "GROUP BY 1, 2 ORDER BY 3 DESC"),
        "rules_per_scheme": fetch_all("SELECT n AS rules, count(*) AS schemes FROM "
                                      "(SELECT count(*) AS n FROM eligibility_rules GROUP BY scheme_id) x GROUP BY n ORDER BY n"),
        "or_groups": fetch_value("SELECT count(*) FROM (SELECT scheme_id, condition_group FROM eligibility_rules "
                                 "GROUP BY 1, 2 HAVING count(*) > 1) x"),
    }


def document_statistics(limit: int = 20) -> dict:
    total = fetch_value("SELECT count(*) FROM scheme_documents")
    with_docs = fetch_value("SELECT count(DISTINCT scheme_id) FROM scheme_documents")
    return {
        "total_rows": total,
        "schemes_with_documents": with_docs,
        "schemes_without_documents": max(0, (table_counts().get("schemes") or 0) - (with_docs or 0)),
        "avg_documents_per_scheme": round(total / with_docs, 2) if with_docs else 0,
        "distinct_documents": fetch_value("SELECT count(DISTINCT lower(regexp_replace(trim(document_name), '[.:;\\s]+$', ''))) "
                                          "FROM scheme_documents"),
        "top_documents": fetch_all(
            "SELECT min(regexp_replace(trim(document_name), '[.:;\\s]+$', '')) AS document, "
            "count(DISTINCT scheme_id) AS schemes FROM scheme_documents "
            "GROUP BY lower(regexp_replace(trim(document_name), '[.:;\\s]+$', '')) "
            "ORDER BY schemes DESC, document LIMIT %s", (limit,)),
        # Common document types by keyword (a document line can mention several).
        "by_keyword": fetch_all(
            "SELECT k.label AS document, count(DISTINCT d.scheme_id) AS schemes FROM scheme_documents d "
            "JOIN (VALUES ('Aadhaar', 'aadhaar'), ('Income certificate', 'income'), ('Caste certificate', 'caste'),"
            " ('Bank account / passbook', 'bank'), ('Photograph', 'photo'), ('Domicile / residence', 'domicile|residen'),"
            " ('Disability certificate', 'disab'), ('Ration card', 'ration'), ('Mark sheet / education', 'mark ?sheet|marksheet|certificate of class'),"
            " ('Age / birth proof', 'birth|age proof'), ('Land records', 'land')) AS k(label, pattern)"
            " ON d.document_name ~* k.pattern GROUP BY k.label ORDER BY schemes DESC"),
    }


def database_health() -> dict:
    started = time.perf_counter()
    info = fetch_one("SELECT current_database() AS database, version() AS version, "
                     "pg_size_pretty(pg_database_size(current_database())) AS size, "
                     "current_setting('transaction_read_only') AS read_only, now()::text AS server_time")
    info["latency_ms"] = round((time.perf_counter() - started) * 1000, 1)
    schema = get_schema()
    counts = table_counts()
    info["tables"] = [{"table": t, "exists": schema.has(t), "rows": counts.get(t),
                       "columns": schema.columns.get(t, [])} for t in TABLES]
    info["apply_mode_column"] = schema.has("schemes", "apply_mode")
    info["citizen_profiles_table"] = schema.has("citizen_profiles")
    info["orphans"] = {
        "rules_without_scheme": fetch_value("SELECT count(*) FROM eligibility_rules r WHERE NOT EXISTS "
                                            "(SELECT 1 FROM schemes s WHERE s.scheme_id = r.scheme_id)"),
        "schemes_without_documents": fetch_value("SELECT count(*) FROM schemes s WHERE NOT EXISTS "
                                                 "(SELECT 1 FROM scheme_documents d WHERE d.scheme_id = s.scheme_id)"),
        "schemes_without_purpose": fetch_value("SELECT count(*) FROM schemes s WHERE NOT EXISTS "
                                               "(SELECT 1 FROM scheme_purposes p WHERE p.scheme_id = s.scheme_id)"),
    }
    info["status"] = "ok"
    return info


def raw_rules(scheme_id: str) -> list[dict]:
    """eligibility_rules rows exactly as stored (admin rule inspection)."""
    return fetch_all("SELECT rule_id, field, operator, value, required, condition_group, description "
                     "FROM eligibility_rules WHERE scheme_id = %s ORDER BY rule_id", (scheme_id,))
