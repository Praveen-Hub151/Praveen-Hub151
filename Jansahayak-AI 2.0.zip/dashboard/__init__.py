"""JanSahayak-AI dashboard package (citizen + admin dashboards and API)."""
__version__ = "1.0.0"
