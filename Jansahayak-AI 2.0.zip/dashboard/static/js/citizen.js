/* Citizen dashboard: overview, search, scheme detail, eligibility, recommendations,
   AI assistant and saved schemes. Hash-based routing, no framework. */
"use strict";

const view = document.getElementById("view");
const PROFILE_KEY = "jansahayak.profile.v1";
const SAVED_KEY = "jansahayak.saved.v1";
let filtersCache = null;
let fieldsCache = null;
let currentAbort = null;
const chatState = { history: [], pending: false, language: "auto", log: [] };

/* ---------- small state helpers ---------- */
const saved = {
  all() { return store.get(SAVED_KEY, []); },
  has(id) { return this.all().some((s) => String(s.id) === String(id)); },
  toggle(s) {
    let list = this.all();
    if (this.has(s.id)) {
      list = list.filter((x) => String(x.id) !== String(s.id));
      store.set(SAVED_KEY, list);
      toast("Removed from saved schemes");
    } else {
      list.unshift({ id: s.id, name: s.name, level_label: s.level_label, state: s.state || null, saved_at: new Date().toISOString() });
      if (!store.set(SAVED_KEY, list.slice(0, 200))) { toast("Could not save: browser storage is unavailable", "error"); return false; }
      toast("Saved on this device");
    }
    updateSavedCount();
    return this.has(s.id);
  },
};
function updateSavedCount() { document.getElementById("saved-count").textContent = saved.all().length; }
function getProfile() { return store.get(PROFILE_KEY, null); }

async function getFilters() {
  if (!filtersCache) filtersCache = await api("/filters");
  return filtersCache;
}
async function getFields() {
  if (!fieldsCache) fieldsCache = await api("/eligibility/fields");
  return fieldsCache;
}

function newAbort() {
  if (currentAbort) currentAbort.abort();
  currentAbort = new AbortController();
  return currentAbort.signal;
}

function saveButton(s, small = true) {
  const on = saved.has(s.id);
  return `<button class="btn ${small ? "btn-sm" : ""} save-btn ${on ? "saved" : ""}" data-save='${esc(JSON.stringify({ id: s.id, name: s.name, level_label: s.level_label, state: s.state || null }))}' aria-pressed="${on}">${icon("bookmark")}<span>${on ? "Saved" : "Save"}</span></button>`;
}

function bindSaveButtons(root = view) {
  root.querySelectorAll(".save-btn").forEach((b) => b.addEventListener("click", () => {
    const s = JSON.parse(b.dataset.save);
    const on = saved.toggle(s);
    b.classList.toggle("saved", on);
    b.setAttribute("aria-pressed", String(on));
    b.querySelector("span").textContent = on ? "Saved" : "Save";
    if (location.hash.startsWith("#/saved")) renderSaved();
  }));
}

const MODE_TEXT = { online: "Apply online", offline: "Apply offline", both: "Online or offline", unknown: "" };

function schemeCard(s) {
  const url = safeUrl(s.official_url);
  const cats = (s.categories || []).slice(0, 2).map((c) => `<span class="badge purpose">${esc(c)}</span>`).join("");
  return `<article class="card scheme-card">
    <div class="chips">${levelBadge(s.level_label)}${s.state ? `<span class="badge">${esc(s.state)}</span>` : ""}${s.apply_mode && MODE_TEXT[s.apply_mode] ? `<span class="badge">${MODE_TEXT[s.apply_mode]}</span>` : ""}</div>
    <h4><a href="#/scheme/${encodeURIComponent(s.id)}">${esc(decodeEntities(s.name))}</a></h4>
    ${s.description ? `<p>${esc(decodeEntities(s.description))}</p>` : ""}
    ${s.ministry || s.department ? `<div class="meta">${esc(s.ministry || s.department)}</div>` : ""}
    ${cats ? `<div class="chips">${cats}</div>` : ""}
    <div class="foot">
      <a class="btn btn-sm btn-primary" href="#/scheme/${encodeURIComponent(s.id)}">View details</a>
      ${saveButton(s)}
      <span class="spacer"></span>
      ${url ? `<a class="btn btn-sm btn-ghost" href="${esc(url)}" target="_blank" rel="noopener noreferrer" aria-label="Official page for ${esc(s.name)} (opens in new tab)">${icon("ext")}</a>` : ""}
    </div>
  </article>`;
}

/* ---------- router ---------- */
const ROUTES = {
  overview: { title: "Overview", render: renderOverview },
  search: { title: "Search schemes", render: renderSearch },
  recommendations: { title: "Recommendations", render: renderRecommendations },
  scheme: { title: "Scheme details", render: renderScheme, nav: "search" },
  eligibility: { title: "Eligibility checker", render: renderEligibility },
  documents: { title: "Upload documents", render: renderDocuments },
  assistant: { title: "AI assistant", render: renderAssistant },
  saved: { title: "Saved schemes", render: renderSaved },
};

function parseHash() {
  const raw = location.hash.replace(/^#\/?/, "");
  const [path, query = ""] = raw.split("?");
  const parts = path.split("/").filter(Boolean);
  return { name: parts[0] || "overview", arg: parts[1] ? decodeURIComponent(parts[1]) : null, params: new URLSearchParams(query) };
}

function route() {
  const r = parseHash();
  const def = ROUTES[r.name] || ROUTES.overview;
  const navName = def.nav || (ROUTES[r.name] ? r.name : "overview");
  document.querySelectorAll("#nav a").forEach((a) => {
    const on = a.dataset.route === navName;
    a.classList.toggle("active", on);
    if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
  });
  document.getElementById("page-title").textContent = def.title;
  document.title = `${def.title} · JanSahayak-AI`;
  def.render(r.arg, r.params);
  view.focus({ preventScroll: true });
  window.scrollTo(0, 0);
}

/* ---------- overview ---------- */
async function renderOverview() {
  const profile = getProfile();
  view.innerHTML = `
    <section class="hero">
      <div><h2>Find government schemes you can use</h2><p>Search real scheme records, check eligibility against the recorded rules, and ask the AI assistant in English or Hindi.</p></div>
      <form id="hero-search" role="search"><label for="hero-q" class="sr-only">Search schemes</label>
        <input id="hero-q" class="input" type="search" placeholder="e.g. scholarship, pension, farmer, आवास" maxlength="120">
        <button class="btn btn-primary" type="submit">${icon("search")}Search</button></form>
    </section>
    <div class="grid grid-4" id="stats">${'<div class="card skeleton" style="height:140px"></div>'.repeat(4)}</div>
    <div class="grid grid-3" style="margin-top:18px">
      <div class="card"><h3>Central vs state</h3><p class="sub">Click a segment to browse</p><div class="chart-box short"><canvas id="c-level" aria-label="Central versus state schemes chart" role="img"></canvas></div></div>
      <div class="card span-2"><h3>Schemes by category</h3><p class="sub">myScheme categories. Click a bar to browse.</p><div class="chart-box short"><canvas id="c-purpose" aria-label="Schemes by purpose chart" role="img"></canvas></div></div>
    </div>
    <div class="grid grid-2" style="margin-top:18px">
      <div class="card"><h3>States with the most schemes</h3><p class="sub">State-level schemes only</p><div class="chart-box short"><canvas id="c-states" aria-label="Schemes by state chart" role="img"></canvas></div></div>
      <div class="card"><h3>${profile ? "Your recommendations" : "Get personalised recommendations"}</h3>
        <p class="sub">${profile ? "Based on the profile saved on this device." : "Fill in a short profile to see schemes whose recorded rules you meet."}</p>
        <div style="display:flex;flex-direction:column;gap:10px">
          <a class="btn btn-primary" href="${profile ? "#/recommendations" : "#/eligibility"}">${icon(profile ? "star" : "user")}${profile ? "View recommendations" : "Create my profile"}</a>
          <a class="btn" href="#/assistant">${icon("chat")}Ask the AI assistant</a>
          <a class="btn" href="#/saved">${icon("bookmark")}Saved schemes (${saved.all().length})</a>
        </div>
        <div class="alert info" style="margin-top:16px">${icon("shield")}<span>Your profile stays in this browser. It is sent to the server only when you run a check, and is not stored there.</span></div>
      </div>
    </div>`;
  document.getElementById("hero-search").addEventListener("submit", (e) => {
    e.preventDefault();
    location.hash = "#/search?q=" + encodeURIComponent(document.getElementById("hero-q").value.trim());
  });
  try {
    const s = await api("/dashboard/summary");
    const stat = (tone, ic, label, value, hint) => `<div class="card stat tone-${tone}"><div class="icon">${icon(ic)}</div><div class="label">${label}</div><div class="value">${fmtNum(value)}</div><div class="hint">${hint}</div></div>`;
    document.getElementById("stats").innerHTML =
      stat("blue", "layers", "Total schemes", s.total_schemes, "Records in the database") +
      stat("teal", "shield", "Central schemes", s.central_schemes, "Government of India") +
      stat("violet", "map", "State schemes", s.state_schemes, `Across ${fmtNum(s.states_covered)} states/UTs`) +
      stat("amber", "check", "With eligibility rules", s.schemes_with_rules, `${fmtNum(s.total_schemes - s.schemes_with_rules)} rely on eligibility text only`);
    renderChart("c-level", doughnutConfig(["Central", "State"], [s.central_schemes, s.state_schemes], undefined,
      (l) => { location.hash = "#/search?level=" + l.toLowerCase(); }));
    renderChart("c-purpose", barConfig(s.top_categories.map((p) => p.category), s.top_categories.map((p) => p.count),
      { horizontal: true, color: PALETTE[2], onClick: (l) => { location.hash = "#/search?category=" + encodeURIComponent(l); } }));
    renderChart("c-states", barConfig(s.top_states.map((p) => p.state), s.top_states.map((p) => p.count),
      { horizontal: true, color: PALETTE[1], onClick: (l) => { location.hash = "#/search?state=" + encodeURIComponent(l); } }));
  } catch (e) {
    document.getElementById("stats").outerHTML = `<div class="card">${stateBox("error", "Could not load statistics", e.message)}</div>`;
  }
}

/* ---------- search ---------- */
const SEARCH_KEYS = ["q", "state", "level", "purpose", "category", "ministry", "beneficiary_type", "apply_mode", "sort"];

async function renderSearch(_, params) {
  const p = Object.fromEntries(SEARCH_KEYS.map((k) => [k, params.get(k) || ""]));
  p.sort = p.sort || "name";
  p.include_central = params.get("include_central") === "true";
  p.page = Math.max(1, parseInt(params.get("page") || "1", 10) || 1);
  const sel = (name, label, all) => `<label class="field">${label}<select class="input" name="${name}"><option value="">${all}</option></select></label>`;
  view.innerHTML = `
    <div class="page-head"><div><h2>Search government schemes</h2><p>Search by name, description, ministry, benefits and eligibility text, then narrow down with filters.</p></div></div>
    <form class="card" id="search-form" novalidate>
      <div class="filters">
        <label class="field q">Keywords<input class="input" name="q" type="search" maxlength="120" value="${esc(p.q)}" placeholder="Scheme name, benefit, keyword…"></label>
        ${sel("state", "State / UT", "All states")}
        ${sel("category", "Category", "All categories")}
        ${sel("purpose", "Purpose (need)", "All purposes")}
        <div class="field"><span>Government level</span>
          <div class="tri" role="radiogroup" aria-label="Government level">
            ${[["", "All"], ["central", "Central"], ["state", "State"]].map(([v, l]) => `<label><input type="radio" name="level" value="${v}" ${p.level === v ? "checked" : ""}><span>${l}</span></label>`).join("")}
          </div></div>
      </div>
      <details style="margin-top:12px" ${p.ministry || p.beneficiary_type || p.apply_mode ? "open" : ""}><summary style="cursor:pointer;color:var(--blue);font-weight:600;font-size:14px">More filters</summary>
        <div class="filters" style="margin-top:12px;grid-template-columns:2fr 1fr 1fr 1fr">
          ${sel("ministry", "Ministry", "All ministries")}
          ${sel("beneficiary_type", "Beneficiary type", "All")}
          ${sel("apply_mode", "How to apply", "Any")}
          <label class="field">Sort by<select class="input" name="sort">
            <option value="name">Best match / name</option><option value="name_desc">Name (Z–A)</option><option value="recent">Recently updated</option></select></label>
        </div></details>
      <div style="display:flex;gap:12px;align-items:center;justify-content:space-between;margin-top:14px;flex-wrap:wrap">
        <label class="check" id="inc-central" ${p.state ? "" : "hidden"}><input type="checkbox" name="include_central" ${p.include_central ? "checked" : ""}> Include central schemes</label>
        <span class="field-error" id="search-error" role="alert"></span>
        <div style="display:flex;gap:8px;margin-left:auto">
          <button type="button" class="btn btn-ghost" id="reset">Reset</button>
          <button type="submit" class="btn btn-primary">${icon("search")}Search</button>
        </div>
      </div>
    </form>
    <div class="results-meta"><span id="result-count" role="status"></span></div>
    <div id="results"></div><div id="pager"></div>`;
  const form = document.getElementById("search-form");
  form.elements.sort.value = p.sort;
  const fill = (name, list, current, labeler = (v) => v) => {
    const el = form.elements[name];
    (list || []).forEach((v) => el.add(new Option(labeler(v), v, false, v === current)));
    if (current && !(list || []).includes(current)) el.add(new Option(labeler(current), current, true, true));
  };
  getFilters().then((f) => {
    fill("state", f.states, p.state);
    fill("category", f.categories, p.category);
    fill("purpose", f.purposes, p.purpose, titleCase);
    fill("ministry", f.ministries, p.ministry);
    fill("beneficiary_type", f.beneficiary_types, p.beneficiary_type);
    fill("apply_mode", f.apply_modes, p.apply_mode, (v) => MODE_TEXT[v] || titleCase(v));
  }).catch(() => { /* filters are optional: keyword search still works */ });

  const go = (page = 1) => {
    const fd = new FormData(form);
    const q = String(fd.get("q") || "").trim();
    if (q.length > 120) { document.getElementById("search-error").textContent = "Keep keywords under 120 characters."; return; }
    const qs = new URLSearchParams();
    SEARCH_KEYS.forEach((k) => { const v = String(fd.get(k) || "").trim(); if (v && !(k === "sort" && v === "name")) qs.set(k, v); });
    if (fd.get("include_central") && fd.get("state")) qs.set("include_central", "true");
    if (page > 1) qs.set("page", page);
    location.hash = "#/search" + (qs.toString() ? "?" + qs : "");
  };
  form.addEventListener("submit", (e) => { e.preventDefault(); go(1); });
  ["state", "category", "purpose", "ministry", "beneficiary_type", "apply_mode", "sort", "include_central"]
    .forEach((n) => form.elements[n].addEventListener("change", () => go(1)));
  form.querySelectorAll('input[name="level"]').forEach((r) => r.addEventListener("change", () => go(1)));
  document.getElementById("reset").addEventListener("click", () => { location.hash = "#/search"; });

  const results = document.getElementById("results");
  const count = document.getElementById("result-count");
  results.innerHTML = skeletonCards(6);
  count.textContent = "Searching…";
  try {
    const data = await api("/schemes", { params: { ...p, page_size: 12 }, signal: newAbort() });
    count.textContent = data.total ? `${fmtNum(data.total)} scheme${data.total === 1 ? "" : "s"} found · page ${data.page} of ${data.pages}` : "";
    if (!data.items.length) {
      results.innerHTML = stateBox("empty", "No schemes match these filters", "Try fewer keywords, another state, or clear the filters.",
        '<a class="btn" href="#/search" style="margin-top:12px">Clear filters</a>');
    } else {
      results.innerHTML = `<div class="scheme-list">${data.items.map(schemeCard).join("")}</div>`;
      bindSaveButtons(results);
    }
    pagination(document.getElementById("pager"), data.page, data.pages, (pg) => go(pg));
  } catch (e) {
    if (e.name === "AbortError") return;
    count.textContent = "";
    results.innerHTML = stateBox("error", "Search failed", e.message, '<button class="btn" id="retry" style="margin-top:12px">Try again</button>');
    document.getElementById("retry").addEventListener("click", route);
  }
}

/* ---------- scheme detail ---------- */
const RESULT_TEXT = { pass: "Met", fail: "Not met", unknown: "Missing info", optional: "Optional" };
const RESULT_CLASS = { pass: "eligible", fail: "not_eligible", unknown: "needs_more_info", optional: "" };

/** Rule groups from the project's engine: same group = any one rule is enough (OR), groups are all required (AND). */
function renderGroups(groups, withResults = true) {
  if (!groups || !groups.length) return "";
  return `<ul class="check-list">${groups.map((g) => {
    const head = g.any_of ? `<span style="font-size:12px;color:var(--text-3)">Any one of:</span><br>` : "";
    const rules = g.rules.map((r) => `${esc(r.description)}${r.required ? "" : ' <span class="badge">Optional</span>'}${withResults ? `<br><span style="color:var(--text-3);font-size:13px">Your value: ${esc(r.your_value)}${g.any_of ? ` · ${esc(RESULT_TEXT[r.result] || r.result)}` : ""}</span>` : ""}`).join("<br>");
    const badge = withResults ? `<span class="badge ${RESULT_CLASS[g.status] || ""}">${esc(RESULT_TEXT[g.status] || g.status)}</span>` : `<span class="badge">Rule</span>`;
    return `<li>${badge}<span>${head}${rules}</span></li>`;
  }).join("")}</ul>`;
}

function renderResult(r) {
  return `<div class="result-panel ${esc(r.status)}" role="status">
    <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
      <h4>${esc(STATUS_TEXT[r.status])}</h4>${statusBadge(r.status)}</div>
    <p style="margin:4px 0 0">${esc(r.summary)}</p>
    ${r.missing_fields && r.missing_fields.length ? `<p style="margin:8px 0 0;font-size:13.5px">Add to your profile: <strong>${r.missing_fields.map((f) => esc(titleCase(f))).join(", ")}</strong> · <a href="#/eligibility">Edit profile</a></p>` : ""}
    ${renderGroups(r.groups)}
    <p style="margin:12px 0 0;font-size:12.5px;color:var(--text-3)">Decided by the project's eligibility engine using only the rules recorded in the database. Always confirm with the official source before applying.</p>
  </div>`;
}

async function renderScheme(id) {
  if (!id) { location.hash = "#/search"; return; }
  view.innerHTML = loadingInline("Loading scheme…");
  let d;
  try { d = await api("/schemes/" + encodeURIComponent(id), { signal: newAbort() }); } catch (e) {
    if (e.name === "AbortError") return;
    view.innerHTML = stateBox(e.status === 404 ? "empty" : "error", e.status === 404 ? "Scheme not found" : "Could not load scheme", e.message,
      '<a class="btn" href="#/search" style="margin-top:12px">Back to search</a>');
    return;
  }
  const s = d.scheme, ap = d.apply || {};
  document.title = `${decodeEntities(s.name)} · JanSahayak-AI`;
  const applyUrl = safeUrl(ap.apply_link), siteUrl = safeUrl(s.official_website);
  const block = (title, text) => text ? `<div class="card"><p class="section-title">${title}</p><div class="prose">${richText(text)}</div></div>` : "";
  const link = (url, label) => safeUrl(url) ? `<li>${icon("ext")}<a href="${esc(safeUrl(url))}" target="_blank" rel="noopener noreferrer">${label}</a></li>` : "";
  view.innerHTML = `
    <a class="back-link" href="#/search" id="back">${icon("arrowLeft")}Back</a>
    <div class="card" style="margin-top:12px"><div class="detail-head">
      <div style="min-width:0;flex:1">
        <div class="chips">${levelBadge(s.level_label)}${s.state ? `<span class="badge">${esc(s.state)}</span>` : ""}${s.beneficiary_type ? `<span class="badge">${esc(s.beneficiary_type)}</span>` : ""}${ap.apply_mode && MODE_TEXT[ap.apply_mode] ? `<span class="badge">${MODE_TEXT[ap.apply_mode]}</span>` : ""}</div>
        <h2>${esc(decodeEntities(s.name))}</h2>
        ${s.ministry || s.department ? `<div style="color:var(--text-3)">${esc([s.ministry, s.department].filter(Boolean).join(" · "))}</div>` : ""}
        ${d.categories.length ? `<div class="chips" style="margin-top:10px">${d.categories.map((c) => `<a class="badge purpose" href="#/search?category=${encodeURIComponent(c)}">${esc(c)}</a>`).join("")}</div>` : ""}
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${saveButton({ id: s.id, name: s.name, level_label: s.level_label, state: s.state }, false)}
        <a class="btn btn-primary" href="#apply-steps" id="go-steps">${icon("check")}Check eligibility &amp; upload documents</a>
      </div></div></div>
    ${applySectionHtml()}
    <div class="grid grid-3" style="margin-top:16px;align-items:start">
      <div class="span-2 grid" style="gap:16px">
        ${block("About this scheme", s.description)}
        ${block("Benefits", s.benefits)}
        ${block("Eligibility (as published)", s.eligibility_text)}
        ${block("Application process", s.application_process)}
      </div>
      <div class="grid" style="gap:16px">
        <div class="card"><p class="section-title">How to apply</p>
          ${(ap.next_steps || []).map((l) => `<p style="margin:0 0 8px;font-size:14px">${esc(l)}</p>`).join("")}
          <ul class="doc-list" style="margin-top:8px">${link(ap.apply_link, "Apply / steps to apply")}${link(ap.portal_link, "Official website")}${link(ap.guidelines_link, "Guidelines (document)")}${siteUrl && siteUrl !== applyUrl ? link(siteUrl, "myScheme page") : ""}</ul>
          ${ap.link_note ? `<p style="margin:8px 0 0;font-size:12.5px;color:var(--text-3)">${esc(ap.link_note)}</p>` : ""}</div>
      </div>
    </div>`;
  document.getElementById("back").addEventListener("click", (e) => { if (history.length > 1) { e.preventDefault(); history.back(); } });
  document.getElementById("go-steps").addEventListener("click", (e) => {
    e.preventDefault();
    document.getElementById("apply-steps").scrollIntoView({ behavior: "smooth" });
  });
  bindSaveButtons(view);
  initApplySection(s, d);
}

/* ---------- scheme page: 1 eligibility, 2 documents (upload + verify), 3 apply ---------- */
const MARK = { pass: "✓", fail: "✗", unknown: "?", optional: "–" };
const DOC_STATUS = {
  verified: ["pass", "✓ Verified"], manual_review: ["unknown", "Uploaded · a person will check"],
  wrong_document: ["fail", "✗ Wrong document"], check_failed: ["fail", "✗ Check failed"],
  missing: ["", "Not uploaded"], optional: ["", "Optional"], info: ["", "Type it in the form"],
  used: ["pass", "✓ Read for eligibility"],
};
const KIND_TEXT = {
  aadhaar: "Aadhaar", income_certificate: "Income certificate", bank_passbook: "Bank passbook",
  caste_certificate: "Caste certificate", disability_certificate: "Disability certificate",
  ration_card: "Ration card", domicile_certificate: "Domicile certificate", address_proof: "Address proof",
  age_proof: "Age proof", identity_proof: "ID proof", photo: "Photo", education: "Education", other: "Other",
};

function applySectionHtml() {
  return `
    <section class="card" id="apply-steps" style="margin-top:16px;scroll-margin-top:80px">
      <p class="section-title">Step 1 · Eligibility criteria</p>
      <div id="elig-box">${loadingInline("Checking eligibility…")}</div>
      <p class="section-title" style="margin-top:22px">Step 2 · Upload your documents</p>
      <p class="sub" style="margin:0 0 10px">Upload a photo or PDF for each document. One Aadhaar can also count as proof of age, identity and address. Files are only read to verify them and are not stored.</p>
      <div id="doc-box">${loadingInline("Loading the document list…")}</div>
      <div id="ready-msg" style="margin-top:14px"></div>
      <p class="section-title" style="margin-top:22px">Step 3 · Apply</p>
      <div id="apply-box"></div>
    </section>`;
}

function eligibilityHtml(r, fromDocuments = false) {
  if (!r.groups || !r.groups.length) {
    return `<div class="alert warn">${icon("alert")}<span>No structured eligibility rules are recorded for this scheme. Read "Eligibility (as published)" below and confirm with the official source.</span></div>`;
  }
  const rows = r.groups.map((g) => {
    const rules = g.rules.map((x) => esc(x.description)).join(g.any_of ? " <em>or</em> " : "<br>");
    const yours = g.rules.map((x) => esc(x.your_value)).filter((v, i, a) => a.indexOf(v) === i).join(", ");
    return `<li class="crit ${esc(g.status)}"><span class="mark ${esc(g.status)}" aria-label="${esc(RESULT_TEXT[g.status] || g.status)}">${MARK[g.status] || "?"}</span>
      <span>${rules}<br><span class="crit-you">You: ${yours}</span></span></li>`;
  }).join("");
  const missing = r.missing_fields && r.missing_fields.length
    ? `<p style="margin:10px 0 0;font-size:13.5px">Still unknown: <strong>${r.missing_fields.map((f) => esc(titleCase(f))).join(", ")}</strong>. Upload a document that shows it (e.g. income certificate), or <a href="#/eligibility">fill your profile</a>.</p>` : "";
  return `<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">${statusBadge(r.status)}<span>${esc(r.summary)}</span></div>
    <ul class="crit-list">${rows}</ul>${missing}
    ${fromDocuments ? '<p class="sub" style="margin:8px 0 0">Checked with the details read from your documents.</p>' : ""}`;
}

function docRowHtml(item, result) {
  const st = result ? result.status : (item.kind === "info" ? "info" : item.optional ? "optional" : "missing");
  const [cls, label] = DOC_STATUS[st] || ["", st];
  const canUpload = item.kind !== "info";
  const reason = result && result.reason && !["verified", "info"].includes(st) ? `<div class="doc-reason">${esc(result.reason)}</div>` : "";
  const file = result && result.file ? `<div class="doc-file">${icon("file")}${esc(result.file)}</div>` : "";
  return `<li class="doc-row" data-item="${item.number}">
    <span class="mark ${cls}">${cls === "pass" ? "✓" : cls === "fail" ? "✗" : cls === "unknown" ? "?" : ""}</span>
    <div class="doc-main"><div class="doc-name">${esc(decodeEntities(item.name))}</div>
      <div class="chips" style="margin-top:4px"><span class="badge">${esc(KIND_TEXT[item.kind] || titleCase(item.kind))}</span><span class="badge ${cls}">${esc(label)}</span></div>
      ${file}${reason}<div class="doc-chosen" data-chosen="${item.number}"></div></div>
    ${canUpload ? `<label class="btn btn-ghost upload-btn">${icon("file")}Upload<input type="file" class="sr-only" data-file="${item.number}" accept=".jpg,.jpeg,.png,.pdf,.webp"></label>` : ""}
  </li>`;
}

function applyButtonsHtml(ap, ready) {
  const mode = ap.apply_mode || "unknown";
  const onlineUrl = safeUrl(ap.online_url) || safeUrl(ap.portal_link) || safeUrl(ap.apply_link);
  const offlineUrl = safeUrl(ap.guidelines_link) || safeUrl(ap.apply_link);
  const onlineOk = ["online", "both", "unknown"].includes(mode);
  const offlineOk = ["offline", "both", "unknown"].includes(mode);
  const btn = (ok, url, cls, label, note) => ok && url
    ? `<a class="btn ${cls}" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${icon("ext")}${label}</a>`
    : `<button class="btn" disabled title="${esc(note)}">${label}</button>`;
  return `${ready ? "" : '<p class="sub" style="margin:0 0 10px">You can open the links now; it is best to apply once all checkmarks are green.</p>'}
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      ${btn(onlineOk, onlineUrl, "btn-primary", "Apply online", "This scheme is applied offline")}
      ${btn(offlineOk, offlineUrl, "btn-teal", "Apply offline", "This scheme is applied online")}
    </div>
    ${offlineOk && ap.where_submit ? `<p style="margin:10px 0 0;font-size:13.5px"><strong>Offline:</strong> fill the form and ${esc(ap.where_submit.charAt(0).toLowerCase() + ap.where_submit.slice(1))}</p>` : ""}
    ${onlineOk && ap.apply_via_csc ? '<p style="margin:6px 0 0;font-size:13.5px">You can also apply online at your nearest CSC / Jan Seva Kendra.</p>' : ""}
    ${mode === "unknown" ? '<p class="sub" style="margin:6px 0 0">How to apply is not written in our data; the links open the scheme\'s official / myScheme page.</p>' : ""}`;
}

/* ---------- apply: copy values into the online form, or print an offline draft ---------- */
function formToolsHtml(ap, res) {
  const mode = ap.apply_mode || "unknown";
  const online = ["online", "both", "unknown"].includes(mode);
  const offline = ["offline", "both", "unknown"].includes(mode);
  const rows = res.form_data.map((f, i) => `<tr>
      <th scope="row">${esc(f.label)}</th>
      <td>${f.value ? `<strong>${esc(f.value)}</strong>` : '<span class="sub">—</span>'}${f.note ? `<div class="form-note">${esc(f.note)}</div>` : ""}</td>
      <td class="form-src">${esc(f.source || "")}</td>
      <td>${f.value && !f.value.includes("XXXX") ? `<button class="btn btn-ghost btn-sm" data-copy="${i}">Copy</button>` : ""}</td></tr>`).join("");
  const guide = res.upload_guide.map((g) => `<li>${icon("file")}<span><strong>${esc(decodeEntities(g.document))}</strong> → upload <em>${esc(g.file)}</em></span></li>`).join("");
  return `
    <div class="form-tools">
      ${online ? `<div class="card form-card" id="online-card">
        <p class="section-title">Fill the online form</p>
        <p class="sub" style="margin:0 0 10px">Open the online form with <strong>Apply online</strong>, then copy each value into the matching box.
          You do the login, OTP, captcha and the final <strong>Submit</strong> yourself.</p>
        <div class="alert info" style="margin:0 0 10px">${icon("check")}<span><strong>Faster with the JanSahayak autofill extension:</strong>
          on the official form page, click the extension's icon and <em>Fill this form</em>. It fills these values for you and asks for anything missing.
          Install it once from the <code>browser_extension</code> folder (see RUN_STEPS.md).</span></div>
        <div class="table-wrap"><table class="form-table"><tbody>${rows}</tbody></table></div>
        ${guide ? `<p class="section-title" style="margin-top:14px">Which file to upload where</p><ul class="doc-list">${guide}</ul>` : ""}
      </div>` : ""}
      ${offline ? `<div class="card form-card">
        <p class="section-title">Apply offline</p>
        <p class="sub" style="margin:0 0 10px">Print a filled application draft with your details, a document checklist and where to submit it.
          Check every detail, sign it, attach photocopies of the documents and submit it.</p>
        <button class="btn btn-teal" id="print-draft">${icon("file")}Prepare draft (print / save as PDF)</button>
      </div>` : ""}
    </div>`;
}

function draftHtml(s, ap, res, items) {
  const today = new Date().toLocaleDateString("en-IN");
  const statusOf = {};
  res.documents.items.forEach((i) => { statusOf[i.number] = i; });
  const rows = res.form_data.map((f) => `<tr><th>${esc(f.label)}</th><td>${esc(f.value || "")}${f.note ? `<div class="note">${esc(f.note)}</div>` : ""}</td></tr>`).join("");
  const docs = items.filter((i) => i.kind !== "info").map((i) => {
    const st = statusOf[i.number];
    const done = st && ["verified", "manual_review"].includes(st.status);
    return `<li><span class="box">${done ? "✓" : ""}</span>${esc(decodeEntities(i.name))}${i.optional ? " (if applicable)" : ""}</li>`;
  }).join("");
  const where = ap.where_submit || "Submit it at your nearest Common Service Centre (CSC), Gram Panchayat or Block office, or at the office named in the scheme guidelines.";
  return `<!doctype html><html><head><meta charset="utf-8"><title>Application draft · ${esc(decodeEntities(s.name))}</title>
<style>
  body{font-family:Arial,Helvetica,sans-serif;color:#111;margin:28px;font-size:14px}
  h1{font-size:20px;margin:0 0 4px} h2{font-size:15px;margin:22px 0 8px;border-bottom:2px solid #111;padding-bottom:4px}
  .draft{display:inline-block;border:2px solid #b45309;color:#b45309;padding:2px 8px;font-weight:700;font-size:12px;margin-bottom:10px}
  table{width:100%;border-collapse:collapse} th,td{border:1px solid #999;padding:7px 9px;text-align:left;vertical-align:top}
  th{width:38%;background:#f3f4f6;font-weight:600} .note{font-size:11px;color:#555;margin-top:3px}
  ul{list-style:none;padding:0;margin:0} li{margin:6px 0;display:flex;gap:8px;align-items:flex-start}
  .box{display:inline-block;width:16px;height:16px;border:1.5px solid #111;text-align:center;line-height:16px;font-size:13px;flex-shrink:0}
  .sign{display:flex;justify-content:space-between;margin-top:40px} .sign div{width:45%;border-top:1px solid #111;padding-top:4px;font-size:12px}
  .small{font-size:12px;color:#444} @media print{body{margin:12mm}}
</style></head><body>
<div class="draft">DRAFT · prepared by JanSahayak-AI · check every detail before submitting</div>
<h1>Application form: ${esc(decodeEntities(s.name))}</h1>
<div class="small">${esc([s.ministry, s.state || "Central scheme"].filter(Boolean).join(" · "))} · Prepared on ${esc(today)}</div>
<h2>1. Applicant details</h2><table>${rows}</table>
<h2>2. Documents attached (photocopies, self-attested)</h2><ul>${docs || "<li>No documents are listed for this scheme.</li>"}</ul>
<h2>3. Where to submit</h2><p>${esc(where)}</p>
${safeUrl(ap.guidelines_link) ? `<p class="small">Official form / guidelines: ${esc(ap.guidelines_link)}</p>` : ""}
<p class="small">If the office gives you its own printed form, copy these details into it.</p>
<h2>4. Declaration</h2>
<p>I declare that the information given above is true to the best of my knowledge. I have attached the documents listed above.</p>
<div class="sign"><div>Place and date</div><div>Signature / thumb impression of the applicant</div></div>
</body></html>`;
}

function bindFormTools(s, ap, res, items) {
  view.querySelectorAll("[data-copy]").forEach((b) => b.addEventListener("click", async () => {
    const value = res.form_data[Number(b.dataset.copy)].value;
    try { await navigator.clipboard.writeText(value); b.textContent = "Copied ✓"; }
    catch { b.textContent = "Select & copy"; }
    setTimeout(() => { b.textContent = "Copy"; }, 1800);
  }));
  const pr = document.getElementById("print-draft");
  if (pr) pr.addEventListener("click", () => {
    const w = window.open("", "_blank");
    if (!w) { toast("Allow pop-ups for this page to print the draft", "error"); return; }
    w.document.open();
    w.document.write(draftHtml(s, ap, res, items));
    w.document.close();
    w.focus();
    setTimeout(() => w.print(), 300);
  });
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(String(r.result).split(",", 2)[1] || "");
    r.onerror = () => reject(new Error("Could not read " + file.name));
    r.readAsDataURL(file);
  });
}

async function initApplySection(s, d) {
  const ap = d.apply || {};
  const eligBox = document.getElementById("elig-box");
  const docBox = document.getElementById("doc-box");
  const readyBox = document.getElementById("ready-msg");
  const applyBox = document.getElementById("apply-box");
  applyBox.innerHTML = applyButtonsHtml(ap, false);

  // Step 1: eligibility with the saved profile (or just the criteria)
  const profile = getProfile() || {};
  try {
    const r = await api("/eligibility/check", { method: "POST", body: { scheme_id: s.id, profile } });
    eligBox.innerHTML = eligibilityHtml(r) + (getProfile() ? "" : `<div class="alert info" style="margin-top:10px">${icon("user")}<span>No profile saved yet: upload your documents below and they will fill it in, or <a href="#/eligibility?scheme=${encodeURIComponent(s.id)}">fill your profile</a>.</span></div>`);
  } catch (e) {
    eligBox.innerHTML = `<div class="alert error">${icon("alert")}<span>${esc(e.message)}</span></div>`;
  }

  // Step 2: the scheme's document list with an upload button per document
  let items;
  try { items = (await api(`/schemes/${encodeURIComponent(s.id)}/required-documents`)).items; } catch (e) {
    docBox.innerHTML = `<div class="alert error">${icon("alert")}<span>${esc(e.message)}</span></div>`;
    return;
  }
  const chosen = {};          // item number -> File
  const extra = { number: 1000, name: "Extra proof for eligibility (optional), e.g. income or caste certificate", kind: "other", optional: true };
  const draw = (results = {}) => {
    docBox.innerHTML = (items.length ? `<ul class="doc-rows">${items.map((it) => docRowHtml(it, results[it.number])).join("")}${docRowHtml(extra, results[extra.number])}</ul>`
      : `<p class="sub">No documents are listed for this scheme.</p><ul class="doc-rows">${docRowHtml(extra)}</ul>`)
      + `<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;margin-top:12px">
          <label class="field" style="max-width:260px">PDF password (only for a locked e-Aadhaar)
            <input class="input" id="doc-password" type="password" maxlength="50" autocomplete="off" placeholder="e.g. SUNI2004"></label>
          <button class="btn btn-primary" id="verify-btn">${icon("check")}Verify documents</button></div>`;
    Object.entries(chosen).forEach(([n, f]) => { const el = docBox.querySelector(`[data-chosen="${n}"]`); if (el) el.textContent = "Selected: " + f.name; });
    docBox.querySelectorAll("input[data-file]").forEach((inp) => inp.addEventListener("change", () => {
      const f = inp.files[0];
      if (!f) return;
      if (f.size > 8 * 1024 * 1024) { toast(f.name + " is larger than 8 MB", "error"); return; }
      chosen[inp.dataset.file] = f;
      docBox.querySelector(`[data-chosen="${inp.dataset.file}"]`).textContent = "Selected: " + f.name;
    }));
    document.getElementById("verify-btn").addEventListener("click", verify);
  };

  const verify = async () => {
    if (!Object.keys(chosen).length) { toast("Choose at least one file with an Upload button first", "error"); return; }
    const btn = document.getElementById("verify-btn");
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Reading documents… (photos take a few seconds)';
    try {
      const files = await Promise.all(Object.entries(chosen).map(async ([n, f]) => ({ item: Number(n), filename: f.name, data: await fileToBase64(f) })));
      const password = document.getElementById("doc-password").value || null;
      const res = await api(`/schemes/${encodeURIComponent(s.id)}/verify-documents`, { method: "POST", body: { profile: getProfile() || {}, files, password } });
      const byNumber = {};
      res.documents.items.forEach((r) => { byNumber[r.number] = r; });
      if (chosen[extra.number]) byNumber[extra.number] = { status: "used", file: chosen[extra.number].name, reason: "" };
      draw(byNumber);
      eligBox.innerHTML = eligibilityHtml(res.eligibility, true);
      if (res.found_in_documents.length) {
        // Remember what the documents showed in the profile on this device
        const p = getProfile() || {};
        res.found_in_documents.forEach((f) => { p[f.field] = f.value; });
        store.set(PROFILE_KEY, p);
      }
      const found = res.found_in_documents.map((f) => `${esc(f.label)}: <strong>${esc(typeof f.value === "boolean" ? (f.value ? "Yes" : "No") : f.value)}</strong>`).join(" · ");
      readyBox.innerHTML = `<div class="alert ${res.ready_for_form ? "success ready-banner" : "warn"}" role="status">${icon(res.ready_for_form ? "check" : "alert")}
        <span><strong>${esc(res.message)}</strong><br>${esc(res.documents.summary)}${found ? `<br><span style="font-size:13px">Read from your documents: ${found}</span>` : ""}</span></div>`;
      // Hand the verified details to the JanSahayak autofill browser extension (browser_extension/).
      // Only this browser keeps them; full Aadhaar / account numbers are never included.
      store.set("jansahayak.autofill.v1", { scheme_id: s.id, scheme_name: decodeEntities(s.name),
        apply_url: safeUrl(ap.online_url) || safeUrl(ap.portal_link) || safeUrl(ap.apply_link) || null,
        fields: res.autofill || {}, saved_at: new Date().toISOString() });
      window.postMessage({ source: "jansahayak-dashboard", type: "autofill-updated" }, location.origin);
      applyBox.innerHTML = applyButtonsHtml(ap, res.ready_for_form) + formToolsHtml(ap, res);
      bindFormTools(s, ap, res, items);
      readyBox.scrollIntoView({ behavior: "smooth", block: "center" });
    } catch (e) {
      readyBox.innerHTML = `<div class="alert error">${icon("alert")}<span>${esc(e.message)}</span></div>`;
      const b = document.getElementById("verify-btn");
      if (b) { b.disabled = false; b.innerHTML = `${icon("check")}Verify documents`; }
    }
  };
  draw();
}

/* ---------- general document extraction -> profile -> scheme matching ---------- */
async function renderDocuments() {
  const current = getProfile() || {};
  view.innerHTML = `
    <section class="card">
      <p class="section-title">Upload documents</p>
      <h2>Build your citizen profile from documents</h2>
      <p class="sub">Upload up to 12 supported documents. Jansahayak AI reads the text, extracts supported fields, lets you review the profile, and then checks scheme eligibility. Files are processed temporarily and are not saved by this endpoint.</p>
      <form id="document-profile-form">
        <label for="profile-files">Choose documents (PDF, JPG, PNG, WEBP, TIFF, BMP, or TXT)</label>
        <input class="input" id="profile-files" type="file" multiple accept=".pdf,.jpg,.jpeg,.png,.webp,.bmp,.tif,.tiff,.txt" required>
        <label for="doc-password" style="display:block;margin-top:12px">PDF password (only if needed)</label>
        <input class="input" id="doc-password" type="password" maxlength="50" autocomplete="off" placeholder="Leave blank if PDF is not locked">
        <label class="check" style="margin-top:14px"><input type="checkbox" id="document-consent" required> I am authorized to upload these documents and consent to processing them for my profile.</label>
        <div class="foot" style="margin-top:16px"><button class="btn btn-primary" id="extract-documents" type="submit">${icon("file")}Extract details</button><span class="sub">Maximum 8 MB per file</span></div>
      </form>
      <div id="document-extract-status" style="margin-top:16px"></div>
    </section>
    <section id="document-review" class="card" style="margin-top:16px;display:none"></section>
    <section id="document-matches" style="margin-top:16px;display:none"></section>`;

  document.getElementById("document-profile-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const input = document.getElementById("profile-files");
    const files = Array.from(input.files || []);
    const status = document.getElementById("document-extract-status");
    const button = document.getElementById("extract-documents");
    if (!files.length) { status.innerHTML = `<div class="alert warn">Choose at least one document.</div>`; return; }
    if (files.length > 12) { status.innerHTML = `<div class="alert warn">Upload no more than 12 documents at once.</div>`; return; }
    if (files.some((f) => f.size > 8 * 1024 * 1024)) { status.innerHTML = `<div class="alert warn">Each file must be 8 MB or smaller.</div>`; return; }
    if (!document.getElementById("document-consent").checked) { status.innerHTML = `<div class="alert warn">Confirm authorization and consent before continuing.</div>`; return; }
    const toBase64 = (file) => new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
      reader.onerror = () => reject(new Error(`Could not read ${file.name}`));
      reader.readAsDataURL(file);
    });
    button.disabled = true;
    button.innerHTML = '<span class="spinner"></span> Extracting documents…';
    status.innerHTML = `<div class="alert info">Reading documents. Scanned photos and PDFs may take a little longer.</div>`;
    try {
      const encoded = await Promise.all(files.map(async (file) => ({ filename: file.name, data: await toBase64(file) })));
      const result = await api("/documents/extract-profile", { method: "POST", body: {
        profile: getProfile() || {}, files: encoded,
        password: document.getElementById("doc-password").value || null,
        consent: true
      }});
      status.innerHTML = `<div class="alert ${result.found_fields.length ? "success" : "warn"}"><span><strong>${esc(result.message)}</strong><br>${esc(result.privacy)}</span></div>`;
      const review = document.getElementById("document-review");
      review.style.display = "block";
      const fields = result.found_fields.map((f) => `<tr><td>${esc(f.label)}</td><td>${esc(Array.isArray(f.value) ? f.value.join(", ") : f.value)}</td><td>${esc(f.source)}</td></tr>`).join("");
      const docs = result.documents.map((d) => `<li><strong>${esc(d.filename)}</strong> — ${esc(titleCase(d.type))}; ${d.field_count} field(s) detected (${esc(d.read_as)})</li>`).join("");
      review.innerHTML = `<p class="section-title">Review extracted details</p><h3>Documents processed</h3><ul class="doc-list">${docs}</ul>
        <h3 style="margin-top:18px">Fields detected</h3>${fields ? `<div style="overflow-x:auto"><table class="data-table"><thead><tr><th>Field</th><th>Extracted value</th><th>Source</th></tr></thead><tbody>${fields}</tbody></table></div>` : `<p class="sub">No profile fields were detected. Try a clearer document.</p>`}
        <p class="sub" style="margin-top:12px">Please check the extracted values. OCR can make mistakes. Confirm before using them for scheme matching.</p>
        <div class="foot"><button class="btn btn-primary" id="confirm-document-profile" ${result.found_fields.length ? "" : "disabled"}>Use these details &amp; find schemes</button><button class="btn btn-ghost" id="discard-document-profile">Discard</button></div>`;
      document.getElementById("discard-document-profile").addEventListener("click", () => { review.style.display = "none"; document.getElementById("document-matches").style.display = "none"; });
      document.getElementById("confirm-document-profile").addEventListener("click", async () => {
        const confirmButton = document.getElementById("confirm-document-profile");
        confirmButton.disabled = true; confirmButton.textContent = "Checking schemes…";
        // Keep the existing profile and merge only fields returned by extraction.
        const merged = { ...(getProfile() || {}) };
        Object.entries(result.profile || {}).forEach(([key, value]) => {
          if (value !== null && value !== undefined && value !== "" && !(Array.isArray(value) && !value.length)) merged[key] = value;
        });
        if (!store.set(PROFILE_KEY, merged)) { status.innerHTML = `<div class="alert error">Could not save the profile in this browser.</div>`; confirmButton.disabled = false; confirmButton.textContent = "Use these details & find schemes"; return; }
        try {
          const matched = await api("/citizen/match", { method: "POST", body: { profile: merged, status: "recommended", page: 1, page_size: 12 } });
          const matches = document.getElementById("document-matches");
          matches.style.display = "block";
          matches.innerHTML = `<section class="card"><p class="section-title">Scheme matching</p><h2>Recommendations based on your confirmed profile</h2><p class="sub">${matched.counts.eligible} eligible · ${matched.counts.needs_more_info} need more information. Confirm final eligibility with the official scheme authority.</p>${matched.items.length ? `<div class="grid grid-2">${matched.items.map((item) => `<article class="card scheme-card"><div class="chips">${statusBadge(item.status)}</div><h3><a href="#/scheme/${encodeURIComponent(item.scheme.id)}">${esc(decodeEntities(item.scheme.name))}</a></h3><p>${esc(item.summary)}</p>${item.missing_fields && item.missing_fields.length ? `<p class="sub">Missing: ${item.missing_fields.map((x) => esc(titleCase(x))).join(", ")}</p>` : ""}<a class="btn btn-sm btn-primary" href="#/scheme/${encodeURIComponent(item.scheme.id)}">View scheme &amp; documents</a></article>`).join("")}</div>` : `<p>No scheme recommendations were returned. Complete more profile fields or try the eligibility checker.</p>`}<div class="foot" style="margin-top:16px"><a class="btn btn-primary" href="#/eligibility">Review full profile</a><a class="btn btn-ghost" href="#/recommendations">Open recommendations</a></div></section>`;
          toast("Profile updated on this device");
          matches.scrollIntoView({ behavior: "smooth", block: "start" });
        } catch (error) {
          status.innerHTML += `<div class="alert warn" style="margin-top:10px">Profile saved, but scheme matching failed: ${esc(error.message)}. Open the eligibility checker and try again.</div>`;
        } finally { confirmButton.disabled = false; confirmButton.textContent = "Use these details & find schemes"; }
      });
    } catch (error) {
      status.innerHTML = `<div class="alert error"><span>${esc(error.message)}</span></div>`;
    } finally {
      button.disabled = false;
      button.innerHTML = `${icon("file")}Extract details`;
    }
  });
}

/* ---------- eligibility ---------- */
async function renderEligibility(_, params) {
  view.innerHTML = loadingInline("Loading form…");
  let fields, filters;
  try { [fields, filters] = await Promise.all([getFields(), getFilters().catch(() => ({ states: [] }))]); } catch (e) {
    view.innerHTML = stateBox("error", "Could not load the eligibility form", e.message); return;
  }
  const profile = getProfile() || {};
  const states = filters.states.filter((s) => s !== "(not set)");
  const input = (f) => {
    const v = profile[f.name];
    const id = `p-${f.name}`;
    if (f.type === "select") return `<select class="input" name="${f.name}" id="${id}"><option value="">Not specified</option>${f.options.map((o) => `<option value="${esc(o)}" ${v === o ? "selected" : ""}>${esc(titleCase(o))}</option>`).join("")}</select>`;
    if (f.type === "multi") return `<div class="chips" role="group" aria-labelledby="l-${f.name}" style="gap:4px 12px">${f.options.map((o) => `<label class="check" style="font-weight:400"><input type="checkbox" name="${f.name}" value="${esc(o)}" ${(v || []).includes(o) ? "checked" : ""}>${esc(titleCase(o))}</label>`).join("")}</div>`;
    if (f.type === "state") return `<select class="input" name="${f.name}" id="${id}"><option value="">Not specified</option>${states.map((o) => `<option ${v === o ? "selected" : ""}>${esc(o)}</option>`).join("")}${v && !states.includes(v) ? `<option selected>${esc(v)}</option>` : ""}</select>`;
    if (f.type === "bool") return `<select class="input" name="${f.name}" id="${id}"><option value="">Not specified</option><option value="true" ${v === true ? "selected" : ""}>Yes</option><option value="false" ${v === false ? "selected" : ""}>No</option></select>`;
    if (f.type === "number") return `<input class="input" type="number" inputmode="decimal" name="${f.name}" id="${id}" ${f.min !== undefined ? `min="${f.min}"` : ""} ${f.max !== undefined ? `max="${f.max}"` : ""} step="${f.step}" value="${v ?? ""}">`;
    return `<input class="input" type="text" name="${f.name}" id="${id}" maxlength="80" value="${esc(v ?? "")}">`;
  };
  const fieldHtml = (f) => f.type === "multi"
    ? `<div class="field" style="grid-column:1/-1"><span id="l-${f.name}">${esc(f.label)}</span>${input(f)}${f.help ? `<span style="font-weight:400;color:var(--text-3)">${esc(f.help)}</span>` : ""}<span class="field-error" id="e-${f.name}"></span></div>`
    : `<label class="field" for="p-${f.name}">${esc(f.label)}${input(f)}${f.help ? `<span style="font-weight:400;color:var(--text-3);font-size:12px">${esc(f.help)}</span>` : ""}<span class="field-error" id="e-${f.name}"></span></label>`;
  const preScheme = params.get("scheme");
  view.innerHTML = `
    <div class="page-head"><div><h2>Eligibility checker</h2><p>Rule-based check against the eligibility rules stored for each scheme. Leave anything you don't know blank.</p></div></div>
    <div class="grid grid-3" style="align-items:start">
      <form class="card span-2" id="profile-form" novalidate>
        <h3>Your profile</h3><p class="sub">These are the fields of the project's CitizenProfile. Unknown fields stay blank and lead to "needs more information", never a guess.</p>
        <div class="form-grid">${fields.fields.map(fieldHtml).join("")}</div>
        <label class="check" style="margin-top:16px"><input type="checkbox" id="remember" checked> Remember my profile on this device</label>
        <div style="display:flex;gap:8px;margin-top:16px;flex-wrap:wrap">
          <button class="btn btn-primary" type="submit" data-mode="match">${icon("star")}Find matching schemes</button>
          <button class="btn" type="button" id="clear-profile">${icon("trash")}Clear profile</button>
        </div>
        <div id="form-msg" style="margin-top:12px"></div>
      </form>
      <div class="card">
        <h3>Check a specific scheme</h3><p class="sub">Search for a scheme, then check it against your profile.</p>
        <div class="typeahead">
          <label class="sr-only" for="scheme-q">Scheme name</label>
          <input class="input" id="scheme-q" type="search" placeholder="Type a scheme name…" autocomplete="off" role="combobox" aria-expanded="false" aria-controls="ta-list" aria-autocomplete="list">
          <ul class="typeahead-list" id="ta-list" role="listbox" hidden></ul>
        </div>
        <div id="picked" style="margin-top:12px"></div>
        <button class="btn btn-primary" id="check-one" style="margin-top:12px;width:100%" disabled>${icon("check")}Check this scheme</button>
      </div>
    </div>
    <div id="one-result" style="margin-top:18px"></div>`;

  const form = document.getElementById("profile-form");
  const readProfile = () => {
    const out = {};
    let ok = true;
    fields.fields.forEach((f) => {
      const err = document.getElementById("e-" + f.name);
      err.textContent = "";
      if (f.type === "multi") {
        const vals = [...form.querySelectorAll(`input[name="${f.name}"]:checked`)].map((c) => c.value);
        if (vals.length) out[f.name] = vals;
        return;
      }
      const el = form.elements[f.name];
      el.removeAttribute("aria-invalid");
      const raw = String(el.value).trim();
      if (raw === "") return;
      if (f.type === "number") {
        const n = Number(raw);
        const intOnly = f.step === 1;
        if (!Number.isFinite(n) || (f.min !== undefined && n < f.min) || (f.max !== undefined && n > f.max) || (intOnly && !Number.isInteger(n))) {
          err.textContent = `Enter ${intOnly ? "a whole number" : "a number"}${f.max !== undefined ? ` between ${f.min} and ${f.max}` : f.min !== undefined ? ` of at least ${f.min}` : ""}.`;
          el.setAttribute("aria-invalid", "true"); ok = false; return;
        }
        out[f.name] = n;
      } else if (f.type === "bool") out[f.name] = raw === "true";
      else out[f.name] = raw;
    });
    return ok ? out : null;
  };
  const showServerErrors = (e) => {
    (e.errors || []).forEach((er) => {
      const name = er.field.split(".").pop();
      const el = document.getElementById("e-" + name);
      if (el) { el.textContent = er.message; form.elements[name] && form.elements[name].setAttribute("aria-invalid", "true"); }
    });
  };
  const persist = (p) => {
    if (document.getElementById("remember").checked) store.set(PROFILE_KEY, p); else store.remove(PROFILE_KEY);
  };

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const p = readProfile();
    const msg = document.getElementById("form-msg");
    if (!p) { msg.innerHTML = `<div class="alert error">${icon("alert")}<span>Please fix the highlighted fields.</span></div>`; return; }
    if (!Object.keys(p).length) { msg.innerHTML = `<div class="alert warn">${icon("alert")}<span>Fill in at least one field.</span></div>`; return; }
    persist(p);
    sessionStorage.setItem("jansahayak.lastProfile", JSON.stringify(p));
    location.hash = "#/recommendations";
  });
  document.getElementById("clear-profile").addEventListener("click", () => {
    store.remove(PROFILE_KEY);
    sessionStorage.removeItem("jansahayak.lastProfile");
    form.reset();
    form.querySelectorAll("select, input[type=number], input[type=text]").forEach((el) => { el.value = ""; });
    form.querySelectorAll("input[type=checkbox]:not(#remember)").forEach((el) => { el.checked = false; });
    toast("Profile cleared from this device");
  });

  // typeahead
  const q = document.getElementById("scheme-q");
  const list = document.getElementById("ta-list");
  const btn = document.getElementById("check-one");
  let picked = null, items = [], active = -1;
  const pick = (s) => {
    picked = s; list.hidden = true; q.setAttribute("aria-expanded", "false"); q.value = decodeEntities(s.name);
    document.getElementById("picked").innerHTML = `<div class="alert info">${icon("check")}<span><strong>${esc(decodeEntities(s.name))}</strong><br>${levelBadge(s.level_label)}</span></div>`;
    btn.disabled = false;
  };
  const show = () => {
    list.innerHTML = items.length ? items.map((s, i) => `<li role="option" id="ta-${i}" aria-selected="${i === active}" data-i="${i}">${esc(decodeEntities(s.name))} <span style="color:var(--text-3);font-size:12px">· ${esc(s.level_label)}${s.state && s.level_label !== "Central" ? " · " + esc(s.state) : ""}</span></li>`).join("") : '<li aria-disabled="true">No schemes found</li>';
    list.hidden = false; q.setAttribute("aria-expanded", "true");
    if (active >= 0) q.setAttribute("aria-activedescendant", "ta-" + active); else q.removeAttribute("aria-activedescendant");
    list.querySelectorAll("li[data-i]").forEach((li) => li.addEventListener("mousedown", (e) => { e.preventDefault(); pick(items[Number(li.dataset.i)]); }));
  };
  q.addEventListener("input", debounce(async () => {
    picked = null; btn.disabled = true; document.getElementById("picked").innerHTML = "";
    const term = q.value.trim();
    if (term.length < 2) { list.hidden = true; return; }
    try { items = (await api("/schemes", { params: { q: term, page_size: 8 } })).items; active = -1; show(); } catch { items = []; show(); }
  }, 250));
  q.addEventListener("keydown", (e) => {
    if (list.hidden || !items.length) return;
    if (e.key === "ArrowDown") { active = Math.min(items.length - 1, active + 1); show(); e.preventDefault(); }
    else if (e.key === "ArrowUp") { active = Math.max(0, active - 1); show(); e.preventDefault(); }
    else if (e.key === "Enter" && active >= 0) { pick(items[active]); e.preventDefault(); }
    else if (e.key === "Escape") { list.hidden = true; q.setAttribute("aria-expanded", "false"); }
  });
  q.addEventListener("blur", () => setTimeout(() => { list.hidden = true; q.setAttribute("aria-expanded", "false"); }, 150));
  btn.addEventListener("click", async () => {
    if (!picked) return;
    const p = readProfile();
    const out = document.getElementById("one-result");
    if (!p) { out.innerHTML = `<div class="alert error">${icon("alert")}<span>Please fix the highlighted profile fields.</span></div>`; return; }
    persist(p);
    out.innerHTML = loadingInline("Checking the recorded rules…");
    try {
      const r = await api("/eligibility/check", { method: "POST", body: { scheme_id: picked.id, profile: p } });
      out.innerHTML = `<div class="card"><div class="card-head"><div><h3>${esc(decodeEntities(r.scheme.name))}</h3><p class="sub" style="margin:0">${esc(r.scheme.level_label)}${r.scheme.state && r.scheme.level_label !== "Central" ? " · " + esc(r.scheme.state) : ""}</p></div><a class="btn btn-sm" href="#/scheme/${encodeURIComponent(r.scheme.id)}">View scheme</a></div>${renderResult(r)}</div>`;
      out.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (e) {
      showServerErrors(e);
      out.innerHTML = `<div class="alert error">${icon("alert")}<span>${esc(e.message)}</span></div>`;
    }
  });
  if (preScheme) {
    api("/schemes/" + encodeURIComponent(preScheme)).then((d) => pick({ id: d.scheme.id, name: d.scheme.name, level_label: d.scheme.level_label, state: d.scheme.state })).catch(() => {});
  }
}

/* ---------- recommendations ---------- */
function profileChips(profile) {
  return Object.entries(profile).map(([k, v]) => {
    const shown = Array.isArray(v) ? v.map(titleCase).join(", ") : typeof v === "boolean" ? (v ? "Yes" : "No") : k === "annual_income" ? "₹" + fmtNum(v) : titleCase(v);
    return `<span class="badge">${esc(titleCase(k))}: ${esc(shown)}</span>`;
  }).join("");
}

async function renderRecommendations(_, params) {
  const profile = getProfile() || JSON.parse(sessionStorage.getItem("jansahayak.lastProfile") || "null");
  if (!profile) {
    view.innerHTML = `<div class="page-head"><div><h2>Recommendations</h2><p>Schemes whose recorded rules match your profile.</p></div></div>
      <div class="card">${stateBox("empty", "No profile yet", "Create a short profile to see schemes you may be eligible for.", '<a class="btn btn-primary" href="#/eligibility" style="margin-top:12px">Create my profile</a>')}</div>`;
    return;
  }
  const status = params.get("status") || "recommended";
  const level = params.get("level") || "";
  const page = Math.max(1, parseInt(params.get("page") || "1", 10) || 1);
  const tabs = [["recommended", "Recommended"], ["eligible", "Eligible"], ["needs_more_info", "Needs more info"], ["not_eligible", "Not eligible"], ["all", "All"]];
  view.innerHTML = `
    <div class="page-head"><div><h2>Recommendations</h2><p>Every scheme is checked with the project's matcher (engine/scheme_matcher.py).</p></div>
      <a class="btn" href="#/eligibility">${icon("user")}Edit profile</a></div>
    <div class="card" style="margin-bottom:16px"><p class="section-title">Your profile</p><div class="chips">${profileChips(profile)}</div>
      <p style="margin:10px 0 0;font-size:13px;color:var(--text-3)" id="needs-note"></p></div>
    <div style="display:flex;gap:12px;justify-content:space-between;flex-wrap:wrap;align-items:center">
      <div class="tabs" role="tablist" aria-label="Result type">${tabs.map(([v, l]) => `<button role="tab" aria-selected="${v === status}" data-status="${v}">${l} <span class="count-${v}"></span></button>`).join("")}</div>
      <label class="field" style="flex-direction:row;align-items:center;gap:8px">Level<select class="input" id="rec-level" style="width:auto"><option value="">All</option><option value="central" ${level === "central" ? "selected" : ""}>Central</option><option value="state" ${level === "state" ? "selected" : ""}>State</option></select></label>
    </div>
    <div id="rec-results" style="margin-top:16px"></div><div id="rec-pager"></div>`;
  const nav = (s, l, pg = 1) => {
    const qs = new URLSearchParams();
    if (s !== "recommended") qs.set("status", s);
    if (l) qs.set("level", l);
    if (pg > 1) qs.set("page", pg);
    location.hash = "#/recommendations" + (qs.toString() ? "?" + qs : "");
  };
  view.querySelectorAll(".tabs button").forEach((b) => b.addEventListener("click", () => nav(b.dataset.status, level)));
  document.getElementById("rec-level").addEventListener("change", (e) => nav(status, e.target.value));

  const box = document.getElementById("rec-results");
  box.innerHTML = loadingInline("Checking your profile against all schemes…");
  try {
    const data = await api("/citizen/match", { method: "POST", body: { profile, status, level: level || null, page, page_size: 10 }, signal: newAbort() });
    const c = data.counts;
    const set = (k, n) => { const el = view.querySelector(".count-" + k); if (el) el.textContent = `(${fmtNum(n)})`; };
    set("eligible", c.eligible); set("needs_more_info", c.needs_more_info); set("not_eligible", c.not_eligible);
    set("all", c.eligible + c.needs_more_info + c.not_eligible); set("recommended", c.eligible + c.maybe);
    document.getElementById("needs-note").textContent = data.needs_filter.length
      ? `Only schemes for your needs (${data.needs_filter.map(titleCase).join(", ")}) are checked. Clear "Needs" in your profile to check every scheme.`
      : "All schemes are checked. Pick one or more needs in your profile to focus the list.";
    if (!data.items.length) {
      box.innerHTML = `<div class="card">${stateBox("empty", "No schemes in this group", status === "eligible" ? "No scheme's recorded rules are fully met yet. Adding more profile details can help." : "Try another tab or level.")}</div>`;
    } else {
      box.innerHTML = `<div class="grid" style="gap:14px">${data.items.map((it) => `
        <article class="card">
          <div class="card-head"><div style="min-width:0">
            <div class="chips" style="margin-bottom:6px">${statusBadge(it.status)}${levelBadge(it.scheme.level_label)}${it.scheme.state ? `<span class="badge">${esc(it.scheme.state)}</span>` : ""}</div>
            <h3><a href="#/scheme/${encodeURIComponent(it.scheme.id)}" style="color:var(--text)">${esc(decodeEntities(it.scheme.name))}</a></h3>
            <p class="sub" style="margin:4px 0 0">${esc(it.summary)}</p></div>
            <div style="display:flex;gap:6px;flex-shrink:0">${saveButton({ id: it.scheme.id, name: it.scheme.name, level_label: it.scheme.level_label, state: it.scheme.state })}</div></div>
          ${it.scheme.description ? `<p style="margin:0 0 10px;color:var(--text-2);font-size:14px">${esc(decodeEntities(it.scheme.description))}</p>` : ""}
          <button class="btn btn-sm why-btn" data-id="${esc(it.scheme.id)}" aria-expanded="false">${icon("check")}Show the rule check</button>
          <div class="why-box"></div>
        </article>`).join("")}</div>`;
      bindSaveButtons(box);
      box.querySelectorAll(".why-btn").forEach((b) => b.addEventListener("click", async () => {
        const target = b.nextElementSibling;
        if (b.getAttribute("aria-expanded") === "true") { target.innerHTML = ""; b.setAttribute("aria-expanded", "false"); return; }
        b.setAttribute("aria-expanded", "true");
        target.innerHTML = loadingInline("Checking…");
        try { target.innerHTML = `<div style="margin-top:12px">${renderResult(await api("/eligibility/check", { method: "POST", body: { scheme_id: b.dataset.id, profile } }))}</div>`; }
        catch (e) { target.innerHTML = `<div class="alert error" style="margin-top:12px">${icon("alert")}<span>${esc(e.message)}</span></div>`; }
      }));
    }
    pagination(document.getElementById("rec-pager"), data.page, data.pages, (pg) => nav(status, level, pg));
  } catch (e) {
    if (e.name === "AbortError") return;
    box.innerHTML = `<div class="card">${stateBox("error", "Could not get recommendations", e.message, e.status === 422 ? '<a class="btn" href="#/eligibility" style="margin-top:12px">Fix my profile</a>' : "")}</div>`;
  }
}

/* ---------- AI assistant ---------- */
const SUGGESTIONS = [
  "Scholarships for SC students",
  "mai 23 saal ka hoon Bihar ke gaon mai rehta hu mujhe kaam chahiye",
  "किसानों के लिए कौन सी योजनाएं हैं?",
  "Loans for women entrepreneurs",
  "विधवा महिलाओं के लिए पेंशन योजना",
];

function renderAssistant() {
  view.innerHTML = `
    <div class="page-head"><div><h2>AI scheme assistant</h2><p>Answers are based on scheme records found in the database. Ask in English or हिंदी.</p></div>
      <div style="display:flex;gap:8px;align-items:center">
        <label class="sr-only" for="chat-lang">Reply language</label>
        <select class="input" id="chat-lang" style="width:auto"><option value="auto">Auto language</option><option value="en">English</option><option value="hi">हिंदी</option></select>
        <button class="btn" id="chat-clear">${icon("refresh")}New chat</button></div></div>
    <div id="ai-banner"></div>
    <section class="card chat" aria-label="Chat with the assistant">
      <div class="chat-log" id="chat-log" role="log" aria-live="polite"></div>
      <form class="chat-form" id="chat-form">
        <label class="sr-only" for="chat-input">Your question</label>
        <textarea class="input" id="chat-input" rows="1" maxlength="1000" placeholder="Ask about a scheme… (Enter to send, Shift+Enter for a new line)"></textarea>
        <label class="sr-only" for="chat-voice-lang">Voice input language</label>
        <select class="input" id="chat-voice-lang" aria-label="Voice input language" title="Voice input language" style="width:auto;max-width:112px;padding:8px 6px">
          <option value="en-IN">English</option><option value="hi-IN">हिंदी</option>
        </select>
        <button class="btn" type="button" id="chat-mic" aria-label="Start voice input" title="Speak in Hindi or English">${icon("mic")}</button>
        <button class="btn btn-primary" type="submit" id="chat-send" aria-label="Send">${icon("send")}</button>
      </form>
    </section>
    <p style="font-size:12.5px;color:var(--text-3);margin-top:10px">Never share Aadhaar numbers, bank details or OTPs in the chat.</p>`;
  const lang = document.getElementById("chat-lang");
  lang.value = chatState.language;
  lang.addEventListener("change", () => { chatState.language = lang.value; });
  document.getElementById("chat-clear").addEventListener("click", () => { chatState.history = []; chatState.log = []; drawChat(); });
  api("/ai/status").then((s) => {
    if (!s.configured) document.getElementById("ai-banner").innerHTML = `<div class="alert warn" style="margin-bottom:14px">${icon("alert")}<span>The AI service is not configured on the server. You will still get matching schemes from the database for every question.</span></div>`;
  }).catch(() => {});
  const input = document.getElementById("chat-input");
  setupVoiceInput(input);
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendChat(); } });
  input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = Math.min(140, input.scrollHeight) + "px"; });
  document.getElementById("chat-form").addEventListener("submit", (e) => { e.preventDefault(); sendChat(); });
  drawChat();
  input.focus();
}

function drawChat() {
  const log = document.getElementById("chat-log");
  if (!log) return;
  if (!chatState.log.length) {
    log.innerHTML = `<div class="msg bot"><div class="bubble">Namaste! I can help you find government schemes. Ask me about a benefit, a group of people, or a scheme by name.</div>
      <div class="suggestions">${SUGGESTIONS.map((s) => `<button type="button" data-s="${esc(s)}">${esc(s)}</button>`).join("")}</div></div>`;
    log.querySelectorAll(".suggestions button").forEach((b) => b.addEventListener("click", () => { document.getElementById("chat-input").value = b.dataset.s; sendChat(); }));
    return;
  }
  log.innerHTML = chatState.log.map((m) => {
    if (m.role === "user") return `<div class="msg user"><div class="bubble">${esc(m.text)}</div></div>`;
    if (m.role === "typing") return `<div class="msg bot"><div class="bubble"><span class="typing" aria-label="Assistant is typing"><span></span><span></span><span></span></span></div></div>`;
    if (m.role === "error") return `<div class="msg bot"><div class="alert error">${icon("alert")}<span>${esc(m.text)}</span></div></div>`;
    const refs = (m.schemes || []).map((s) => {
      const url = safeUrl(s.official_url);
      return `<div class="ref"><span style="min-width:0"><a class="name" href="#/scheme/${encodeURIComponent(s.id)}">${esc(decodeEntities(s.name))}</a><br><span style="color:var(--text-3);font-size:12px">${esc(s.level_label)}${s.state ? " · " + esc(s.state) : ""}</span>${s.match_status ? ` ${statusBadge(s.match_status)}` : ""}</span>
        ${url ? `<a class="btn btn-sm" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${icon("ext")}Official</a>` : ""}</div>`;
    }).join("");
    const und = m.understood && m.understood.reasons && m.understood.reasons.length
      ? `<details style="font-size:13px;color:var(--text-2)"><summary style="cursor:pointer">What I understood (${m.understood.reasons.length})</summary><ul style="margin:6px 0 0;padding-left:18px">${m.understood.reasons.map((r) => `<li>${esc(r)}</li>`).join("")}</ul>${m.understood.counts ? `<p style="margin:6px 0 0">Rule check: ${fmtNum(m.understood.counts.eligible)} eligible, ${fmtNum(m.understood.counts.maybe)} need more details. <a href="#/eligibility" data-use-profile='${esc(JSON.stringify(m.understood.profile || {}))}'>Open in eligibility checker</a></p>` : ""}</details>`
      : "";
    return `<div class="msg bot">${m.notice ? `<div class="alert warn" style="font-size:13px">${icon("alert")}<span>${esc(m.notice)}</span></div>` : ""}${und}
      <div class="bubble rich">${richText(m.text)}</div><div class="chat-voice-actions"><button type="button" class="btn btn-sm" data-speak="${esc(m.text)}" aria-label="Read response aloud">${icon("volume")}Listen</button></div>${refs ? `<div class="refs"><span style="font-size:12px;color:var(--text-3);font-weight:600">Schemes from the database</span>${refs}</div>` : ""}</div>`;
  }).join("");
  log.querySelectorAll("[data-use-profile]").forEach((a) => a.addEventListener("click", () => {
    const p = JSON.parse(a.dataset.useProfile);
    Object.keys(p).forEach((k) => { if (Array.isArray(p[k]) && !p[k].length) delete p[k]; });
    store.set(PROFILE_KEY, { ...(getProfile() || {}), ...p });
  }));
  log.querySelectorAll("[data-speak]").forEach((button) => {
    button.addEventListener("click", () => speakAssistant(button.getAttribute("data-speak") || ""));
  });
  log.scrollTop = log.scrollHeight;
}

let chatRecognition = null;
let chatListening = false;

function setupVoiceInput(input) {
  const mic = document.getElementById("chat-mic");
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!mic) return;

  if (!SpeechRecognition) {
    mic.disabled = true;
    mic.title = "Voice input is not supported in this browser. Try Google Chrome.";
    mic.setAttribute("aria-label", "Voice input not supported");
    return;
  }

  mic.addEventListener("click", () => {
    if (chatListening && chatRecognition) {
      chatRecognition.stop();
      return;
    }

    const recognition = new SpeechRecognition();
    chatRecognition = recognition;
    recognition.lang = document.getElementById("chat-voice-lang")?.value || "en-IN";
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    let finalTranscript = "";
    chatListening = true;
    mic.classList.add("voice-listening");
    mic.innerHTML = `${icon("mic-off")}<span class="sr-only">Stop listening</span>`;
    mic.title = "Stop voice input";
    mic.setAttribute("aria-label", "Stop voice input");
    toast(recognition.lang === "hi-IN" ? "सुन रहा हूँ… बोलना शुरू करें" : "Listening… speak now");

    recognition.onresult = (event) => {
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) finalTranscript += transcript;
        else interim += transcript;
      }
      input.value = [finalTranscript, interim].filter(Boolean).join(" ").trim();
      input.style.height = "auto";
      input.style.height = Math.min(140, input.scrollHeight) + "px";
    };

    recognition.onerror = (event) => {
      if (event.error !== "no-speech" && event.error !== "aborted") {
        toast(event.error === "not-allowed"
          ? "Microphone permission was denied. Allow microphone access in your browser."
          : "Voice recognition error: " + event.error, "error");
      }
    };

    recognition.onend = () => {
      chatListening = false;
      if (chatRecognition === recognition) chatRecognition = null;
      mic.classList.remove("voice-listening");
      mic.innerHTML = icon("mic");
      mic.title = "Speak in Hindi or English";
      mic.setAttribute("aria-label", "Start voice input");
      input.focus();
    };

    try { recognition.start(); }
    catch (error) {
      chatListening = false;
      mic.classList.remove("voice-listening");
      mic.innerHTML = icon("mic");
      toast("Could not start microphone. Please try again.", "error");
    }
  });
}

function speakAssistant(text) {
  if (!("speechSynthesis" in window) || !text) {
    toast("Spoken responses are not supported in this browser.", "error");
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  const hasHindi = /[\\u0900-\\u097F]/.test(text);
  utterance.lang = chatState.language === "hi" || (chatState.language === "auto" && hasHindi)
    ? "hi-IN" : "en-IN";
  window.speechSynthesis.speak(utterance);
}

async function sendChat() {
  const input = document.getElementById("chat-input");
  const send = document.getElementById("chat-send");
  const text = input.value.trim();
  if (!text || chatState.pending) return;
  if (text.length > 1000) { toast("Please keep questions under 1000 characters", "error"); return; }
  chatState.pending = true; send.disabled = true; input.value = ""; input.style.height = "auto";
  chatState.log.push({ role: "user", text });
  chatState.log.push({ role: "typing" });
  drawChat();
  try {
    const r = await api("/chat", { method: "POST", body: { message: text, history: chatState.history.slice(-6), language: chatState.language } });
    chatState.log.pop();
    chatState.log.push({ role: "bot", text: r.answer, schemes: r.schemes, notice: r.notice, understood: r.understood });
    chatState.history.push({ role: "user", content: text }, { role: "assistant", content: r.answer });
  } catch (e) {
    chatState.log.pop();
    chatState.log.push({ role: "error", text: e.message });
  } finally {
    chatState.pending = false; send.disabled = false; drawChat(); input.focus();
  }
}

/* ---------- saved ---------- */
function renderSaved() {
  const list = saved.all();
  view.innerHTML = `
    <div class="page-head"><div><h2>Saved schemes</h2><p>Saved in this browser only. Nothing is written to the database.</p></div>
      ${list.length ? `<button class="btn" id="clear-saved">${icon("trash")}Clear all</button>` : ""}</div>
    ${list.length ? `<div class="card" style="padding:0"><div class="table-wrap" style="border:0"><table class="data"><thead><tr><th scope="col">Scheme</th><th scope="col">Level</th><th scope="col">Saved</th><th scope="col"><span class="sr-only">Actions</span></th></tr></thead><tbody>
      ${list.map((s) => `<tr><td><a href="#/scheme/${encodeURIComponent(s.id)}" style="font-weight:600">${esc(decodeEntities(s.name))}</a>${s.state ? `<div style="color:var(--text-3);font-size:12.5px">${esc(s.state)}</div>` : ""}</td>
        <td>${levelBadge(s.level_label)}</td><td style="white-space:nowrap;color:var(--text-3)">${esc(new Date(s.saved_at).toLocaleDateString("en-IN"))}</td>
        <td style="text-align:right;white-space:nowrap"><a class="btn btn-sm" href="#/scheme/${encodeURIComponent(s.id)}">Open</a> <button class="btn btn-sm btn-ghost" data-remove="${esc(s.id)}" aria-label="Remove ${esc(s.name)}">${icon("x")}</button></td></tr>`).join("")}
      </tbody></table></div></div>`
      : `<div class="card">${stateBox("empty", "No saved schemes yet", "Use the Save button on any scheme to keep it here.", '<a class="btn btn-primary" href="#/search" style="margin-top:12px">Browse schemes</a>')}</div>`}`;
  view.querySelectorAll("[data-remove]").forEach((b) => b.addEventListener("click", () => {
    store.set(SAVED_KEY, saved.all().filter((s) => String(s.id) !== b.dataset.remove));
    updateSavedCount(); renderSaved(); toast("Removed from saved schemes");
  }));
  const clear = document.getElementById("clear-saved");
  if (clear) clear.addEventListener("click", () => {
    if (confirm("Remove all saved schemes from this device?")) { store.set(SAVED_KEY, []); updateSavedCount(); renderSaved(); }
  });
}

/* ---------- boot ---------- */
async function checkStatus() {
  const dbDot = document.getElementById("db-dot"), dbText = document.getElementById("db-status");
  const aiDot = document.getElementById("ai-dot"), aiText = document.getElementById("ai-status-text");
  try {
    const h = await api("/health");
    dbDot.className = "status-dot " + (h.database === "ok" ? "ok" : "err");
    dbText.textContent = h.database === "ok" ? "Database connected" : "Database unavailable";
    aiDot.className = "status-dot " + (h.ai === "configured" ? "ok" : "warn");
    aiText.textContent = h.ai === "configured" ? "AI assistant ready" : "AI not configured";
  } catch {
    dbDot.className = "status-dot err"; dbText.textContent = "Server unreachable";
    aiDot.className = "status-dot err"; aiText.textContent = "AI unavailable";
  }
}

document.querySelectorAll("[data-icon]").forEach((el) => { el.outerHTML = icon(el.dataset.icon); });
document.getElementById("top-search").addEventListener("submit", (e) => {
  e.preventDefault();
  const q = document.getElementById("top-q").value.trim();
  location.hash = "#/search" + (q ? "?q=" + encodeURIComponent(q) : "");
});
setupSidebar();
updateSavedCount();
checkStatus();
window.addEventListener("hashchange", route);
route();
