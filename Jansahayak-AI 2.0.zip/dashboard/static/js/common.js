/* Shared helpers for the citizen and admin dashboards. No secrets live here:
   all data comes from the FastAPI backend on the same origin. */
"use strict";

const API_BASE = (document.querySelector('meta[name="api-base"]') || {}).content || "/api";

const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1v-9.5Z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3 6.4 20.2l1.1-6.2L3 9.6l6.2-.9L12 3Z"/>',
  check: '<path d="M9 12.5 11.2 15 15.5 9.5"/><circle cx="12" cy="12" r="9"/>',
  chat: '<path d="M4 5h16v11H8l-4 4V5Z"/><path d="M8 10h8M8 13h5"/>',
  bookmark: '<path d="M6 3h12v18l-6-4-6 4V3Z"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 13 9 5 9-5"/>',
  map: '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Z"/><path d="M9 4v14M15 6v14"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  file: '<path d="M7 3h7l5 5v13H7V3Z"/><path d="M14 3v5h5"/>',
  shield: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3Z"/>',
  db: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
  cpu: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  table: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 10v10"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  ext: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v6H4V6h6"/>',
  arrowLeft: '<path d="M19 12H5M11 18l-6-6 6-6"/>',
  send: '<path d="M4 12 20 4l-6 16-3-7-7-1Z"/>',
  alert: '<path d="M12 3 2 20h20L12 3Z"/><path d="M12 10v4M12 17h.01"/>',
  inbox: '<path d="M3 13h5l1.5 3h5L16 13h5"/><path d="M5 5h14l2 8v6H3v-6l2-8Z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  logout: '<path d="M15 4h4v16h-4M10 8l-4 4 4 4M6 12h10"/>',
  refresh: '<path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/>',
  trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
  mic: '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 19v3M8 22h8"/>',
  "mic-off": '<path d="M9 9v3a3 3 0 0 0 5.1 2.1M15 9V5a3 3 0 0 0-5.8-1M5 10a7 7 0 0 0 11.7 5.2M19 10a7 7 0 0 1-.7 3.1M12 19v3M8 22h8M2 2l20 20"/>',
  volume: '<path d="M11 5 6 9H3v6h3l5 4V5Z"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/>',
};

function icon(name, cls = "") {
  return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ""}</svg>`;
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/** Only http(s) links are rendered; anything else (javascript:, data:) is dropped. */
function safeUrl(url) {
  try {
    const u = new URL(String(url), window.location.origin);
    return u.protocol === "http:" || u.protocol === "https:" ? u.href : null;
  } catch { return null; }
}

/** Decode HTML entities found in the scraped data (e.g. &#39;) without parsing HTML. */
function decodeEntities(text) {
  return String(text ?? "").replace(/&(#\d+|#x[0-9a-f]+|amp|lt|gt|quot|apos|nbsp);/gi, (m, e) => {
    const k = e.toLowerCase();
    if (k[0] === "#") return String.fromCodePoint(k[1] === "x" ? parseInt(k.slice(2), 16) : parseInt(k.slice(1), 10));
    return { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " }[k];
  });
}

/** Minimal, safe rendering of the scheme texts: escape everything first, then
    turn **bold**, "- " bullets and [Online]/[Offline] section labels into markup. */
function richText(text) {
  let h = esc(decodeEntities(text));
  h = h.replace(/\*{2,3}([^*\n]+?)\*{2,3}/g, "<strong>$1</strong>").replace(/\*{2,}/g, "");
  h = h.replace(/(^|\n)\s*[-•]\s+/g, "$1• ").replace(/([.:])-\s(?=<strong>)/g, "$1\n• ");
  h = h.replace(/\[(Online[^\]\n]*|Offline)\]/gi, '<span class="badge central">$1</span>');
  h = h.replace(/\n{3,}/g, "\n\n");
  return h;
}

function fmtNum(n) {
  if (n === null || n === undefined || Number.isNaN(n)) return "—";
  return new Intl.NumberFormat("en-IN").format(n);
}

function titleCase(s) {
  return String(s || "").replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

class ApiError extends Error {
  constructor(message, status, errors) { super(message); this.status = status; this.errors = errors || []; }
}

async function api(path, { method = "GET", body, params, signal } = {}) {
  let url = API_BASE + path;
  if (params) {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== "" && v !== false) qs.set(k, v); });
    const s = qs.toString();
    if (s) url += "?" + s;
  }
  let res;
  try {
    res = await fetch(url, {
      method, signal, credentials: "same-origin",
      headers: body ? { "Content-Type": "application/json" } : {},
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch (e) {
    if (e.name === "AbortError") throw e;
    throw new ApiError("Cannot reach the server. Check that the dashboard backend is running.", 0);
  }
  let data = null;
  try { data = await res.json(); } catch { /* non-JSON */ }
  if (!res.ok) {
    let msg = (data && typeof data.detail === "string") ? data.detail : `Request failed (HTTP ${res.status})`;
    throw new ApiError(msg, res.status, data && data.errors);
  }
  return data;
}

function toast(message, type = "info") {
  let wrap = document.querySelector(".toast-wrap");
  if (!wrap) {
    wrap = document.createElement("div");
    wrap.className = "toast-wrap";
    wrap.setAttribute("role", "status");
    wrap.setAttribute("aria-live", "polite");
    document.body.appendChild(wrap);
  }
  const t = document.createElement("div");
  t.className = "toast " + (type === "error" ? "error" : "");
  t.textContent = message;
  wrap.appendChild(t);
  setTimeout(() => t.remove(), 3800);
}

function stateBox(kind, title, text, actionHtml = "") {
  const ic = kind === "error" ? "alert" : kind === "empty" ? "inbox" : "search";
  return `<div class="state-box ${kind}" role="${kind === "error" ? "alert" : "status"}">${icon(ic)}<h4>${esc(title)}</h4><p>${esc(text)}</p>${actionHtml}</div>`;
}

function skeletonCards(n = 6) {
  return `<div class="scheme-list" aria-hidden="true">${Array.from({ length: n }, () => '<div class="card skeleton sk-card"></div>').join("")}</div><span class="sr-only" role="status">Loading…</span>`;
}

function loadingInline(text = "Loading…") {
  return `<div class="state-box" role="status"><div class="spinner dark" style="margin:0 auto 10px"></div><p>${esc(text)}</p></div>`;
}

function levelBadge(label) {
  const l = (label || "").toLowerCase();
  return `<span class="badge ${l === "central" ? "central" : "state"}">${esc(label || "—")}</span>`;
}

const STATUS_TEXT = { eligible: "Eligible", not_eligible: "Not eligible", needs_more_info: "Needs more information" };
function statusBadge(status) {
  return `<span class="badge ${esc(status)}">${esc(STATUS_TEXT[status] || titleCase(status))}</span>`;
}

function pagination(container, page, pages, onPage) {
  if (pages <= 1) { container.innerHTML = ""; return; }
  const btn = (p, label, opts = {}) =>
    `<button class="btn btn-sm ${p === page ? "current" : ""}" data-page="${p}" ${opts.disabled ? "disabled" : ""} ${p === page ? 'aria-current="page"' : ""} aria-label="${opts.aria || "Page " + p}">${label}</button>`;
  const parts = [btn(page - 1, "‹", { disabled: page <= 1, aria: "Previous page" })];
  const set = new Set([1, pages, page - 1, page, page + 1].filter((p) => p >= 1 && p <= pages));
  let last = 0;
  [...set].sort((a, b) => a - b).forEach((p) => {
    if (p - last > 1) parts.push('<span aria-hidden="true">…</span>');
    parts.push(btn(p, String(p)));
    last = p;
  });
  parts.push(btn(page + 1, "›", { disabled: page >= pages, aria: "Next page" }));
  container.innerHTML = `<nav class="pagination" aria-label="Pagination">${parts.join("")}</nav>`;
  container.querySelectorAll("button[data-page]").forEach((b) =>
    b.addEventListener("click", () => { if (!b.disabled) onPage(Number(b.dataset.page)); }));
}

/* ---------- browser-local storage (only on this device, never sent elsewhere) ---------- */
const store = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; }
  },
  remove(key) { try { localStorage.removeItem(key); } catch { /* ignore */ } },
};

function debounce(fn, ms = 300) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

/* ---------- Chart.js helpers ---------- */
const PALETTE = ["#2563eb", "#0d9488", "#7c3aed", "#f59e0b", "#db2777", "#0891b2", "#65a30d", "#ea580c", "#4f46e5", "#64748b"];
const charts = {};

function chartsAvailable() { return typeof window.Chart !== "undefined"; }

function renderChart(canvasId, config) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  if (!chartsAvailable()) {
    canvas.parentElement.innerHTML = stateBox("error", "Charts unavailable", "The Chart.js library could not be loaded (offline?). The numbers are still shown in the tables.");
    return;
  }
  if (charts[canvasId]) charts[canvasId].destroy();
  Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;
  Chart.defaults.color = "#64748b";
  charts[canvasId] = new Chart(canvas, config);
}

function barConfig(labels, values, { horizontal = false, label = "Schemes", color = PALETTE[0], onClick } = {}) {
  return {
    type: "bar",
    data: { labels, datasets: [{ label, data: values, backgroundColor: color, borderRadius: 6, maxBarThickness: 28 }] },
    options: {
      indexAxis: horizontal ? "y" : "x", responsive: true, maintainAspectRatio: false,
      plugins: { legend: { display: false }, tooltip: { callbacks: { label: (c) => ` ${fmtNum(c.parsed[horizontal ? "x" : "y"])} ${label.toLowerCase()}` } } },
      scales: {
        x: { grid: { display: !horizontal ? false : true, color: "#eef1f6" }, ticks: { autoSkip: !horizontal, maxRotation: 50 } },
        y: { grid: { display: horizontal ? false : true, color: "#eef1f6" }, beginAtZero: true },
      },
      onClick: onClick ? (_, els) => { if (els.length) onClick(labels[els[0].index]); } : undefined,
      onHover: onClick ? (e, els) => { e.native.target.style.cursor = els.length ? "pointer" : "default"; } : undefined,
    },
  };
}

function doughnutConfig(labels, values, colors = [PALETTE[0], PALETTE[1]], onClick) {
  return {
    type: "doughnut",
    data: { labels, datasets: [{ data: values, backgroundColor: colors, borderWidth: 3, borderColor: "#fff", hoverOffset: 6 }] },
    options: {
      responsive: true, maintainAspectRatio: false, cutout: "68%",
      plugins: { legend: { position: "bottom", labels: { usePointStyle: true, padding: 16 } } },
      onClick: onClick ? (_, els) => { if (els.length) onClick(labels[els[0].index]); } : undefined,
    },
  };
}

/* ---------- mobile sidebar ---------- */
function setupSidebar() {
  const sidebar = document.querySelector(".sidebar");
  const btn = document.querySelector(".menu-btn");
  if (!sidebar || !btn) return;
  let scrim = null;
  const close = () => { sidebar.classList.remove("open"); btn.setAttribute("aria-expanded", "false"); scrim && scrim.remove(); scrim = null; };
  btn.addEventListener("click", () => {
    if (sidebar.classList.contains("open")) return close();
    sidebar.classList.add("open");
    btn.setAttribute("aria-expanded", "true");
    scrim = document.createElement("div");
    scrim.className = "scrim";
    scrim.addEventListener("click", close);
    document.body.appendChild(scrim);
  });
  sidebar.addEventListener("click", (e) => { if (e.target.closest("a")) close(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
}
