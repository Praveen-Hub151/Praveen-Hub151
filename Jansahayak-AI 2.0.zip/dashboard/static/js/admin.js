/* Admin dashboard. Every request goes to /api/admin/*, which the server protects
   with an HttpOnly session cookie; this page only decides what to show. */
"use strict";

const view = document.getElementById("view");
const loginEl = document.getElementById("login");
const appEl = document.getElementById("admin-app");
let overviewCache = null;

/* ---------- auth ---------- */
async function adminApi(path, opts) {
  try {
    return await api("/admin" + path, opts);
  } catch (e) {
    if (e.status === 401) { showLogin("Your session has ended. Please sign in again."); }
    throw e;
  }
}

function showLogin(message) {
  appEl.hidden = true;
  loginEl.hidden = false;
  const msg = document.getElementById("login-msg");
  msg.innerHTML = message ? `<div class="alert warn">${icon("alert")}<span>${esc(message)}</span></div>` : "";
  setTimeout(() => document.querySelector('#login-form [name="username"]').focus(), 0);
}

function showApp(user) {
  loginEl.hidden = true;
  appEl.hidden = false;
  document.getElementById("who").innerHTML = `${icon("user")} Signed in as <strong>${esc(user.username)}</strong>`;
  route();
}

document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const form = e.target;
  const btn = document.getElementById("login-btn");
  const username = form.username.value.trim(), password = form.password.value;
  const msg = document.getElementById("login-msg");
  if (!username || !password) { msg.innerHTML = `<div class="alert error">${icon("alert")}<span>Enter your username and password.</span></div>`; return; }
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>Signing in…';
  try {
    const r = await api("/admin/login", { method: "POST", body: { username, password } });
    form.password.value = "";
    showApp(r);
  } catch (err) {
    msg.innerHTML = `<div class="alert error">${icon("alert")}<span>${esc(err.message)}</span></div>`;
  } finally {
    btn.disabled = false; btn.textContent = "Sign in";
  }
});

document.getElementById("logout").addEventListener("click", async () => {
  try { await api("/admin/logout", { method: "POST" }); } catch { /* ignore */ }
  overviewCache = null;
  showLogin("You have signed out.");
});

document.getElementById("refresh").addEventListener("click", async (e) => {
  const b = e.currentTarget;
  b.disabled = true;
  try { await adminApi("/cache/refresh", { method: "POST" }); overviewCache = null; toast("Statistics reloaded from the database"); route(); }
  catch (err) { if (err.status !== 401) toast(err.message, "error"); }
  finally { b.disabled = false; }
});

/* ---------- router ---------- */
const ROUTES = {
  overview: { title: "Overview", render: renderOverview },
  rules: { title: "Eligibility rules", render: renderRules },
  documents: { title: "Required documents", render: renderDocuments },
  schemes: { title: "Scheme table", render: renderSchemes },
  system: { title: "System health", render: renderSystem },
};

function route() {
  if (appEl.hidden) return;
  const raw = location.hash.replace(/^#\/?/, "");
  const [path, query = ""] = raw.split("?");
  const [name] = path.split("/");
  const key = ROUTES[name] ? name : "overview";
  document.querySelectorAll("#nav a").forEach((a) => {
    const on = a.dataset.route === key;
    a.classList.toggle("active", on);
    if (on) a.setAttribute("aria-current", "page"); else a.removeAttribute("aria-current");
  });
  document.getElementById("page-title").textContent = ROUTES[key].title;
  document.title = `${ROUTES[key].title} · JanSahayak-AI Admin`;
  ROUTES[key].render(new URLSearchParams(query));
  view.focus({ preventScroll: true });
}

const stat = (tone, ic, label, value, hint) =>
  `<div class="card stat tone-${tone}"><div class="icon">${icon(ic)}</div><div class="label">${esc(label)}</div><div class="value">${typeof value === "string" ? esc(value) : fmtNum(value)}</div><div class="hint">${esc(hint || "")}</div></div>`;

function barTable(rows, labelKey, valueKey, { labelHead = "Name", valueHead = "Schemes", link } = {}) {
  const max = Math.max(1, ...rows.map((r) => r[valueKey]));
  return `<div class="table-wrap"><table class="data"><thead><tr><th scope="col">${labelHead}</th><th scope="col" class="num">${valueHead}</th></tr></thead><tbody>
    ${rows.map((r) => `<tr><td>${link ? `<a href="${link(r)}">${esc(r[labelKey])}</a>` : esc(r[labelKey])}</td><td class="num"><div class="bar-cell" style="justify-content:flex-end"><span class="bar" style="width:${Math.round((r[valueKey] / max) * 120)}px"></span>${fmtNum(r[valueKey])}</div></td></tr>`).join("")}
  </tbody></table></div>`;
}

async function getOverview() {
  if (!overviewCache) overviewCache = await adminApi("/overview");
  return overviewCache;
}

function failBox(e) {
  if (e.status === 401) return;
  view.innerHTML = stateBox("error", "Could not load data", e.message, '<button class="btn" id="retry" style="margin-top:12px">Try again</button>');
  document.getElementById("retry").addEventListener("click", route);
}

/* ---------- overview ---------- */
async function renderOverview() {
  view.innerHTML = loadingInline("Loading statistics from PostgreSQL…");
  let o;
  try { o = await getOverview(); } catch (e) { return failBox(e); }
  const r = o.rules, d = o.documents;
  view.innerHTML = `
    <div class="page-head"><div><h2>Scheme database overview</h2><p>All numbers are computed live from the jansahayak_db tables.</p></div></div>
    <div class="grid grid-4">
      ${stat("blue", "layers", "Total schemes", o.total_schemes, `${fmtNum(o.states_covered)} states/UTs with state schemes`)}
      ${stat("teal", "shield", "Central schemes", o.central_schemes, `${((o.central_schemes / o.total_schemes) * 100 || 0).toFixed(1)}% of all schemes`)}
      ${stat("violet", "map", "State schemes", o.state_schemes, `${((o.state_schemes / o.total_schemes) * 100 || 0).toFixed(1)}% of all schemes`)}
      ${stat("amber", "check", "Eligibility rules", r.total_rules, `${fmtNum(r.schemes_with_rules)} schemes have rules`)}
    </div>
    <div class="grid grid-3" style="margin-top:18px">
      <div class="card"><h3>Central vs state</h3><p class="sub">schemes.level</p><div class="chart-box short"><canvas id="c-level" role="img" aria-label="Central versus state chart"></canvas></div></div>
      <div class="card span-2"><h3>Schemes by purpose (need)</h3><p class="sub">scheme_purposes.purpose, distinct schemes</p><div class="chart-box short"><canvas id="c-purpose" role="img" aria-label="Schemes by purpose chart"></canvas></div></div>
    </div>
    <div class="grid grid-2" style="margin-top:18px">
      <div class="card"><h3>Schemes by state</h3><p class="sub">State-level schemes, top ${Math.min(20, o.by_state.length)} of ${fmtNum(o.by_state.length)} states/UTs. Click a bar to list them.</p><div class="chart-box tall"><canvas id="c-state" role="img" aria-label="Schemes by state chart"></canvas></div></div>
      <div class="card"><h3>Schemes by myScheme category</h3><p class="sub">scheme_purposes.category</p><div class="chart-box tall"><canvas id="c-cat" role="img" aria-label="Schemes by category chart"></canvas></div></div>
    </div>
    <div class="grid grid-3" style="margin-top:18px">
      ${stat("blue", "file", "Document rows", d.total_rows, `${fmtNum(d.avg_documents_per_scheme)} per scheme on average`)}
      ${stat("teal", "check", "Schemes without rules", r.schemes_without_rules, "Decided as needs-review")}
      ${stat("violet", "target", "Categories", o.categories_total, `${fmtNum(o.top_purposes.length)} need values`)}
    </div>`;
  renderChart("c-level", doughnutConfig(["Central", "State"], [o.central_schemes, o.state_schemes], undefined,
    (l) => { location.hash = "#/schemes?level=" + l.toLowerCase(); }));
  renderChart("c-purpose", barConfig(o.purposes.map((p) => titleCase(p.purpose)), o.purposes.map((p) => p.count),
    { color: PALETTE[2], onClick: (l) => { location.hash = "#/schemes?purpose=" + l.toLowerCase().replace(/ /g, "_"); } }));
  const states = o.by_state.slice(0, 20);
  renderChart("c-state", barConfig(states.map((s) => s.state), states.map((s) => s.count),
    { horizontal: true, color: PALETTE[1], onClick: (l) => { location.hash = "#/schemes?state=" + encodeURIComponent(l); } }));
  renderChart("c-cat", barConfig(o.categories.map((c) => c.category), o.categories.map((c) => c.count),
    { horizontal: true, color: PALETTE[0], onClick: (l) => { location.hash = "#/schemes?category=" + encodeURIComponent(l); } }));
}

/* ---------- rules ---------- */
async function renderRules() {
  view.innerHTML = loadingInline("Loading rule statistics…");
  let r;
  try { r = await adminApi("/rules/stats"); } catch (e) { return failBox(e); }
  view.innerHTML = `
    <div class="page-head"><div><h2>Eligibility rule statistics</h2><p>eligibility_rules: same condition_group = OR, different groups = AND (schemas/eligibility_schema.py).</p></div></div>
    <div class="grid grid-4">
      ${stat("blue", "check", "Total rules", r.total_rules, `${fmtNum(r.required)} required · ${fmtNum(r.optional)} optional`)}
      ${stat("teal", "layers", "Schemes with rules", r.schemes_with_rules, `${fmtNum(r.avg_rules_per_scheme)} rules per scheme`)}
      ${stat("amber", "alert", "Schemes without rules", r.schemes_without_rules, "Need manual review of eligibility text")}
      ${stat("violet", "target", "OR groups", r.or_groups, "Groups with more than one rule")}
    </div>
    <div class="grid grid-2" style="margin-top:18px">
      <div class="card"><h3>Rules by profile field</h3><p class="sub">Which CitizenProfile fields the rules check</p><div class="chart-box"><canvas id="c-field" role="img" aria-label="Rules by field chart"></canvas></div></div>
      <div class="card"><h3>Rules per scheme</h3><p class="sub">How many rules each scheme has</p><div class="chart-box"><canvas id="c-per" role="img" aria-label="Rules per scheme chart"></canvas></div></div>
    </div>
    <div class="grid grid-2" style="margin-top:18px">
      <div class="card"><h3>Field coverage</h3>${barTable(r.by_field, "field", "schemes", { labelHead: "Field", valueHead: "Schemes" })}</div>
      <div class="card"><h3>Field and operator</h3><div class="table-wrap"><table class="data"><thead><tr><th scope="col">Field</th><th scope="col">Operator</th><th scope="col" class="num">Rules</th></tr></thead><tbody>
        ${r.by_field_operator.map((x) => `<tr><td>${esc(x.field)}</td><td><code>${esc(x.operator)}</code></td><td class="num">${fmtNum(x.count)}</td></tr>`).join("")}</tbody></table></div></div>
    </div>`;
  renderChart("c-field", barConfig(r.by_field.map((x) => x.field), r.by_field.map((x) => x.count), { label: "Rules", color: PALETTE[0] }));
  renderChart("c-per", barConfig(r.rules_per_scheme.map((x) => `${x.rules} rule${x.rules === 1 ? "" : "s"}`), r.rules_per_scheme.map((x) => x.schemes), { color: PALETTE[1] }));
}

/* ---------- documents ---------- */
async function renderDocuments() {
  view.innerHTML = loadingInline("Loading document statistics…");
  let d;
  try { d = await adminApi("/documents/stats", { params: { limit: 25 } }); } catch (e) { return failBox(e); }
  view.innerHTML = `
    <div class="page-head"><div><h2>Required document statistics</h2><p>scheme_documents, one row per (scheme, document) line.</p></div></div>
    <div class="grid grid-4">
      ${stat("blue", "file", "Document rows", d.total_rows, `${fmtNum(d.distinct_documents)} distinct wordings`)}
      ${stat("teal", "layers", "Schemes with documents", d.schemes_with_documents, `${fmtNum(d.avg_documents_per_scheme)} per scheme`)}
      ${stat("amber", "alert", "Schemes without documents", d.schemes_without_documents, "No document list recorded")}
      ${stat("violet", "target", "Most common", d.top_documents[0] ? d.top_documents[0].document : "—", d.top_documents[0] ? `${fmtNum(d.top_documents[0].schemes)} schemes` : "")}
    </div>
    <div class="grid grid-2" style="margin-top:18px">
      <div class="card"><h3>Document types</h3><p class="sub">Schemes whose document list mentions each keyword</p><div class="chart-box tall"><canvas id="c-kw" role="img" aria-label="Document types chart"></canvas></div></div>
      <div class="card"><h3>Most common document lines</h3><p class="sub">Exact wording, ignoring case and trailing punctuation</p>${barTable(d.top_documents, "document", "schemes", { labelHead: "Document" })}</div>
    </div>`;
  renderChart("c-kw", barConfig(d.by_keyword.map((x) => x.document), d.by_keyword.map((x) => x.schemes), { horizontal: true, color: PALETTE[2] }));
}

/* ---------- scheme table ---------- */
async function renderSchemes(params) {
  const p = { q: params.get("q") || "", state: params.get("state") || "", level: params.get("level") || "",
    purpose: params.get("purpose") || "", category: params.get("category") || "", page: Math.max(1, parseInt(params.get("page") || "1", 10) || 1) };
  view.innerHTML = `
    <div class="page-head"><div><h2>Scheme table</h2><p>Search all schemes and inspect their stored eligibility rules.</p></div></div>
    <form class="card" id="f" novalidate><div class="filters">
      <label class="field q">Search<input class="input" name="q" type="search" maxlength="120" value="${esc(p.q)}" placeholder="Name, slug, ministry, text…"></label>
      <label class="field">State<select class="input" name="state"><option value="">All</option></select></label>
      <label class="field">Level<select class="input" name="level"><option value="">All</option><option value="central">Central</option><option value="state">State</option></select></label>
      <label class="field">Purpose<select class="input" name="purpose"><option value="">All</option></select></label>
      <label class="field">Category<select class="input" name="category"><option value="">All</option></select></label>
    </div><div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px"><a class="btn btn-ghost" href="#/schemes">Reset</a><button class="btn btn-primary" type="submit">${icon("search")}Search</button></div></form>
    <div class="results-meta"><span id="count" role="status"></span></div>
    <div class="card" style="padding:0" id="table">${loadingInline()}</div><div id="pager"></div>`;
  const form = document.getElementById("f");
  form.level.value = p.level;
  api("/filters").then((f) => {
    f.states.forEach((s) => form.state.add(new Option(s, s, false, s === p.state)));
    f.purposes.forEach((s) => form.purpose.add(new Option(titleCase(s), s, false, s === p.purpose)));
    f.categories.forEach((s) => form.category.add(new Option(s, s, false, s === p.category)));
  }).catch(() => {});
  const go = (page = 1) => {
    const qs = new URLSearchParams();
    ["q", "state", "level", "purpose", "category"].forEach((k) => { const v = form[k].value.trim(); if (v) qs.set(k, v); });
    if (page > 1) qs.set("page", page);
    location.hash = "#/schemes" + (qs.toString() ? "?" + qs : "");
  };
  form.addEventListener("submit", (e) => { e.preventDefault(); go(); });
  ["state", "level", "purpose", "category"].forEach((k) => form[k].addEventListener("change", () => go()));
  let data;
  try { data = await adminApi("/schemes", { params: { ...p, page_size: 25 } }); } catch (e) {
    if (e.status !== 401) document.getElementById("table").innerHTML = stateBox("error", "Could not load schemes", e.message);
    return;
  }
  document.getElementById("count").textContent = `${fmtNum(data.total)} schemes · page ${data.page} of ${data.pages}`;
  document.getElementById("table").innerHTML = data.items.length ? `<div class="table-wrap" style="border:0"><table class="data">
    <thead><tr><th scope="col">Scheme</th><th scope="col">Level</th><th scope="col">State</th><th scope="col">Categories</th><th scope="col"><span class="sr-only">Actions</span></th></tr></thead><tbody>
    ${data.items.map((s) => `<tr><td><strong>${esc(decodeEntities(s.name))}</strong><div style="color:var(--text-3);font-size:12.5px"><code>${esc(s.id)}</code>${s.ministry || s.department ? " · " + esc(s.ministry || s.department) : ""}</div></td>
      <td>${levelBadge(s.level_label)}</td><td>${esc(s.state || "—")}</td><td><div class="chips">${s.categories.slice(0, 2).map((c) => `<span class="badge purpose">${esc(c)}</span>`).join("")}</div></td>
      <td style="text-align:right"><button class="btn btn-sm" data-open="${esc(s.id)}">Inspect</button></td></tr>`).join("")}
    </tbody></table></div>` : stateBox("empty", "No schemes found", "Change the search or filters.");
  view.querySelectorAll("[data-open]").forEach((b) => b.addEventListener("click", () => openScheme(b.dataset.open, b)));
  pagination(document.getElementById("pager"), data.page, data.pages, go);
}

async function openScheme(id, opener) {
  const backdrop = document.createElement("div");
  backdrop.className = "drawer-backdrop";
  const drawer = document.createElement("aside");
  drawer.className = "drawer";
  drawer.setAttribute("role", "dialog");
  drawer.setAttribute("aria-modal", "true");
  drawer.setAttribute("aria-labelledby", "drawer-title");
  drawer.innerHTML = `<header><h3 id="drawer-title">Loading…</h3><button class="btn btn-ghost btn-icon" aria-label="Close">${icon("x")}</button></header><div class="body">${loadingInline()}</div>`;
  document.body.append(backdrop, drawer);
  const close = () => { backdrop.remove(); drawer.remove(); document.removeEventListener("keydown", onKey); opener && opener.focus(); };
  const onKey = (e) => { if (e.key === "Escape") close(); };
  document.addEventListener("keydown", onKey);
  backdrop.addEventListener("click", close);
  drawer.querySelector("header button").addEventListener("click", close);
  drawer.querySelector("header button").focus();
  let d;
  try { d = await adminApi("/schemes/" + encodeURIComponent(id)); } catch (e) {
    drawer.querySelector(".body").innerHTML = stateBox("error", "Could not load scheme", e.message); return;
  }
  const s = d.scheme;
  drawer.querySelector("#drawer-title").textContent = decodeEntities(s.name);
  const kv = ["scheme_id", "level", "state", "ministry", "department", "beneficiary_type", "apply_mode", "apply_via_csc", "official_website", "official_application_url", "online_url", "scraped_at"]
    .filter((k) => k in s).map((k) => `<dt>${esc(k)}</dt><dd>${safeUrl(s[k]) && /^https?:/i.test(String(s[k])) ? `<a href="${esc(safeUrl(s[k]))}" target="_blank" rel="noopener noreferrer">${esc(s[k])}</a>` : esc(s[k] ?? "—")}</dd>`).join("");
  drawer.querySelector(".body").innerHTML = `
    <section><p class="section-title">Stored fields</p><dl class="kv">${kv}</dl></section>
    <section><p class="section-title">Categories and purposes</p><div class="chips">${d.categories.map((c) => `<span class="badge purpose">${esc(c)}</span>`).join("")}${d.purposes.map((c) => `<span class="badge">${esc(c)}</span>`).join("")}</div></section>
    <section><p class="section-title">Eligibility rules (${d.raw_rules.length})</p>
      ${d.raw_rules.length ? `<div class="table-wrap"><table class="data"><thead><tr><th scope="col">Rule</th><th scope="col">Group</th><th scope="col">Field</th><th scope="col">Op</th><th scope="col">Value</th><th scope="col">Req.</th></tr></thead><tbody>
        ${d.raw_rules.map((r) => `<tr><td><code>${esc(r.rule_id)}</code><div style="color:var(--text-3);font-size:12.5px">${esc(r.description || "")}</div></td><td>${esc(r.condition_group)}</td><td>${esc(r.field)}</td><td><code>${esc(r.operator)}</code></td><td><code>${esc(JSON.stringify(r.value))}</code></td><td>${r.required ? "Yes" : "No"}</td></tr>`).join("")}
      </tbody></table></div>
      <p class="sub" style="margin:8px 0 0">${d.rules.length} condition group(s). Rules in the same group are alternatives (any one is enough).</p>`
      : '<div class="alert warn">' + icon("alert") + '<span>No structured rules. The matcher reports this scheme as "no_rules" (needs review).</span></div>'}</section>
    <section><p class="section-title">Eligibility text (as published)</p><div class="prose">${richText(s.eligibility_text || "—")}</div></section>
    <section><p class="section-title">Documents (${d.documents.length})</p><ul class="doc-list">${d.documents.map((x) => `<li>${icon("file")}<span>${esc(decodeEntities(x))}</span></li>`).join("") || "<li>None recorded</li>"}</ul></section>
    <section><p class="section-title">How to apply (services/apply_mode.py)</p>${(d.apply.next_steps || []).map((l) => `<p style="margin:0 0 6px">${esc(l)}</p>`).join("")}</section>
    <a class="btn" href="/#/scheme/${encodeURIComponent(s.scheme_id)}" target="_blank" rel="noopener">${icon("ext")}Open the citizen view</a>`;
}

/* ---------- system ---------- */
async function renderSystem() {
  view.innerHTML = loadingInline("Checking database and services…");
  let s;
  try { s = await adminApi("/system"); } catch (e) { return failBox(e); }
  const db = s.database, ai = s.ai;
  view.innerHTML = `
    <div class="page-head"><div><h2>System health</h2><p>Database connection, table status and AI configuration.</p></div></div>
    <div class="grid grid-4">
      ${stat("teal", "db", "Database", db.status === "ok" ? "Connected" : "Error", `${db.database} · ${db.latency_ms} ms`)}
      ${stat("blue", "layers", "Database size", db.size, db.version.split(" on ")[0])}
      ${stat("violet", "shield", "Dashboard access", db.read_only === "on" ? "Read-only" : "Read/write", "Session transaction_read_only")}
      ${stat(ai.configured ? "teal" : "amber", "cpu", "AI assistant", ai.configured ? "Configured" : "Not configured", `${ai.provider} · ${ai.model}`)}
    </div>
    <div class="grid grid-2" style="margin-top:18px">
      <div class="card"><h3>Tables</h3><div class="table-wrap"><table class="data"><thead><tr><th scope="col">Table</th><th scope="col">Status</th><th scope="col" class="num">Rows</th><th scope="col" class="num">Columns</th></tr></thead><tbody>
        ${db.tables.map((t) => `<tr><td><code>${esc(t.table)}</code></td><td>${t.exists ? '<span class="badge eligible">OK</span>' : '<span class="badge not_eligible">Missing</span>'}</td><td class="num">${fmtNum(t.rows)}</td><td class="num">${t.columns.length}</td></tr>`).join("")}
      </tbody></table></div>
      <dl class="kv" style="margin-top:14px">
        <dt>apply_mode column</dt><dd>${db.apply_mode_column ? "Present" : "Missing (run database/add_apply_mode.py)"}</dd>
        <dt>citizen_profiles</dt><dd>${db.citizen_profiles_table ? "Present (written by main.py, not by the dashboard)" : "Not created yet"}</dd>
        <dt>Rules without scheme</dt><dd>${fmtNum(db.orphans.rules_without_scheme)}</dd>
        <dt>Schemes without documents</dt><dd>${fmtNum(db.orphans.schemes_without_documents)}</dd>
        <dt>Schemes without category</dt><dd>${fmtNum(db.orphans.schemes_without_purpose)}</dd>
        <dt>Server time</dt><dd>${esc(db.server_time)}</dd>
      </dl></div>
      <div class="card"><h3>AI service (Groq)</h3><p class="sub">The API key is read from .env on the server and never sent to the browser.</p>
        <dl class="kv"><dt>GROQ_API_KEY</dt><dd>${ai.configured ? "Set" : "Not set"}</dd><dt>GROQ_MODEL</dt><dd><code>${esc(ai.model)}</code></dd><dt>Endpoint</dt><dd><code>${esc(ai.base_url)}</code></dd></dl>
        <button class="btn" id="ping" style="margin-top:14px" ${ai.configured ? "" : "disabled"}>${icon("refresh")}Test connection</button>
        <div id="ping-result" style="margin-top:12px" role="status"></div>
        <h3 style="margin-top:22px">Dashboard settings</h3>
        <dl class="kv"><dt>Read-only connections</dt><dd>${s.settings.read_only_connections ? "Yes" : "No"}</dd><dt>Max page size</dt><dd>${s.settings.max_page_size}</dd><dt>Admin session</dt><dd>${s.settings.admin_session_minutes} minutes</dd></dl>
      </div>
    </div>`;
  const ping = document.getElementById("ping");
  ping.addEventListener("click", async () => {
    const out = document.getElementById("ping-result");
    ping.disabled = true; out.innerHTML = loadingInline("Contacting Groq…");
    try {
      const r = await adminApi("/ai/ping", { method: "POST" });
      out.innerHTML = r.ok
        ? `<div class="alert success">${icon("check")}<span>Groq reachable in ${r.latency_ms} ms. Model <code>${esc(ai.model)}</code> ${r.model_available ? "is available" : "was not found in your account's model list"}.</span></div>`
        : `<div class="alert error">${icon("alert")}<span>${esc(r.error)}</span></div>`;
    } catch (e) { out.innerHTML = `<div class="alert error">${icon("alert")}<span>${esc(e.message)}</span></div>`; }
    finally { ping.disabled = false; }
  });
}

/* ---------- boot ---------- */
document.querySelectorAll("[data-icon]").forEach((el) => { el.outerHTML = icon(el.dataset.icon); });
setupSidebar();
window.addEventListener("hashchange", route);
(async () => {
  try {
    const st = await api("/admin/config-status");
    if (!st.admin_configured) {
      showLogin("Admin login is not configured on the server. Run python scripts/hash_admin_password.py and add the lines it prints to .env, then restart the dashboard.");
      document.getElementById("login-btn").disabled = true;
      return;
    }
    showApp(await api("/admin/me"));
  } catch (e) {
    if (e.status === 401) showLogin();
    else showLogin(e.message);
  }
})();
