"""PostgreSQL access for the dashboard.

Uses the same .env settings as engine/db_rules.get_connection() (DB_HOST, DB_PORT,
DB_NAME, DB_USER, DB_PASSWORD) but keeps a small connection pool, because a web
server handles many requests. Every pooled connection is put in READ ONLY mode
(DASHBOARD_DB_READ_ONLY=true by default), so nothing the dashboard does can
change, delete or overwrite scheme records.
"""
from __future__ import annotations

import logging
import threading
import time
from contextlib import contextmanager
from typing import Any, Iterator

import psycopg2
import psycopg2.extras
from psycopg2 import pool as pg_pool
from psycopg2 import sql

from engine.db_rules import connection_settings

from .config import settings

log = logging.getLogger("dashboard.db")

_pool: pg_pool.ThreadedConnectionPool | None = None
_pool_lock = threading.Lock()

TABLES = ("schemes", "scheme_purposes", "scheme_documents", "eligibility_rules")


class DatabaseUnavailable(RuntimeError):
    """Raised when PostgreSQL cannot be reached."""


def get_pool() -> pg_pool.ThreadedConnectionPool:
    global _pool
    if _pool is None:
        with _pool_lock:
            if _pool is None:
                try:
                    _pool = pg_pool.ThreadedConnectionPool(
                        settings.db_pool_min, settings.db_pool_max,
                        **connection_settings(),   # DATABASE_URL (Render) or DB_HOST/DB_PORT/...
                        connect_timeout=5, application_name="jansahayak-dashboard",
                    )
                except psycopg2.OperationalError as exc:
                    raise DatabaseUnavailable(str(exc).strip()) from exc
    return _pool


def close_pool() -> None:
    global _pool
    if _pool is not None:
        _pool.closeall()
        _pool = None


@contextmanager
def get_conn() -> Iterator[psycopg2.extensions.connection]:
    """A pooled, read-only connection. Can be passed to the project's own
    functions (engine.scheme_matcher.match_schemes, engine.db_rules.load_rules ...),
    which only read."""
    pool = get_pool()
    try:
        conn = pool.getconn()
    except (psycopg2.OperationalError, pg_pool.PoolError) as exc:
        raise DatabaseUnavailable(str(exc).strip()) from exc
    broken = False
    try:
        if conn.readonly != settings.db_read_only:
            conn.set_session(readonly=settings.db_read_only, autocommit=False)
        yield conn
        conn.rollback()  # nothing to commit: ends the read transaction
    except psycopg2.OperationalError as exc:
        broken = True
        raise DatabaseUnavailable(str(exc).strip()) from exc
    except Exception:
        try:
            conn.rollback()
        except psycopg2.Error:
            broken = True
        raise
    finally:
        pool.putconn(conn, close=broken or conn.closed != 0)


def fetch_all(query: sql.Composable | str, params: Any = None) -> list[dict]:
    with get_conn() as conn, conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(query, params)
        return [dict(r) for r in cur.fetchall()]


def fetch_one(query: sql.Composable | str, params: Any = None) -> dict | None:
    rows = fetch_all(query, params)
    return rows[0] if rows else None


def fetch_value(query: sql.Composable | str, params: Any = None) -> Any:
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(query, params)
        row = cur.fetchone()
        return row[0] if row else None


class SchemaInfo:
    """Which tables/columns exist, so optional columns (apply_mode, added by
    database/add_apply_mode.py) are used only when present."""

    def __init__(self) -> None:
        self.columns: dict[str, list[str]] = {}
        self.loaded_at = 0.0
        self._lock = threading.Lock()

    def load(self, force: bool = False) -> "SchemaInfo":
        with self._lock:
            if self.columns and not force and time.time() - self.loaded_at < 600:
                return self
            rows = fetch_all(
                "SELECT table_name, column_name FROM information_schema.columns "
                "WHERE table_schema = 'public' AND table_name = ANY(%s) ORDER BY table_name, ordinal_position",
                (list(TABLES) + ["citizen_profiles"],),
            )
            cols: dict[str, list[str]] = {}
            for r in rows:
                cols.setdefault(r["table_name"], []).append(r["column_name"])
            self.columns = cols
            self.loaded_at = time.time()
            missing = [t for t in TABLES if t not in cols]
            if missing:
                log.warning("Tables missing from the database: %s (run database/import_schemes.py)", ", ".join(missing))
            return self

    def has(self, table: str, column: str | None = None) -> bool:
        cols = self.columns.get(table)
        if cols is None:
            return False
        return column is None or column in cols


schema_info = SchemaInfo()


def get_schema() -> SchemaInfo:
    return schema_info.load()
