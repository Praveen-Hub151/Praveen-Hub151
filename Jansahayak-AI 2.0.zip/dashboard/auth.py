"""Admin authentication (standard library only).

* Password stored only as a PBKDF2-SHA256 hash in .env (ADMIN_PASSWORD_HASH),
  generated with ``python scripts/hash_admin_password.py``.
* After login the server sets an HttpOnly, SameSite=Strict cookie holding an
  HMAC-signed, expiring token. JavaScript cannot read it.
* Every admin API route depends on ``require_admin`` so protection is enforced
  on the server, not only in the UI.
* Failed logins are rate limited per client IP.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time

from fastapi import HTTPException, Request, status

from .config import settings
from .passwords import PBKDF2_ITERATIONS, hash_password, verify_password  # noqa: F401

COOKIE_NAME = "jansahayak_admin"
_failures: dict[str, list[float]] = {}
MAX_FAILURES = 5
FAILURE_WINDOW = 300


def _sign(payload: bytes) -> str:
    return hmac.new(settings.secret_key.encode(), payload, hashlib.sha256).hexdigest()


def make_token(username: str) -> str:
    payload = json.dumps({"u": username, "exp": int(time.time()) + settings.admin_session_minutes * 60,
                          "n": secrets.token_hex(8)}, separators=(",", ":")).encode()
    return base64.urlsafe_b64encode(payload).decode().rstrip("=") + "." + _sign(payload)


def read_token(token: str) -> dict | None:
    try:
        b64, sig = token.rsplit(".", 1)
        payload = base64.urlsafe_b64decode(b64 + "=" * (-len(b64) % 4))
        if not hmac.compare_digest(_sign(payload), sig):
            return None
        data = json.loads(payload)
        if data.get("exp", 0) < time.time() or data.get("u") != settings.admin_username:
            return None
        return data
    except Exception:
        return None


def client_ip(request: Request) -> str:
    """The caller's IP. Behind Render's proxy every request comes from the proxy, so with
    TRUST_PROXY_HEADERS (on by default on Render) the last X-Forwarded-For entry is used:
    that one is added by the proxy itself, so a client cannot fake it."""
    if settings.trust_proxy:
        forwarded = request.headers.get("x-forwarded-for", "")
        last = forwarded.split(",")[-1].strip()
        if last:
            return last
    return request.client.host if request.client else "unknown"


class RateLimiter:
    """At most ``limit`` calls per ``window`` seconds per key (in memory, per server process)."""

    def __init__(self, limit_fn, window: int = 60) -> None:
        self.limit_fn, self.window, self.hits = limit_fn, window, {}

    def hit(self, key: str) -> bool:
        """Records a call; True if the key is over the limit."""
        now = time.time()
        recent = [t for t in self.hits.get(key, []) if now - t < self.window]
        limited = len(recent) >= self.limit_fn()
        if not limited:
            recent.append(now)
        self.hits[key] = recent
        if len(self.hits) > 5000:  # keep memory bounded
            for k in list(self.hits)[:2500]:
                self.hits.pop(k, None)
        return limited


def check_login_allowed(ip: str) -> None:
    now = time.time()
    recent = [t for t in _failures.get(ip, []) if now - t < FAILURE_WINDOW]
    _failures[ip] = recent
    if len(recent) >= MAX_FAILURES:
        raise HTTPException(status.HTTP_429_TOO_MANY_REQUESTS,
                            "Too many failed login attempts. Try again in a few minutes.")


def record_failure(ip: str) -> None:
    _failures.setdefault(ip, []).append(time.time())


def clear_failures(ip: str) -> None:
    _failures.pop(ip, None)


def authenticate(username: str, password: str) -> bool:
    if not settings.admin_configured:
        return False
    user_ok = hmac.compare_digest(username.encode(), settings.admin_username.encode())
    pass_ok = verify_password(password, settings.admin_password_hash)
    return user_ok and pass_ok


def require_admin(request: Request) -> dict:
    """FastAPI dependency protecting every admin endpoint."""
    if not settings.admin_configured:
        raise HTTPException(status.HTTP_503_SERVICE_UNAVAILABLE,
                            "Admin access is not configured. Set ADMIN_USERNAME, ADMIN_PASSWORD_HASH and DASHBOARD_SECRET_KEY in .env.")
    token = request.cookies.get(COOKIE_NAME)
    data = read_token(token) if token else None
    if not data:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Admin login required")
    return data
