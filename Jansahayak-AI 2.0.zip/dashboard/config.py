"""Dashboard settings, read from the project's existing .env file.

The database settings are the ones the project already has (DB_HOST, DB_PORT,
DB_NAME, DB_USER, DB_PASSWORD). New, optional settings: GROQ_API_KEY,
GROQ_MODEL, and the admin settings ADMIN_USERNAME, ADMIN_PASSWORD_HASH,
DASHBOARD_SECRET_KEY. See .env.example.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

log = logging.getLogger("dashboard.config")

PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = PACKAGE_DIR.parent

# .env lookup order: explicit DASHBOARD_ENV_FILE, project root, current directory.
_env_file = os.getenv("DASHBOARD_ENV_FILE")
for candidate in [_env_file, PROJECT_ROOT / ".env", Path.cwd() / ".env"]:
    if candidate and Path(candidate).is_file():
        load_dotenv(candidate, override=False)
        log.info("Loaded environment from %s", candidate)
        break


def _bool_env(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None or value == "":
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _int_env(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


@dataclass
class Settings:
    # Database: the same variables engine/db_rules.get_connection() reads.
    db_host: str = field(default_factory=lambda: os.getenv("DB_HOST", "localhost"))
    db_port: int = field(default_factory=lambda: _int_env("DB_PORT", 5432))
    db_name: str = field(default_factory=lambda: os.getenv("DB_NAME", "jansahayak_db"))
    db_user: str = field(default_factory=lambda: os.getenv("DB_USER", "postgres"))
    db_password: str = field(default_factory=lambda: os.getenv("DB_PASSWORD", ""))
    db_pool_min: int = field(default_factory=lambda: _int_env("DASHBOARD_DB_POOL_MIN", 1))
    db_pool_max: int = field(default_factory=lambda: _int_env("DASHBOARD_DB_POOL_MAX", 10))
    # Every dashboard connection is opened READ ONLY unless this is explicitly turned off.
    db_read_only: bool = field(default_factory=lambda: _bool_env("DASHBOARD_DB_READ_ONLY", True))

    # Groq (backend only, never sent to the browser).
    groq_api_key: str | None = field(default_factory=lambda: os.getenv("GROQ_API_KEY") or None)
    groq_model: str = field(default_factory=lambda: os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"))
    groq_base_url: str = field(default_factory=lambda: os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1"))
    groq_timeout: float = field(default_factory=lambda: float(os.getenv("GROQ_TIMEOUT", "30")))
    chat_rate_per_minute: int = field(default_factory=lambda: _int_env("CHAT_RATE_PER_MINUTE", 20))

    # Admin authentication.
    admin_username: str | None = field(default_factory=lambda: os.getenv("ADMIN_USERNAME") or None)
    admin_password_hash: str | None = field(default_factory=lambda: os.getenv("ADMIN_PASSWORD_HASH") or None)
    secret_key: str | None = field(default_factory=lambda: os.getenv("DASHBOARD_SECRET_KEY") or None)
    admin_session_minutes: int = field(default_factory=lambda: _int_env("ADMIN_SESSION_MINUTES", 60))
    # On Render (RENDER=true) the site is HTTPS, so the admin cookie is Secure by default.
    cookie_secure: bool = field(default_factory=lambda: _bool_env("ADMIN_COOKIE_SECURE", bool(os.getenv("RENDER"))))
    # Behind a proxy (Render, nginx) the client's real IP is in X-Forwarded-For.
    trust_proxy: bool = field(default_factory=lambda: _bool_env("TRUST_PROXY_HEADERS", bool(os.getenv("RENDER"))))

    # HTTP.
    api_prefix: str = field(default_factory=lambda: os.getenv("DASHBOARD_API_PREFIX", "/api").rstrip("/"))
    cors_origins: list[str] = field(
        default_factory=lambda: [o.strip() for o in os.getenv("DASHBOARD_CORS_ORIGINS", "").split(",") if o.strip()]
    )
    max_page_size: int = field(default_factory=lambda: _int_env("DASHBOARD_MAX_PAGE_SIZE", 50))
    max_body_mb: int = field(default_factory=lambda: _int_env("DASHBOARD_MAX_BODY_MB", 40))
    upload_rate_per_minute: int = field(default_factory=lambda: _int_env("UPLOAD_RATE_PER_MINUTE", 6))

    def __post_init__(self) -> None:
        # Older .env files have a plain ADMIN_PASSWORD (from dashboard_app.py). Accept it, hashed in
        # memory, so admin login works; ADMIN_PASSWORD_HASH is still preferred.
        plain = os.getenv("ADMIN_PASSWORD")
        if self.admin_username and not self.admin_password_hash and plain:
            from .passwords import hash_password
            self.admin_password_hash = hash_password(plain)
            log.warning("Using plain ADMIN_PASSWORD from .env. Prefer ADMIN_PASSWORD_HASH "
                        "(python scripts/hash_admin_password.py).")
        if self.admin_username and self.admin_password_hash and not self.secret_key:
            import secrets
            self.secret_key = secrets.token_hex(32)
            log.warning("DASHBOARD_SECRET_KEY is not set: using a random key, so admins are logged out "
                        "whenever the server restarts.")

    @property
    def admin_configured(self) -> bool:
        return bool(self.admin_username and self.admin_password_hash and self.secret_key)


settings = Settings()
