"""Eligibility for the dashboard, using the project's own logic unchanged.

* Rules are loaded exactly like engine/db_rules.load_rules().
* The decision is engine/eligibility_engine.evaluate_eligibility(), i.e.
  schemas/eligibility_schema.check_rules():
      same condition_group = OR, different groups = AND, required=False never blocks.
* "State scheme for another state" is decided the same way as in
  engine/scheme_matcher.match_schemes().
* Recommendations call engine/scheme_matcher.match_schemes() directly.

The dashboard only adds explanations: for each rule it shows the project's
check_rule() result (pass / fail / unknown) and the rule's own description.

Project statuses -> dashboard labels:
    eligible      -> Eligible
    not_eligible  -> Not eligible
    maybe         -> Needs more information (some profile fields are missing)
    no_rules      -> Needs more information (no structured rules; read the eligibility text)
"""
from __future__ import annotations

from typing import Any

from engine.db_rules import load_rules, load_scheme
from engine.eligibility_engine import evaluate_eligibility
from engine.scheme_matcher import match_schemes, missing_fields
from schemas.citizen_schema import CitizenProfile
from schemas.eligibility_schema import EligibilityRule, Result, check_rule

from .db import get_conn

ELIGIBLE, NOT_ELIGIBLE, NEEDS_INFO = "eligible", "not_eligible", "needs_more_info"
DASHBOARD_STATUS = {"eligible": ELIGIBLE, "not_eligible": NOT_ELIGIBLE, "maybe": NEEDS_INFO, "no_rules": NEEDS_INFO}

FIELD_LABELS = {
    "age": "Age", "gender": "Gender", "state": "State", "district": "District", "area": "Rural / urban",
    "education": "Education", "employment_status": "Employment status", "annual_income": "Annual income",
    "category": "Social category", "has_disability": "Disability", "disability_percent": "Disability %",
    "is_farmer": "Farmer", "land_owned_acres": "Land owned (acres)", "has_bank_account": "Bank account",
    "has_bpl_card": "BPL card", "has_aadhaar": "Aadhaar", "marital_status": "Marital status",
    "skills": "Skills", "owns_land": "Owns land", "has_house": "Has a house", "needs": "Needs",
}


def _fmt(field: str, value: Any) -> str:
    if value is None:
        return "not given"
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if hasattr(value, "value"):
        value = value.value
    if field == "annual_income" and isinstance(value, (int, float)):
        return f"₹{value:,.0f}"
    if isinstance(value, list):
        return ", ".join(_fmt(field, v) for v in value) or "none"
    return str(value).replace("_", " ")


def rule_text(rule: EligibilityRule) -> str:
    if rule.description:
        return rule.description
    op = rule.operator.value
    label = FIELD_LABELS.get(rule.field, rule.field)
    if op in ("is_true", "is_false"):
        return f"{label} must be {'Yes' if op == 'is_true' else 'No'}"
    return f"{label} {op} {_fmt(rule.field, rule.value)}"


def explain(rules: list[EligibilityRule], citizen: dict) -> list[dict]:
    """One entry per condition_group, each with the project's check_rule() result per rule."""
    groups: dict[Any, list[EligibilityRule]] = {}
    for r in rules:
        groups.setdefault(r.condition_group, []).append(r)
    out = []
    for group, group_rules in groups.items():
        checks = []
        for r in group_rules:
            res = check_rule(r, citizen)
            checks.append({
                "rule_id": r.rule_id, "field": r.field, "label": FIELD_LABELS.get(r.field, r.field),
                "operator": r.operator.value, "value": r.value, "required": r.required,
                "description": rule_text(r), "result": res.value,
                "your_value": _fmt(r.field, citizen.get(r.field)),
            })
        required = [c for c in checks if c["required"]]
        results = [c["result"] for c in required]
        if not required:
            group_status = "optional"
        elif Result.passed.value in results:
            group_status = "pass"
        elif Result.unknown.value in results:
            group_status = "unknown"
        else:
            group_status = "fail"
        out.append({"group": str(group), "any_of": len(required) > 1, "status": group_status, "rules": checks})
    return out


def _summary(native: str, groups: list[dict], missing: list[str], state_block: str | None) -> str:
    if state_block:
        return state_block
    if native == "eligible":
        return f"You meet all {sum(1 for g in groups if g['status'] == 'pass')} required condition(s) recorded for this scheme."
    if native == "not_eligible":
        failed = [r["description"] for g in groups if g["status"] == "fail" for r in g["rules"] if r["required"]]
        return "Not eligible: " + "; ".join(failed[:3]) + "."
    if native == "no_rules":
        return ("No structured eligibility rules are recorded for this scheme. "
                "Read the eligibility text below and confirm with the official source.")
    return "More information needed: add " + ", ".join(FIELD_LABELS.get(m, m) for m in missing) + " to decide."


def check_scheme(citizen: CitizenProfile, scheme_id: str) -> dict | None:
    citizen_dict = citizen.model_dump()
    with get_conn() as conn:
        scheme = load_scheme(conn, scheme_id)
        if scheme is None:
            return None
        rules = load_rules(conn, scheme_id)

    state_block = None
    if scheme["state"] and citizen.state and scheme["state"] != citizen.state:
        # Same rule as engine/scheme_matcher.match_schemes()
        native = "not_eligible"
        state_block = f"This is a {scheme['state']} state scheme and your state is {citizen.state}."
    elif not rules:
        native = "no_rules"
    else:
        native = evaluate_eligibility(citizen_dict, rules)

    groups = explain(rules, citizen_dict)
    missing = missing_fields(rules, citizen_dict) if native == "maybe" else []
    return {
        "scheme": {"id": scheme["scheme_id"], "name": scheme["scheme_name"], "state": scheme["state"],
                   "level": scheme["level"], "level_label": "Central" if scheme["level"] == "central" else "State"},
        "status": DASHBOARD_STATUS[native],
        "project_status": native,
        "summary": _summary(native, groups, missing, state_block),
        "missing_fields": missing,
        "groups": groups,
        "rule_count": len(rules),
        "engine": "engine.eligibility_engine.evaluate_eligibility",
    }


def match(citizen: CitizenProfile) -> dict[str, list[dict]]:
    """engine/scheme_matcher.match_schemes() on a pooled read-only connection."""
    with get_conn() as conn:
        return match_schemes(conn, citizen)


def explain_scheme_rules(scheme_id: str) -> list[dict]:
    with get_conn() as conn:
        rules = load_rules(conn, scheme_id)
    return explain(rules, {})
