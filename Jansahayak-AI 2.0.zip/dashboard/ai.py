"""AI scheme assistant (Groq, OpenAI-compatible chat completions API).

The API key is read on the server from GROQ_API_KEY and is never sent to the
browser. Every question first searches the scheme database; the model is told
to answer only from those records. If Groq is not configured or fails, the
endpoint still returns the matching schemes so the citizen is never left with
nothing.
"""
from __future__ import annotations

import logging
import re
import time
from typing import Any

import httpx

from .config import settings
from .queries import keyword_search_for_chat, schemes_by_ids

log = logging.getLogger("dashboard.ai")

DEVANAGARI = re.compile(r"[ऀ-ॿ]")
HINGLISH_HINTS = {"kya", "hai", "mujhe", "kaise", "liye", "yojana", "yojna", "chahiye", "batao", "kaun", "milega"}

SYSTEM_PROMPT = """You are JanSahayak, an assistant that helps Indian citizens discover government schemes.

Rules:
- Use ONLY the scheme records provided in the CONTEXT block for scheme-specific facts (names, benefits, eligibility, documents, links). If the records do not contain the answer, say so plainly and suggest checking the official website or the nearest Common Service Centre (CSC).
- Never invent schemes, amounts, deadlines, eligibility rules or URLs. Only mention a URL if it appears in the CONTEXT.
- Do not decide whether the user is eligible. Explain the stated conditions and suggest the Eligibility Checker in this dashboard for a rule-based check.
- Reply in {language}. Keep answers short, clear and practical, using bullet points where helpful. Refer to schemes by their exact names.
- Never ask for Aadhaar numbers, bank details, OTPs or passwords.
"""

_rate: dict[str, list[float]] = {}


def detect_language(text: str, preference: str | None = None) -> str:
    if preference in {"hi", "en"}:
        return preference
    if DEVANAGARI.search(text):
        return "hi"
    words = set(re.findall(r"[a-z]+", text.lower()))
    if len(words & HINGLISH_HINTS) >= 2:
        return "hi"
    return "en"


def rate_limited(client_id: str) -> bool:
    now = time.time()
    window = [t for t in _rate.get(client_id, []) if now - t < 60]
    if len(window) >= settings.chat_rate_per_minute:
        _rate[client_id] = window
        return True
    window.append(now)
    _rate[client_id] = window
    if len(_rate) > 5000:  # keep memory bounded
        for k in list(_rate)[:2500]:
            _rate.pop(k, None)
    return False


def ai_status() -> dict:
    return {
        "configured": bool(settings.groq_api_key),
        "provider": "Groq",
        "model": settings.groq_model,
        "base_url": settings.groq_base_url,
    }


def ping() -> dict:
    """Live check used by the admin dashboard. Lists models; does not spend tokens."""
    if not settings.groq_api_key:
        return {"ok": False, "error": "GROQ_API_KEY is not set"}
    started = time.perf_counter()
    try:
        r = httpx.get(f"{settings.groq_base_url}/models", headers={"Authorization": f"Bearer {settings.groq_api_key}"},
                      timeout=10)
        latency = round((time.perf_counter() - started) * 1000)
        if r.status_code != 200:
            return {"ok": False, "status_code": r.status_code, "latency_ms": latency,
                    "error": "Groq rejected the request (check the API key)" if r.status_code in (401, 403) else "Groq returned an error"}
        models = [m.get("id") for m in r.json().get("data", [])]
        return {"ok": True, "latency_ms": latency, "model_available": settings.groq_model in models}
    except httpx.HTTPError as exc:
        return {"ok": False, "error": f"Could not reach Groq: {exc.__class__.__name__}"}


def understand(message: str) -> dict:
    """Run the project's own rule-based extractor (agent/rule_based_extractor.py) on the
    message. If it finds what the person needs, match schemes with the project's
    engine. Returns {} when nothing useful was understood."""
    try:
        from agent.rule_based_extractor import extract_profile_with_reasons
        from .eligibility import match
    except ImportError as exc:  # pragma: no cover
        log.warning("Profile extractor unavailable: %s", exc)
        return {}
    profile, reasons = extract_profile_with_reasons(message)
    if not profile.needs:
        return {"reasons": reasons} if reasons else {}
    matched = match(profile)
    from engine.scheme_matcher import popular_schemes
    popular_no_rules = [s for s in matched["no_rules"] if s["scheme_id"] in popular_schemes()]
    picked = ([(s, "eligible") for s in matched["eligible"][:4]] + [(s, "maybe") for s in matched["maybe"][:2]]
              + [(s, "maybe") for s in popular_no_rules[:2]])
    details = schemes_by_ids([s["scheme_id"] for s, _ in picked])
    schemes = []
    for s, status in picked:
        d = details.get(s["scheme_id"])
        if d:
            schemes.append({**d, "match_status": "eligible" if status == "eligible" else "needs_more_info",
                            "missing": s.get("missing", [])})
    return {
        "reasons": reasons,
        "profile": profile.model_dump(mode="json", exclude_none=True, exclude={"citizen_id", "need_text"}),
        "counts": {"eligible": len(matched["eligible"]), "maybe": len(matched["maybe"])},
        "schemes": schemes,
    }


def _context_block(schemes: list[dict]) -> str:
    if not schemes:
        return "CONTEXT: No matching scheme records were found in the database."
    lines = ["CONTEXT (scheme records from the JanSahayak database):"]
    for i, s in enumerate(schemes, 1):
        lines.append(f"[{i}] {s.get('name')}")
        if s.get("match_status"):
            lines.append("    Rule check for this user: " + ("meets the recorded rules" if s["match_status"] == "eligible"
                         else "needs more details: " + ", ".join(s.get("missing") or [])))
        lines.append(f"    Level: {s.get('level_label')}" + (f" | State: {s['state']}" if s.get("state") else ""))
        if s.get("ministry"):
            lines.append(f"    Ministry/Department: {s['ministry']}")
        if s.get("categories"):
            lines.append(f"    Categories: {', '.join(s['categories'])}")
        if s.get("description"):
            lines.append(f"    Description: {s['description']}")
        if s.get("official_url"):
            lines.append(f"    Official link: {s['official_url']}")
    return "\n".join(lines)


def _fallback_answer(lang: str, schemes: list[dict], reason: str) -> str:
    if lang == "hi":
        head = "AI सहायक अभी उपलब्ध नहीं है।" if reason else ""
        if schemes:
            return (head + " आपके प्रश्न से मिलती-जुलती योजनाएं डेटाबेस में मिलीं, नीचे देखें। "
                    "पात्रता जांचने के लिए 'Eligibility Checker' का उपयोग करें।").strip()
        return (head + " आपके प्रश्न से मेल खाती कोई योजना नहीं मिली। कृपया अलग शब्दों में खोजें।").strip()
    head = "The AI assistant is unavailable right now." if reason else ""
    if schemes:
        return (head + " Here are schemes from the database that match your question. "
                "Use the Eligibility Checker to check the rules against your profile.").strip()
    return (head + " No schemes in the database matched your question. Try different keywords.").strip()


def answer(message: str, history: list[dict], language: str | None = None) -> dict:
    lang = detect_language(message, language)
    # Retrieval first: the latest message plus the previous user turn for follow-ups.
    prev_user = [h["content"] for h in history if h.get("role") == "user"][-1:]
    understood = understand(message)
    state = (understood.get("profile") or {}).get("state")
    schemes = keyword_search_for_chat(message, limit=5, state=state)
    if not schemes and prev_user:
        schemes = keyword_search_for_chat(prev_user[0] + " " + message, limit=5, state=state)
    # Profile matches first, then keyword matches, without duplicates.
    seen, combined = set(), []
    for s in (understood.get("schemes") or []) + schemes:
        if s["id"] not in seen:
            seen.add(s["id"])
            combined.append(s)
    schemes = combined[:7]

    base = {"language": lang, "schemes": schemes, "model": settings.groq_model,
            "understood": {k: understood[k] for k in ("reasons", "profile", "counts") if k in understood}}
    if not settings.groq_api_key:
        return {**base, "ai_available": False, "answer": _fallback_answer(lang, schemes, "not configured"),
                "notice": "AI is not configured on the server (GROQ_API_KEY missing). Showing database matches only."}

    messages: list[dict[str, Any]] = [
        {"role": "system", "content": SYSTEM_PROMPT.format(language="Hindi (Devanagari script)" if lang == "hi" else "English")},
    ]
    for h in history[-6:]:
        if h.get("role") in {"user", "assistant"} and isinstance(h.get("content"), str):
            messages.append({"role": h["role"], "content": h["content"][:2000]})
    messages.append({"role": "user", "content": f"{_context_block(schemes)}\n\nQUESTION: {message}"})

    try:
        r = httpx.post(
            f"{settings.groq_base_url}/chat/completions",
            headers={"Authorization": f"Bearer {settings.groq_api_key}", "Content-Type": "application/json"},
            json={"model": settings.groq_model, "messages": messages, "temperature": 0.2, "max_tokens": 700},
            timeout=settings.groq_timeout,
        )
        if r.status_code != 200:
            log.warning("Groq returned HTTP %s: %s", r.status_code, r.text[:300])
            return {**base, "ai_available": False, "answer": _fallback_answer(lang, schemes, "error"),
                    "notice": f"The AI service returned an error (HTTP {r.status_code}). Showing database matches only."}
        text = r.json()["choices"][0]["message"]["content"].strip()
        return {**base, "ai_available": True, "answer": text}
    except (httpx.HTTPError, KeyError, IndexError, ValueError) as exc:
        log.warning("Groq request failed: %s", exc)
        return {**base, "ai_available": False, "answer": _fallback_answer(lang, schemes, "error"),
                "notice": "The AI service could not be reached. Showing database matches only."}
