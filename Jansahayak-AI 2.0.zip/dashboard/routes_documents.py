"""Scheme page: required documents, upload + verification, "ready for the form".

    GET  /api/schemes/{scheme_id}/required-documents
    POST /api/schemes/{scheme_id}/verify-documents
         {"profile": {...}, "password": null,
          "files": [{"item": 1, "filename": "aadhaar.jpg", "data": "<base64>"}]}

Uses the project's own code unchanged:
    services/document_verifier.required_documents / verify_scheme_documents   (documents + checks)
    dashboard/eligibility.check_scheme -> engine/eligibility_engine            (rule checkmarks)

Privacy: uploaded files are written to a temporary folder only while they are read,
then deleted. Nothing is saved in the database (dashboard connections are read-only).
Only masked numbers are returned.
"""
from __future__ import annotations

import base64
import binascii
import logging
import os
import tempfile
from typing import Any, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from services.document_verifier import required_documents, verify_scheme_documents
from documents.document_profile import read_document, apply_documents
from documents.ocr import OCRNotInstalled, PasswordNeeded

from . import auth
from .config import settings
from .db import get_conn
from .eligibility import FIELD_LABELS, check_scheme
from .profile import build_profile

log = logging.getLogger("dashboard")
router = APIRouter(tags=["documents"])

ALLOWED = {".jpg", ".jpeg", ".png", ".pdf", ".webp", ".bmp", ".tif", ".tiff"}
MAX_FILES = 12
MAX_BYTES = 8 * 1024 * 1024          # 8 MB per file
EXTRA_FIRST = 1000                   # item numbers from 1000 = extra documents not in the scheme's list


# Reading documents (OCR) is slow and CPU heavy, so uploads are limited per client.
upload_limiter = auth.RateLimiter(lambda: settings.upload_rate_per_minute)


class UploadedFile(BaseModel):
    item: int = Field(..., ge=1, le=EXTRA_FIRST + 4)   # 1000+ = extra proof (e.g. income certificate)
    filename: str = Field(..., min_length=1, max_length=200)
    data: str = Field(..., min_length=1, max_length=12_000_000)   # base64


class VerifyRequest(BaseModel):
    profile: dict[str, Any] = Field(default_factory=dict)
    files: list[UploadedFile] = Field(default_factory=list, max_length=MAX_FILES)
    password: Optional[str] = Field(None, max_length=50)      # locked e-Aadhaar PDF


class ProfileUploadFile(BaseModel):
    filename: str = Field(..., min_length=1, max_length=200)
    data: str = Field(..., min_length=1, max_length=12_000_000)


class ExtractProfileRequest(BaseModel):
    profile: dict[str, Any] = Field(default_factory=dict)
    files: list[ProfileUploadFile] = Field(..., min_length=1, max_length=MAX_FILES)
    password: Optional[str] = Field(None, max_length=50)
    consent: bool = Field(..., description="Citizen confirms they are authorized to upload these documents")


def _scheme_items(scheme_id: str) -> list[dict]:
    if len(scheme_id) > 100:
        raise HTTPException(404, "Scheme not found")
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT 1 FROM schemes WHERE scheme_id = %s", (scheme_id,))
            if cur.fetchone() is None:
                raise HTTPException(404, "Scheme not found")
        return required_documents(conn, scheme_id)


DOC_LABEL = {"aadhaar": "Aadhaar", "income_certificate": "Income certificate", "bank_passbook": "Bank passbook",
             "caste_certificate": "Caste certificate", "ration_card": "Ration card",
             "domicile_certificate": "Domicile certificate", "disability_certificate": "Disability certificate"}


def form_data(uploaded: list[dict], profile) -> list[dict]:
    """The usual application-form fields, filled from the documents (Aadhaar first) and the profile.
    Each field: label, value, source (which document), note."""
    docs = sorted(uploaded, key=lambda d: d["type"] != "aadhaar")      # Aadhaar is the best source
    def pick(key, types=None):
        for d in docs:
            if (types is None or d["type"] in types) and d["details"].get(key) not in (None, ""):
                return d["details"][key], DOC_LABEL.get(d["type"], d["type"])
        return None, None

    p = profile.model_dump(mode="json")
    rows = []
    def add(label, value, source=None, note=""):
        if value is None and not note:
            return
        rows.append({"label": label, "value": "" if value is None else str(value),
                     "source": source or ("Your documents / profile" if value is not None else ""), "note": note})

    name, src = pick("name", {"aadhaar", "income_certificate", "caste_certificate", "bank_passbook"})
    add("Applicant name (as in Aadhaar)", name, src)
    rel, rsrc = pick("relation_name")
    relation, _ = pick("relation")
    add(f"{relation or 'Father'}'s / husband's name", rel, rsrc)
    dob, dsrc = pick("date_of_birth", {"aadhaar"})
    add("Date of birth", dob, dsrc)
    add("Age", p.get("age"), dsrc if dob else None)
    add("Gender", (p.get("gender") or "").title() or None)
    cat, csrc = pick("category", {"caste_certificate"})
    add("Category", (cat or p.get("category") or "").upper() or None, csrc)
    addr, asrc = pick("address")
    add("Address", addr, asrc)
    add("State", p.get("state"))
    pin, psrc = pick("pincode")
    add("PIN code", pin, psrc)
    add("Rural / urban", (p.get("area") or "").title() or None)
    income, isrc = pick("annual_income", {"income_certificate"})
    add("Annual family income (Rs)", f"{income:,.0f}" if income else (f"{p['annual_income']:,.0f}" if p.get("annual_income") else None), isrc)
    cert, csrc2 = pick("certificate_number", {"income_certificate"})
    add("Income certificate number", cert, csrc2)
    bank, bsrc = pick("bank", {"bank_passbook"})
    add("Bank name", bank, bsrc)
    ifsc, fsrc = pick("ifsc", {"bank_passbook"})
    add("IFSC code", ifsc, fsrc)
    acc, asrc2 = pick("account_number", {"bank_passbook"})
    add("Bank account number", acc, asrc2, "Only the last 4 digits are kept. Type the full number from your passbook." if acc else "")
    aad, adsrc = pick("aadhaar_number", {"aadhaar"})
    add("Aadhaar number", aad, adsrc, "Only the last 4 digits are kept. Type the full number from your card." if aad else "")
    add("Mobile number", None, None, "Type your mobile number (the one linked to Aadhaar).")
    return rows


AUTOFILL_KEYS = {   # form_data label (start) -> key used by the browser extension
    "Applicant name": "name", "Father": "father_name", "Husband": "father_name", "Date of birth": "dob",
    "Age": "age", "Gender": "gender", "Category": "category", "Address": "address", "State": "state",
    "PIN code": "pincode", "Rural / urban": "area", "Annual family income": "annual_income",
    "Income certificate number": "income_certificate_no", "Bank name": "bank_name", "IFSC code": "ifsc",
    "Bank account number": "account_number_masked", "Aadhaar number": "aadhaar_masked",
}


def autofill_fields(rows: list[dict], profile) -> dict:
    """Plain key -> value for the JanSahayak autofill browser extension (browser_extension/)."""
    out = {}
    for r in rows:
        key = next((k for start, k in AUTOFILL_KEYS.items() if r["label"].startswith(start)), None)
        if key and r["value"]:
            out[key] = r["value"].replace(",", "") if key == "annual_income" else r["value"]
    p = profile.model_dump(mode="json")
    for key in ("has_disability", "marital_status", "education", "employment_status", "district"):
        if p.get(key) is not None:
            out[key] = p[key]
    return out


@router.post("/documents/extract-profile")
def extract_profile_from_documents(body: ExtractProfileRequest, request: Request):
    """Extract profile fields from citizen-authorized uploads; files are deleted after processing."""
    if not body.consent:
        raise HTTPException(400, "Please confirm you are authorized to upload these documents.")
    if upload_limiter.hit(auth.client_ip(request)):
        raise HTTPException(429, "Too many uploads. Please wait a minute and try again.")

    base_profile = build_profile(body.profile)
    parsed_docs = []
    file_results = []
    with tempfile.TemporaryDirectory(prefix="jansahayak_profile_") as tmp:
        for index, uploaded in enumerate(body.files, start=1):
            ext = os.path.splitext(uploaded.filename)[1].lower()
            if ext not in ALLOWED and ext != ".txt":
                raise HTTPException(422, f"{uploaded.filename}: supported formats are PDF, JPG, PNG, WEBP, BMP, TIFF, and TXT")
            try:
                raw = base64.b64decode(uploaded.data, validate=True)
            except (binascii.Error, ValueError):
                raise HTTPException(422, f"{uploaded.filename}: the file could not be read")
            if not raw:
                raise HTTPException(422, f"{uploaded.filename}: empty file")
            if len(raw) > MAX_BYTES:
                raise HTTPException(422, f"{uploaded.filename}: file is larger than 8 MB")
            # Never use a client-supplied filename as a filesystem path.
            safe_name = f"{index}{ext}"
            path = os.path.join(tmp, safe_name)
            with open(path, "wb") as out:
                out.write(raw)
            try:
                parsed = read_document(path, body.password)
            except (OCRNotInstalled, PasswordNeeded) as exc:
                raise HTTPException(422, str(exc)) from None
            except Exception as exc:
                log.warning("Could not parse uploaded document %s: %s", uploaded.filename, type(exc).__name__)
                raise HTTPException(422, f"{uploaded.filename}: unable to read this file. Check the format or PDF password.") from None
            parsed["file"] = uploaded.filename
            parsed_docs.append(parsed)
            file_results.append({
                "filename": uploaded.filename,
                "type": parsed.get("type", "unknown"),
                "read_as": parsed.get("read_as", "document"),
                "fields_found": sorted(parsed.get("details", {}).keys()),
                "field_count": len(parsed.get("details", {})),
            })

    updated, _changes = apply_documents(base_profile, parsed_docs)
    profile_data = updated.model_dump(mode="json", exclude={"citizen_id", "need_text"})
    found = []
    for doc in parsed_docs:
        for key, value in doc.get("profile", {}).items():
            if value not in (None, ""):
                found.append({"field": key, "label": FIELD_LABELS.get(key, key.replace("_", " ").title()),
                              "value": getattr(value, "value", value), "source": doc["file"],
                              "document_type": doc.get("type", "unknown")})
    return {
        "profile": profile_data,
        "documents": file_results,
        "found_fields": found,
        "message": ("Extracted details are ready for your review." if found else
                    "No supported profile fields were found. Try a clearer image or a text-based PDF."),
        "privacy": "Files are processed temporarily and deleted after this request. Review extracted details before relying on them.",
    }


@router.get("/schemes/{scheme_id}/required-documents")
def get_required_documents(scheme_id: str):
    items = _scheme_items(scheme_id)
    return {"scheme_id": scheme_id, "items": items,
            "needed": sum(1 for i in items if i["kind"] != "info" and not i["optional"])}


@router.post("/schemes/{scheme_id}/verify-documents")
def verify_documents(scheme_id: str, body: VerifyRequest, request: Request):
    if upload_limiter.hit(auth.client_ip(request)):
        raise HTTPException(429, "Too many uploads. Please wait a minute and try again.")
    items = {i["number"]: i for i in _scheme_items(scheme_id)}
    profile = build_profile(body.profile)

    with tempfile.TemporaryDirectory(prefix="jansahayak_upload_") as tmp:
        uploads = {}
        for f in body.files:
            if f.item not in items and f.item < EXTRA_FIRST:
                raise HTTPException(422, f"Document number {f.item} does not exist for this scheme")
            ext = os.path.splitext(f.filename)[1].lower()
            if ext not in ALLOWED:
                raise HTTPException(422, f"{f.filename}: only photos (JPG/PNG) and PDF files can be uploaded")
            try:
                raw = base64.b64decode(f.data, validate=True)
            except (binascii.Error, ValueError):
                raise HTTPException(422, f"{f.filename}: the file could not be read")
            if len(raw) > MAX_BYTES:
                raise HTTPException(422, f"{f.filename}: file is larger than 8 MB")
            safe_name = f"{f.item}{ext}"                     # never use the browser's file name as a path
            path = os.path.join(tmp, safe_name)
            with open(path, "wb") as out:
                out.write(raw)
            uploads[f.item] = path

        with get_conn() as conn:
            result = verify_scheme_documents(conn, scheme_id, uploads, profile=profile, password=body.password)

    # Show the browser's file names, not the temporary ones
    names = {f.item: f.filename for f in body.files}
    by_path = {os.path.basename(p): names[n] for n, p in uploads.items()}
    for item in result["items"]:
        if item["file"] in by_path:
            item["file"] = by_path[item["file"]]

    # Eligibility again, now with the details read from the documents
    doc_profile = result["profile"]
    eligibility = check_scheme(doc_profile, scheme_id)
    before = profile.model_dump()
    found = [{"field": k, "label": FIELD_LABELS.get(k, k), "value": getattr(v, "value", v)}
             for k, v in doc_profile.model_dump().items()
             if k not in ("citizen_id", "need_text") and v not in (None, []) and before.get(k) != v]

    docs_ready = result["ready"]
    eligible = eligibility["status"] == "eligible"
    if docs_ready and eligible:
        message = "All eligibility conditions are met and all documents are verified. Ready for filling the form."
    elif not eligible and eligibility["status"] == "not_eligible":
        message = "Your documents show you do not meet this scheme's conditions (see the red items)."
    elif not docs_ready:
        message = "Some documents are still missing or need attention (see below)."
    else:
        message = "Documents are ready, but some eligibility details are still missing."

    for u in result["uploaded"]:
        u["file"] = by_path.get(u["file"], u["file"])

    return {
        "scheme_id": scheme_id,
        "form_data": (rows := form_data(result["uploaded"], doc_profile)),
        "autofill": autofill_fields(rows, doc_profile),
        "upload_guide": [{"document": i["name"], "file": i["file"]} for i in result["items"]
                         if i["file"] and i["status"] in ("verified", "manual_review")],
        "documents": {"summary": result["summary"], "ready": docs_ready, "items": result["items"]},
        "eligibility": eligibility,
        "found_in_documents": found,
        "profile": doc_profile.model_dump(mode="json", exclude={"citizen_id", "need_text"}),
        "ready_for_form": docs_ready and eligible,
        "message": message,
    }
