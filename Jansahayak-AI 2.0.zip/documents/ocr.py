
"""
ocr.py: Extract text from uploaded documents.

Supported formats:
- .txt: Direct text reading
- Text-based PDF: pdfplumber
- Scanned PDF: Tesseract OCR
- JPG / PNG / other supported images: OpenCV + Tesseract

Tesseract installation:
D:\\OCR\\tesseract.exe
"""

import logging
import os
import shutil
from pathlib import Path

import pytesseract

# Configure Tesseract executable
TESSERACT_EXE = r"D:\OCR\tesseract.exe"
pytesseract.pytesseract.tesseract_cmd = TESSERACT_EXE

# Suppress harmless PDF warnings
logging.getLogger("pdfminer").setLevel(logging.ERROR)

IMAGE_TYPES = {
    ".jpg", ".jpeg", ".png", ".bmp",
    ".tif", ".tiff", ".webp"
}

MAX_OCR_PAGES = 3


class PasswordNeeded(RuntimeError):
    pass


class OCRNotInstalled(RuntimeError):
    pass


def find_tesseract() -> str | None:
    """Find the Tesseract executable."""

    configured = os.getenv("TESSERACT_CMD")

    paths = [
        configured,
        TESSERACT_EXE,
        r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
        shutil.which("tesseract"),
    ]

    for path in paths:
        if path and os.path.isfile(path):
            return path

    return None


def ocr_image(image) -> str:
    """Extract text from a PIL image using Tesseract OCR."""

    import cv2
    import numpy as np

    exe = find_tesseract()

    if not exe:
        raise OCRNotInstalled(
            "Tesseract OCR was not found.\n"
            "Expected location: D:\\OCR\\tesseract.exe"
        )

    pytesseract.pytesseract.tesseract_cmd = exe

    # Convert image to grayscale
    gray = cv2.cvtColor(
        np.array(image.convert("RGB")),
        cv2.COLOR_RGB2GRAY
    )

    # Enlarge small images
    if gray.shape[1] < 1500:
        scale = 1500 / gray.shape[1]
        gray = cv2.resize(
            gray,
            None,
            fx=scale,
            fy=scale,
            interpolation=cv2.INTER_CUBIC
        )

    # Improve text readability
    clean = cv2.adaptiveThreshold(
        gray,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY,
        31,
        15
    )

    # Detect available languages
    try:
        langs = pytesseract.get_languages(config="")
    except pytesseract.TesseractError as exc:
        raise RuntimeError(
            f"Unable to load Tesseract language data: {exc}"
        ) from exc

    lang = "eng+hin" if "eng" in langs and "hin" in langs else "eng"

    return pytesseract.image_to_string(clean, lang=lang)


def read_text(
    path: str,
    password: str | None = None
) -> tuple[str, str]:
    """Return extracted text and the extraction method."""

    p = Path(path)

    if not p.exists():
        raise FileNotFoundError(f"File not found: {path}")

    ext = p.suffix.lower()

    # TXT files
    if ext == ".txt":
        return (
            p.read_text(encoding="utf-8", errors="replace"),
            "text file"
        )

    # PDF files
    if ext == ".pdf":
        import pdfplumber

        try:
            with pdfplumber.open(
                str(p),
                password=password or ""
            ) as pdf:

                text = "\n".join(
                    page.extract_text() or ""
                    for page in pdf.pages
                )

                if len(text.strip()) > 30:
                    return text, "PDF text"

                # Scanned PDF: convert pages to images
                images = [
                    page.to_image(resolution=250).original
                    for page in pdf.pages[:MAX_OCR_PAGES]
                ]

        except Exception as exc:
            if "password" in (
                type(exc).__name__ + repr(exc)
            ).lower():
                raise PasswordNeeded(
                    "This PDF is password protected. "
                    "Provide the correct PDF password."
                ) from None

            raise

        if not images:
            return "", "scanned PDF (OCR)"

        return (
            "\n".join(ocr_image(img) for img in images),
            "scanned PDF (OCR)"
        )

    # Image files
    if ext in IMAGE_TYPES:
        from PIL import Image

        with Image.open(str(p)) as img:
            return ocr_image(img), "photo (OCR)"

    raise ValueError(
        f"Unsupported file format: {ext}. "
        "Upload JPG, PNG, PDF or TXT."
    )
