"""extractors.py: finds the useful details in a document's text.

    Aadhaar              name, date of birth -> age, gender, state, pincode, Aadhaar number (masked)
    Income certificate   name, yearly income, state, certificate number
    Bank passbook        name, bank, IFSC, account number (masked)

Privacy: Aadhaar and account numbers are only ever kept MASKED (XXXX XXXX 1234).
"""
import re
from datetime import date

from agent.rule_based_extractor import STATES, find

AADHAAR_WORDS = ["aadhaar", "aadhar", "unique identification", "uidai", "government of india",
                 "आधार", "भारत सरकार"]
INCOME_WORDS = ["income certificate", "आय प्रमाण", "annual income", "वार्षिक आय", "income of"]
BANK_WORDS = ["passbook", "ifsc", "account no", "a/c no", "savings account", "bank", "खाता"]
BANKS = ["State Bank of India", "Punjab National Bank", "Bank of Baroda", "Canara Bank",
         "Union Bank of India", "Bank of India", "Indian Bank", "Central Bank of India",
         "Indian Overseas Bank", "UCO Bank", "Bank of Maharashtra", "Punjab & Sind Bank",
         "HDFC Bank", "ICICI Bank", "Axis Bank", "Kotak Mahindra Bank", "IDBI Bank",
         "India Post Payments Bank", "Airtel Payments Bank", "Gramin Bank", "Cooperative Bank"]


def mask(number: str) -> str:
    digits = re.sub(r"\D", "", number)
    return "XXXX XXXX " + digits[-4:] if len(digits) == 12 else "X" * (len(digits) - 4) + digits[-4:]


CASTE_WORDS = ["caste certificate", "community certificate", "jati praman", "जाति प्रमाण",
               "scheduled caste", "scheduled tribe", "other backward class", "अनुसूचित"]
DISABILITY_WORDS = ["disability certificate", "udid", "unique disability", "divyang", "दिव्यांग",
                    "विकलांगता", "percentage of disability", "% disability"]
RATION_WORDS = ["ration card", "राशन कार्ड", "public distribution", "food and civil supplies",
                "antyodaya", "priority household", "nfsa"]
DOMICILE_WORDS = ["domicile certificate", "residence certificate", "niwas praman", "निवास प्रमाण",
                  "permanent resident", "मूल निवास"]


def detect_type(text: str) -> str:
    low = text.lower()
    if find(low, INCOME_WORDS):
        return "income_certificate"
    if find(low, CASTE_WORDS):
        return "caste_certificate"
    if find(low, DISABILITY_WORDS):
        return "disability_certificate"
    if find(low, RATION_WORDS):
        return "ration_card"
    if find(low, DOMICILE_WORDS):
        return "domicile_certificate"
    if re.search(r"\b\d{4}\s\d{4}\s\d{4}\b", text) and find(low, AADHAAR_WORDS):
        return "aadhaar"
    if find(low, ["passbook", "ifsc"]) or re.search(r"\b[A-Z]{4}0[A-Z0-9]{6}\b", text):
        return "bank_passbook"
    if find(low, AADHAAR_WORDS):
        return "aadhaar"
    return "unknown"


def parse_date(text: str) -> date | None:
    m = re.search(r"(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})", text)
    if not m:
        return None
    day, month, year = map(int, m.groups())
    try:
        return date(year, month, day)
    except ValueError:
        return None


def age_on(born: date, today: date | None = None) -> int:
    today = today or date.today()
    return today.year - born.year - ((today.month, today.day) < (born.month, born.day))


def find_state(text: str) -> str | None:
    low = text.lower()
    for state, names in STATES.items():
        if find(low, names):
            return state
    return None


def find_gender(text: str) -> str | None:
    low = text.lower()
    if find(low, ["female", "महिला", "स्त्री"]):
        return "female"
    if find(low, ["male", "पुरुष"]):
        return "male"
    if find(low, ["transgender", "ट्रांसजेंडर"]):
        return "transgender"
    return None


def clean_name(name: str | None) -> str | None:
    if not name:
        return None
    name = re.sub(r"\s+", " ", re.sub(r"[^A-Za-z .]", " ", name)).strip(" .")
    return name.title() if 2 < len(name) < 60 else None


def money(text: str) -> float | None:
    """'Rs. 1,20,000/-' -> 120000, '1.5 lakh' -> 150000."""
    m = re.search(r"(\d[\d,]*(?:\.\d+)?)\s*(lakh|lac|लाख)", text, re.I)
    if m:
        return float(m.group(1).replace(",", "")) * 100000
    m = re.search(r"(\d[\d,]{2,}(?:\.\d+)?)", text)
    return float(m.group(1).replace(",", "")) if m else None


# ---------- one function per document type ----------

def extract_aadhaar(text: str) -> dict:
    out = {}
    if m := re.search(r"\b(\d{4}\s?\d{4}\s?\d{4})\b", text):
        out["aadhaar_number"] = mask(m.group(1))

    dob_line = re.search(r"(?:DOB|D\.O\.B|Date of Birth|जन्म तिथि|जन्मतिथि)\s*[:/]?\s*([^\n]+)", text, re.I)
    born = parse_date(dob_line.group(1)) if dob_line else None
    if born:
        out["date_of_birth"] = born.strftime("%d/%m/%Y")
        out["age"] = age_on(born)
    elif m := re.search(r"(?:Year of Birth|YOB|जन्म वर्ष)\s*[:/]?\s*(\d{4})", text, re.I):
        out["age"] = date.today().year - int(m.group(1))

    # The name is usually the English line just above the DOB line
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    for i, line in enumerate(lines):
        if re.search(r"DOB|Date of Birth|Year of Birth|जन्म", line, re.I):
            for prev in reversed(lines[max(0, i - 3):i]):
                name = clean_name(prev)
                if name and not re.search(r"government|india|aadhaar|uidai", name, re.I):
                    out["name"] = name
                    break
            break

    if gender := find_gender(text):
        out["gender"] = gender
    if state := find_state(text):
        out["state"] = state
    if m := re.search(r"\b(\d{6})\b(?!\s?\d)", re.sub(r"\b\d{4}\s?\d{4}\s?\d{4}\b", "", text)):
        out["pincode"] = m.group(1)
    return out


def extract_income_certificate(text: str) -> dict:
    out = {}
    m = re.search(r"(?:annual|yearly|वार्षिक)\s*(?:family\s*)?(?:income|आय)[^\n\d₹]{0,60}"
                  r"((?:rs\.?|₹|inr|रु\.?)?\s*\d[\d,]*(?:\.\d+)?\s*(?:lakh|lac|लाख)?)", text, re.I)
    m = m or re.search(r"income[^\n\d₹]{0,60}((?:rs\.?|₹|inr)?\s*\d[\d,]*(?:\.\d+)?\s*(?:lakh|lac)?)",
                       text, re.I)
    if m and (amount := money(m.group(1))) and amount >= 1000:
        out["annual_income"] = amount

    m = re.search(r"certif(?:y|ied) that\s*(?:shri|smt|sri|kumari|km|mr|mrs|ms)?\.?\s*([A-Za-z .]+?)"
                  r"\s*(?:,|\bs/o\b|\bd/o\b|\bw/o\b|\bson\b|\bdaughter\b|\bwife\b|\bresident\b|\br/o\b)",
                  text, re.I)
    if m and (name := clean_name(m.group(1))):
        out["name"] = name
    if m := re.search(r"(?:certificate|cert\.?)\s*(?:no|number)\.?\s*[:.-]?\s*([A-Z0-9/\-]{5,})", text, re.I):
        out["certificate_number"] = m.group(1)
    if state := find_state(text):
        out["state"] = state
    return out


def extract_bank_passbook(text: str) -> dict:
    out = {}
    if m := re.search(r"(?:a/c|acct|account)\s*(?:no|number)?\.?\s*[:.-]?\s*(\d{9,18})", text, re.I):
        out["account_number"] = "X" * (len(m.group(1)) - 4) + m.group(1)[-4:]
    if m := re.search(r"\b([A-Z]{4}0[A-Z0-9]{6})\b", text):
        out["ifsc"] = m.group(1)
    for bank in BANKS:
        if bank.lower() in text.lower():
            out["bank"] = bank
            break
    m = re.search(r"(?:customer name|account holder(?:'s)? name|name)\s*[:.-]\s*([A-Za-z .]+)", text, re.I)
    if m and (name := clean_name(m.group(1))):
        out["name"] = name
    return out


EXTRACTORS = {"aadhaar": extract_aadhaar,
              "income_certificate": extract_income_certificate,
              "bank_passbook": extract_bank_passbook}


def holder_name(text: str) -> str | None:
    """'Name: Ramesh Kumar' or 'certify that Shri Ramesh Kumar, S/O ...'."""
    m = re.search(r"(?:^|\n)\s*(?:name(?: of (?:the )?(?:applicant|holder|head))?)\s*[:.-]\s*([A-Za-z .]+)",
                  text, re.I)
    m = m or re.search(r"certif(?:y|ied) that\s*(?:shri|smt|sri|kumari|km|mr|mrs|ms)?\.?\s*([A-Za-z .]+?)"
                       r"\s*(?:,|\bs/o\b|\bd/o\b|\bw/o\b|\bson\b|\bdaughter\b|\bwife\b|\bresident\b|\br/o\b)",
                       text, re.I)
    return clean_name(m.group(1)) if m else None


def extract_caste_certificate(text: str) -> dict:
    out = {"name": holder_name(text)}
    low = text.lower()
    if find(low, ["scheduled tribe", "अनुसूचित जनजाति", "s.t.", "st category"]):
        out["category"] = "st"
    elif find(low, ["scheduled caste", "अनुसूचित जाति", "s.c.", "sc category"]):
        out["category"] = "sc"
    elif find(low, ["other backward", "obc", "पिछड़ा"]):
        out["category"] = "obc"
    elif find(low, ["economically weaker", "ews"]):
        out["category"] = "ews"
    if state := find_state(text):
        out["state"] = state
    return {k: v for k, v in out.items() if v}


def extract_disability_certificate(text: str) -> dict:
    out = {"name": holder_name(text), "has_disability": True}
    if m := re.search(r"(\d{1,3})\s*%", text):
        out["disability_percent"] = int(m.group(1))
    if m := re.search(r"\budid\b[^\n\d]{0,20}([A-Z]{2}\d{14,16})", text, re.I):
        out["udid"] = "XXXX" + m.group(1)[-4:]
    return {k: v for k, v in out.items() if v is not None}


def extract_ration_card(text: str) -> dict:
    out = {"name": holder_name(text)}
    low = text.lower()
    if find(low, ["bpl", "below poverty", "antyodaya", "aay", "priority household", "phh"]):
        out["has_bpl_card"] = True
    if state := find_state(text):
        out["state"] = state
    return {k: v for k, v in out.items() if v}


def extract_domicile_certificate(text: str) -> dict:
    out = {"name": holder_name(text), "state": find_state(text)}
    return {k: v for k, v in out.items() if v}


EXTRACTORS.update({"caste_certificate": extract_caste_certificate,
                   "disability_certificate": extract_disability_certificate,
                   "ration_card": extract_ration_card,
                   "domicile_certificate": extract_domicile_certificate})

# Which CitizenProfile fields each document can prove
PROFILE_FIELDS = {"age", "gender", "state", "annual_income", "category", "has_disability",
                  "disability_percent", "has_bpl_card"}
PROVES = {"aadhaar": {"has_aadhaar": True}, "bank_passbook": {"has_bank_account": True},
          "income_certificate": {}}


RELATION = {"s": "Father", "d": "Father", "w": "Husband", "c": "Parent"}


def relation_name(text: str) -> dict:
    """'S/O Suresh Kumar' / 'D/O Ramesh Prasad' / 'W/O ...' -> father's or husband's name."""
    m = re.search(r"\b([SDWC])\s?/\s?O\.?\s*:?\s*(?:shri|smt|sri|late)?\.?\s*([A-Za-z .]+?)\s*(?:,|\n|$)",
                  text, re.I)
    if m and (name := clean_name(m.group(2))):
        return {"relation": RELATION[m.group(1).lower()], "relation_name": name}
    return {}


def address(text: str) -> str | None:
    """The 'Address:' line (without the S/O part), or the 'resident of ...' phrase."""
    m = re.search(r"(?:address|पता)\s*[:.-]\s*([^\n]+)", text, re.I)
    m = m or re.search(r"resident of\s+(.+?)(?:,\s*(?:has|belongs|is)\b|\.\s|$)", text, re.I | re.S)
    if not m:
        return None
    addr = re.sub(r"\b[SDWC]\s?/\s?O\.?\s*:?[^,]*,\s*", "", m.group(1), flags=re.I)
    addr = " ".join(addr.split()).strip(" ,.")
    return addr or None


def extract(text: str, doc_type: str | None = None) -> dict:
    """text -> {"type", "details", "profile"}  (profile = fields for CitizenProfile)."""
    doc_type = doc_type or detect_type(text)
    details = EXTRACTORS.get(doc_type, lambda t: {})(text)
    if doc_type in ("aadhaar", "income_certificate", "caste_certificate", "domicile_certificate"):
        details.update({k: v for k, v in relation_name(text).items() if k not in details})
        if (addr := address(text)) and "address" not in details:
            details["address"] = addr
    profile = {k: v for k, v in details.items() if k in PROFILE_FIELDS}
    profile.update(PROVES.get(doc_type, {}))
    return {"type": doc_type, "details": details, "profile": profile}
