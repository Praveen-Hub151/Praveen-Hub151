"""read_document.py: try the document reader on one file.

Run from the JanSahayak-AI folder:
    python documents/read_document.py tests/sample_documents/aadhaar_sample.txt
    python documents/read_document.py "C:\\Users\\tjain\\Pictures\\my_aadhaar.jpg"
    python documents/read_document.py e_aadhaar.pdf --password ABCD2000

Nothing is saved by this command; it only shows what was found.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from documents.document_profile import LABELS, read_document
from documents.ocr import OCRNotInstalled


def main():
    sys.stdout.reconfigure(errors="replace")
    args = sys.argv[1:]
    password = None
    if "--password" in args:
        i = args.index("--password")
        password = args[i + 1]
        args = args[:i] + args[i + 2:]
    if not args:
        print(__doc__)
        return 1

    try:
        doc = read_document(args[0], password)
    except OCRNotInstalled as e:
        print(e)
        return 1
    except Exception as e:
        print("Could not read the file:", e)
        return 1

    print(f"File      : {doc['file']}   (read as {doc['read_as']})")
    print(f"Document  : {LABELS.get(doc['type'], doc['type'])}")
    print("Found     :")
    for key, value in doc["details"].items():
        print(f"   {key:18} {value}")
    if not doc["details"]:
        print("   no Aadhaar / income / bank / caste / ration / domicile / disability details.")
        print("   That is fine for a photo or marksheet (a person checks those). Otherwise try a clearer photo.")
    print("Fills profile with:", doc["profile"] or "nothing")
    return 0


if __name__ == "__main__":
    sys.exit(main())
