"""document_profile.py: uses uploaded documents to fill the CitizenProfile,
ticks off required documents for each scheme, and saves what was found.

Rules:
    - A detail from a document is PROOF, so it replaces what the chat guessed
      (e.g. you typed "23 saal" but Aadhaar says born 2000 -> age from Aadhaar).
      Every change is listed so the user can see it.
    - Only masked numbers are saved (XXXX XXXX 1234). The photo itself is never stored.
"""
import json
from datetime import datetime, timezone
from pathlib import Path

from documents.extractors import extract
from documents.ocr import read_text
from schemas.citizen_schema import CitizenProfile

PROFILES_DIR = Path(__file__).resolve().parent.parent / "data" / "profiles"
LABELS = {"aadhaar": "Aadhaar", "income_certificate": "Income certificate",
          "bank_passbook": "Bank passbook", "caste_certificate": "Caste certificate",
          "disability_certificate": "Disability certificate", "ration_card": "Ration card",
          "domicile_certificate": "Domicile certificate", "unknown": "Other document (photo, marksheet ...)"}

# Words in a scheme's "required documents" list that each uploaded document covers
COVERS = {
    "aadhaar": ["aadhaar", "aadhar", "uid", "identity proof", "proof of identity", "id proof",
                "address proof", "proof of address", "age proof", "proof of age", "date of birth"],
    "income_certificate": ["income certificate", "income proof", "proof of income", "income"],
    "bank_passbook": ["bank", "passbook", "account", "cancelled cheque", "ifsc"],
}


def read_document(path: str, password: str | None = None) -> dict:
    """File -> {"file", "read_as", "type", "details", "profile"}."""
    text, how = read_text(path, password)
    result = extract(text)
    return {"file": Path(path).name, "read_as": how, **result}


def apply_documents(profile: CitizenProfile, docs: list[dict]) -> tuple[CitizenProfile, list[str]]:
    """Put document details into the profile. Returns (new profile, list of changes)."""
    data = profile.model_dump()
    changes = []
    for doc in docs:
        for field, value in doc["profile"].items():
            old = data.get(field)
            old = getattr(old, "value", old)
            if old == value:
                continue
            data[field] = value
            label = LABELS.get(doc["type"], doc["type"])
            changes.append(f"{field}: {old} -> {value}   (from {label})" if old is not None
                           else f"{field} = {value}   (from {label})")
    return CitizenProfile(**data), changes


def document_checklist(required: list[str], uploaded_types: set[str]) -> list[tuple[bool, str]]:
    """For each required document of a scheme: (already uploaded?, document name)."""
    checklist = []
    for name in required:
        low = name.lower()
        done = any(any(word in low for word in COVERS[t]) for t in uploaded_types if t in COVERS)
        checklist.append((done, name))
    return checklist


# ---------- saving ----------

CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS citizen_documents (
    id          SERIAL PRIMARY KEY,
    session_id  VARCHAR(100) NOT NULL,   -- same as citizen_profiles.session_id
    file_name   TEXT,
    doc_type    VARCHAR(30),             -- aadhaar / income_certificate / bank_passbook / unknown
    details     JSONB,                   -- what was found (numbers masked)
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
)"""


def save_documents(session_id: str, docs: list[dict], conn=None) -> str:
    """Save to PostgreSQL table citizen_documents, or a JSON file if that fails."""
    rows = [(session_id, d["file"], d["type"], json.dumps(d["details"], ensure_ascii=False)) for d in docs]
    try:
        from engine.db_rules import get_connection
        own_conn = conn is None
        conn = conn or get_connection()
        with conn, conn.cursor() as cur:
            cur.execute(CREATE_TABLE)
            cur.executemany("INSERT INTO citizen_documents (session_id, file_name, doc_type, details) "
                            "VALUES (%s, %s, %s, %s)", rows)
        if own_conn:
            conn.close()
        return "PostgreSQL table citizen_documents"
    except Exception:
        PROFILES_DIR.mkdir(parents=True, exist_ok=True)
        path = PROFILES_DIR / f"{session_id}_documents.json"
        path.write_text(json.dumps({"session_id": session_id, "documents": docs,
                                    "saved_at": datetime.now(timezone.utc).isoformat()},
                                   ensure_ascii=False, indent=2), encoding="utf-8")
        return str(path)
