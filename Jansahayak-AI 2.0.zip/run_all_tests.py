"""run_all_tests.py: runs every test file in tests/ and prints one summary line each.

Run from the JanSahayak-AI folder:
    python run_all_tests.py
"""
import subprocess
import sys
from pathlib import Path

TESTS = [  # in the order the project was built
    ("Stage 1  Eligibility engine (fake schemes)", "tests/test_eligibility.py"),
    ("Stage 3  Rules from PostgreSQL", "tests/test_db_eligibility.py"),
    ("Stage 3  Scheme matcher (all schemes)", "tests/test_scheme_matcher.py"),
    ("Stage 4  Rule-based profile extractor", "tests/test_rule_based_extractor.py"),
    ("Stage 4  Sentence -> schemes (main.py)", "tests/test_pipeline.py"),
    ("Stage 5  Follow-up questions + saving", "tests/test_followup.py"),
    ("Stage 6  Scheme details, documents, links", "tests/test_scheme_service.py"),
    ("Stage 7  Online / offline apply mode", "tests/test_apply_mode.py"),
    ("Stage 8  Documents: Aadhaar, income, passbook", "tests/test_documents.py"),
    ("Stage 9  Per-scheme document verification", "tests/test_document_verifier.py"),
    ("Dashboard  API, eligibility parity, security", "tests/test_dashboard.py"),
    ("Dashboard  Scheme page: upload + verify + ready", "tests/test_scheme_page.py"),
    ("Extension  Autofill safety checks", "tests/test_extension.py"),
]

root = Path(__file__).resolve().parent
all_ok = True
for label, path in TESTS:
    result = subprocess.run([sys.executable, str(root / path)], cwd=root,
                            capture_output=True, text=True, encoding="utf-8", errors="replace")
    lines = (result.stdout.strip() or result.stderr.strip() or "no output").splitlines()
    ok = result.returncode == 0
    all_ok &= ok
    print(f"[{'OK  ' if ok else 'FAIL'}] {label:45} {lines[-1]}")

print("\nEverything works." if all_ok else "\nSomething failed: run that test file alone to see why.")
sys.exit(0 if all_ok else 1)
