"""rule_based_extractor.py: a FREE profile extractor (no AI, no API key, no internet).

It reads the message and applies rules we wrote ourselves, like:
    "23 saal"           -> age = 23
    "gaon" / "गाँव"      -> area = rural
    "kaam chahiye"      -> employment_status = unemployed, needs = [employment]

It returns a CitizenProfile, which engine/scheme_matcher.py uses to find schemes.

Weak point: it only knows the words in the lists below. If it misses something,
add the word to the right list.

Run from the JanSahayak-AI folder:
    python agent/rule_based_extractor.py "mai 23 saal ka hoon gaon mai rehta hu mujhe kaam chahiye"
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))   # so "schemas" can be imported

from schemas.citizen_schema import CitizenProfile  # noqa: E402

# ---------- word lists (add more words here) ----------

RURAL = ["gaon", "gao", "gaanv", "gav", "village", "dehat", "dehaat", "gramin", "grameen",
         "rural", "गाँव", "गांव", "ग्राम", "देहात", "ग्रामीण"]
URBAN = ["shahar", "shehar", "sheher", "city", "town", "urban", "शहर", "नगर"]

MALE = ["ladka", "aadmi", "purush", "male", "man", "boy", "लड़का", "पुरुष", "आदमी",
        # Hindi grammar: "main ... rehta/karta hoon" or "23 saal ka hoon" is a man speaking
        "rehta", "rahta", "karta", "ka hoon", "ka hu", "ka hun", "रहता", "करता", "का हूँ", "का हूं"]
FEMALE = ["ladki", "aurat", "mahila", "female", "woman", "girl", "widow", "vidhwa",
          "लड़की", "महिला", "औरत", "विधवा",
          "rehti", "rahti", "karti", "ki hoon", "ki hu", "ki hun", "रहती", "करती", "की हूँ", "की हूं"]

WANT = ["chahiye", "chaiye", "cahiye", "chahie", "chahiye", "chahte", "chahta", "chahti",
        "want", "need", "looking", "dhundh", "चाहिए", "चाहता", "चाहती"]

UNEMPLOYED = ["berozgar", "berojgar", "unemployed", "jobless", "kaam nahi", "naukri nahi",
              "बेरोजगार", "बेरोज़गार"]
FARMER = ["kisan", "kisaan", "farmer", "किसान", "कृषक"]   # "kheti aati hai" is a skill, not a farmer
LABOURER = ["mazdoor", "majdoor", "mazdoori", "majduri", "labour", "labourer", "dihadi",
            "daily wage", "मजदूर", "मज़दूर", "मजदूरी", "दिहाड़ी"]
SELF_EMPLOYED = ["dukaan", "dukan", "shop", "business", "vyapar", "apna kaam", "दुकान", "व्यापार"]
HOMEMAKER = ["housewife", "homemaker", "grihini", "गृहिणी"]
RETIRED = ["retired", "retire", "sevanivritt", "रिटायर", "सेवानिवृत्त"]
STUDENT = ["student", "chhatra", "chatra", "padhta", "padhti", "छात्र", "छात्रा", "पढ़ता", "पढ़ती"]
DISABILITY = ["viklang", "divyang", "disabled", "disability", "handicapped",
              "विकलांग", "दिव्यांग"]
BPL = ["bpl", "garibi rekha", "गरीबी रेखा", "बीपीएल"]

# ----- skills: "X aata hai" = a skill, "X sikhna hai" = needs training -----
SKILLS = {
    "agriculture": ["agriculture", "kheti", "khethi", "krishi", "farming", "kheti badi", "खेती", "कृषि"],
    "animal_husbandry": ["pashupalan", "dairy", "doodh", "gaay", "bhains", "bakri", "poultry",
                         "murgi", "पशुपालन", "डेयरी"],
    "fishing": ["machli", "machhli", "fishing", "मछली"],
    "tailoring": ["silai", "silayi", "sewing", "tailor", "tailoring", "darzi", "सिलाई", "दर्जी"],
    "weaving_handicraft": ["bunai", "weaving", "handicraft", "kadhai", "embroidery", "बुनाई", "कढ़ाई"],
    "construction": ["mistri", "raj mistri", "mason", "chinai", "construction", "मिस्त्री"],
    "carpentry": ["carpenter", "carpentry", "badhai", "lakdi ka kaam", "बढ़ई"],
    "electrician": ["electrician", "bijli ka kaam", "wiring", "बिजली का काम"],
    "plumbing": ["plumber", "plumbing", "प्लंबर"],
    "welding": ["welding", "welder", "वेल्डिंग"],
    "painting": ["painter", "painting", "putai", "पुताई"],
    "driving": ["driving", "driver", "gaadi chalana", "gadi chalana", "ड्राइविंग", "ड्राइवर"],
    "mechanic": ["mechanic", "repair", "repairing", "मैकेनिक"],
    "computer": ["computer", "typing", "कंप्यूटर"],
    "cooking": ["cooking", "khana banana", "cook", "halwai", "खाना बनाना"],
    "beauty": ["beauty parlour", "parlour", "mehendi", "mehndi", "makeup", "ब्यूटी पार्लर"],
}
KNOWS = ["aata", "aati", "aate", "ata", "ati", "janta", "jaanta", "janti", "jaanti",
         "experience", "anubhav", "expert", "skilled", "know", "knows", "karta", "karti",
         "karte", "आता", "आती", "जानता", "जानती", "अनुभव", "करता", "करती"]
LEARN = ["sikhna", "seekhna", "sikhni", "seekhni", "sikhana", "training", "learn",
         "सीखना", "प्रशिक्षण"]

# ----- things a person has / doesn't have ("jamin nahi hai" -> owns_land = False) -----
LAND = ["jamin", "jameen", "zameen", "zamin", "bhumi", "khet", "land", "ज़मीन", "जमीन", "भूमि", "खेत"]
HOUSE = ["ghar", "makaan", "makan", "house", "home", "घर", "मकान"]
BANK = ["khata", "account", "खाता"]
AADHAAR = ["aadhaar", "aadhar", "adhar", "aadhar card", "आधार"]
NOT = ["nahi", "nahin", "nhi", "nai", "na", "no", "not", "dont", "don't", "without", "bina",
       "नहीं", "नही", "ना", "बिना"]
HAS = ["hai", "he", "h", "hain", "have", "has", "own", "owns", "है", "हैं"]

# ----- education (checked top to bottom, so "post graduate" wins over "graduate") -----
EDUCATION = [
    ("postgraduate", ["post graduate", "postgraduate", "m.a", "msc", "m.sc", "mba", "mcom",
                      "m.com", "mtech", "m.tech", "phd", "स्नातकोत्तर"]),
    ("graduate", ["graduate", "graduation", "b.a", "bsc", "b.sc", "bcom", "b.com", "btech",
                  "b.tech", "degree", "स्नातक"]),
    ("diploma_iti", ["iti", "diploma", "polytechnic", "आईटीआई"]),
    ("class_12", ["intermediate", "inter pass", "barahvi", "बारहवीं"]),
    ("class_10", ["matric", "high school", "dasvi", "दसवीं"]),
    ("none", ["anpadh", "unpadh", "illiterate", "अनपढ़"]),
]

MARITAL = [   # widowed first: "pati ki maut" must not become married
    ("widowed", ["vidhwa", "widow", "widower", "vidhur", "pati ki maut", "pati nahi rahe",
                 "विधवा", "विधुर"]),
    ("divorced", ["talak", "talaq", "divorced", "divorce", "तलाक"]),
    ("single", ["unmarried", "kunwara", "kunwari", "avivahit", "single", "अविवाहित", "कुंवारा"]),
    ("married", ["shadi shuda", "shaadi shuda", "shadishuda", "shaadi ho gayi", "shadi ho gayi",
                 "shaadi ho gai", "shadi ho gai", "shaadi hui", "shadi hui", "married", "vivahit", "patni",
                 "biwi", "pati", "शादीशुदा", "विवाहित", "पत्नी", "पति"]),
]

CATEGORY = {
    "sc": ["sc", "dalit", "scheduled caste", "anusuchit jati", "अनुसूचित जाति", "दलित"],
    "st": ["st", "adivasi", "tribal", "scheduled tribe", "anusuchit janjati",
           "अनुसूचित जनजाति", "आदिवासी"],
    "obc": ["obc", "pichda", "pichhda", "backward class", "पिछड़ा", "ओबीसी"],
    "ews": ["ews"],
    "general": ["general", "samanya", "सामान्य"],
}

# A need word counts when it appears together with a "want" word (see NEED_ALWAYS for exceptions)
NEEDS = {
    "employment": ["kaam", "naukri", "nokri", "job", "rozgar", "rojgar", "work",
                   "काम", "नौकरी", "रोजगार", "रोज़गार"],
    "loan": ["loan", "karz", "karza", "karj", "rin", "लोन", "कर्ज", "कर्ज़", "ऋण"],
    # plain "ghar" is not enough: "ghar ki kamai" (family income) is not a housing need
    "housing": ["ghar chahiye", "ghar banana", "ghar ke liye", "pakka ghar", "apna ghar", "makaan",
                "makan", "awas", "house", "घर चाहिए", "पक्का घर", "मकान", "आवास"],
    "education": ["padhai", "scholarship", "school", "college", "fees", "पढ़ाई", "छात्रवृत्ति", "शिक्षा"],
    "health": ["ilaj", "ilaaj", "bimari", "hospital", "dawai", "treatment", "इलाज", "बीमारी", "अस्पताल"],
    "pension": ["pension", "पेंशन"],
    "agriculture": ["kheti", "agriculture", "beej", "khad", "fasal", "krishi", "tractor", "बीज", "खाद", "फसल", "कृषि"],
    "skill_training": ["training", "skill", "kaushal", "sikhna", "प्रशिक्षण", "कौशल"],
}
NEED_ALWAYS = ["pension", "scholarship", "awas", "पेंशन", "छात्रवृत्ति", "आवास"]

STATES = {
    "Andhra Pradesh": ["andhra pradesh", "andhra", "आंध्र प्रदेश"],
    "Arunachal Pradesh": ["arunachal pradesh", "arunachal", "अरुणाचल प्रदेश"],
    "Assam": ["assam", "असम"],
    "Bihar": ["bihar", "बिहार"],
    "Chhattisgarh": ["chhattisgarh", "chattisgarh", "छत्तीसगढ़"],
    "Goa": ["goa", "गोवा"],
    "Gujarat": ["gujarat", "गुजरात"],
    "Haryana": ["haryana", "हरियाणा"],
    "Himachal Pradesh": ["himachal pradesh", "himachal", "हिमाचल प्रदेश", "हिमाचल"],
    "Jharkhand": ["jharkhand", "झारखंड", "झारखण्ड"],
    "Karnataka": ["karnataka", "कर्नाटक"],
    "Kerala": ["kerala", "केरल"],
    "Madhya Pradesh": ["madhya pradesh", "मध्य प्रदेश"],
    "Maharashtra": ["maharashtra", "महाराष्ट्र"],
    "Manipur": ["manipur", "मणिपुर"],
    "Meghalaya": ["meghalaya", "मेघालय"],
    "Mizoram": ["mizoram", "मिजोरम", "मिज़ोरम"],
    "Nagaland": ["nagaland", "नागालैंड"],
    "Odisha": ["odisha", "orissa", "ओडिशा", "उड़ीसा"],
    "Punjab": ["punjab", "पंजाब"],
    "Rajasthan": ["rajasthan", "राजस्थान"],
    "Sikkim": ["sikkim", "सिक्किम"],
    "Tamil Nadu": ["tamil nadu", "tamilnadu", "तमिलनाडु", "तमिल नाडु"],
    "Telangana": ["telangana", "तेलंगाना"],
    "Tripura": ["tripura", "त्रिपुरा"],
    "Uttar Pradesh": ["uttar pradesh", "उत्तर प्रदेश"],
    "Uttarakhand": ["uttarakhand", "uttaranchal", "उत्तराखंड", "उत्तराखण्ड"],
    "West Bengal": ["west bengal", "bengal", "पश्चिम बंगाल", "बंगाल"],
    "Andaman and Nicobar Islands": ["andaman", "nicobar", "अंडमान"],
    "Chandigarh": ["chandigarh", "चंडीगढ़"],
    "Dadra & Nagar Haveli and Daman & Diu": ["dadra", "nagar haveli", "daman", "diu", "दादरा", "दमन"],
    "Delhi": ["delhi", "dilli", "दिल्ली"],
    "Jammu and Kashmir": ["jammu", "kashmir", "जम्मू", "कश्मीर"],
    "Ladakh": ["ladakh", "लद्दाख"],
    "Lakshadweep": ["lakshadweep", "लक्षद्वीप"],
    "Puducherry": ["puducherry", "pondicherry", "पुडुचेरी"],
}

INCOME_WORDS = ["income", "kamai", "kamata", "kamati", "aay", "aamdani", "amdani", "salary",
                "earn", "tankhwah", "कमाई", "कमाता", "कमाती", "आय", "आमदनी", "वेतन", "तनख्वाह"]
MONTHLY = ["mahina", "mahine", "mahine", "month", "monthly", "per month", "maheena",
           "महीना", "महीने", "मासिक"]


# ---------- helpers ----------

def find(text: str, words: list[str]) -> str | None:
    """Return the first word from the list that appears in the text, else None.

    English/Hinglish words must match as whole words ("st" won't match "stay").
    Hindi words are matched as plain text.
    """
    for w in words:
        if w.isascii():
            if re.search(rf"(?<![a-z0-9]){re.escape(w)}(?![a-z])", text):
                return w
        elif w in text:
            return w
    return None


def to_number(text: str) -> float:
    return float(text.replace(",", ""))


def find_age(text: str):
    # "23 saal", "23 sal", "23 years", "23 yrs", "23 वर्ष", "23 साल"
    m = re.search(r"(\d{1,3})\s*(saal|sal|years?|yrs?|year old|varsh|वर्ष|साल)", text)
    # "age 23", "umar 23", "उम्र 23"
    m = m or re.search(r"(?:age|umar|umr|उम्र|आयु)\D{0,5}(\d{1,3})", text)
    if m:
        age = int(m.group(1))
        if 0 < age <= 120:
            return age, m.group(0)
    return None, None


def find_income(text: str):
    """Yearly income in rupees, only if an income word is in the message."""
    income_word = find(text, INCOME_WORDS)
    if not income_word:
        return None, None    # "1 lakh ka loan" is not income, so we need an income word

    m = re.search(r"(\d+(?:[.,]\d+)?)\s*(lakh|lac|लाख)", text)
    if m:
        amount = to_number(m.group(1)) * 100000
    else:
        m = re.search(r"(\d+(?:[.,]\d+)?)\s*(hazar|hajar|hazaar|thousand|k\b|हजार|हज़ार)", text)
        if m:
            amount = to_number(m.group(1)) * 1000
        else:
            m = re.search(r"(?:rs\.?|₹|rupaye|rupees?|रुपये)?\s*(\d[\d,]{2,})", text)
            if not m:
                return None, None
            amount = to_number(m.group(1))

    if find(text, MONTHLY):
        amount *= 12          # we store income per year
    return amount, f"{m.group(0).strip()} ({income_word})"


def words_of(text: str) -> list[str]:
    """Split into words (English and Hindi letters), e.g. "jamin nhi hai" -> ["jamin", "nhi", "hai"]."""
    return re.findall(r"[a-z0-9'ऀ-ॿ]+", text)


def has_thing(text: str, nouns: list[str]):
    """Does the person have it? True / False / None (not mentioned).

        "mere pass jamin nhi hai"  -> False   (a "not" word within 3 words after)
        "bina jamin ke"            -> False   (a "not" word just before)
        "2 acre khet hai"          -> True    (a "has" word within 3 words after)
        "ghar mai rehta hu"        -> None    (just mentioned, nothing said about owning)
    """
    words = words_of(text)
    for i, word in enumerate(words):
        if word not in nouns:
            continue
        after, before = words[i + 1:i + 4], words[max(0, i - 2):i]
        if any(w in NOT for w in after) or any(w in NOT for w in before):
            return False, " ".join(words[max(0, i - 2):i + 4])
        if any(w in HAS for w in after) or any(w in ("have", "own", "owns") for w in before):
            return True, " ".join(words[i:i + 4])
    return None, None


def find_land_acres(text: str):
    m = re.search(r"(\d+(?:\.\d+)?)\s*(acre|acres|ekad|ekar|एकड़|hectare|hectares|हेक्टेयर)", text)
    if not m:
        return None, None
    acres = float(m.group(1))
    if m.group(2).startswith(("hectare", "हेक्टेयर")):
        acres = round(acres * 2.47, 2)
    return acres, m.group(0)


def find_education(text: str):
    # "10th pass", "12vi pass", "8 class tak", "5vi tak padha"
    m = re.search(r"(\d{1,2})\s*(?:th|st|nd|rd|vi|vin|wi|va|ve|वीं)?\s*(?:pass|tak|class|kaksha|पास|तक)", text)
    if m:
        n = int(m.group(1))
        level = ("primary" if n <= 5 else "middle" if n <= 9 else
                 "class_10" if n <= 11 else "class_12" if n == 12 else None)
        if level:
            return level, m.group(0)
    for level, words in EDUCATION:
        if w := find(text, words):
            return level, w
    return None, None


# ---------- main function ----------

def extract_profile_with_reasons(message: str) -> tuple[CitizenProfile, list[str]]:
    """Returns the profile and a list of reasons, so you can see WHY each field was filled."""
    text = message.lower()
    data, reasons = {}, []

    def fill(field, value, because):
        data[field] = value
        reasons.append(f"{field} = {value}   because of \"{because}\"")

    age, why = find_age(text)
    if age is not None:
        fill("age", age, why)

    if w := find(text, RURAL):
        fill("area", "rural", w)
    elif w := find(text, URBAN):
        fill("area", "urban", w)

    if w := find(text, FEMALE):
        fill("gender", "female", w)
    elif w := find(text, MALE):
        fill("gender", "male", w)

    for state, names in STATES.items():
        if w := find(text, names):
            fill("state", state, w)
            break

    for category, words in CATEGORY.items():
        if w := find(text, words):
            fill("category", category, w)
            break

    if w := find(text, DISABILITY):
        fill("has_disability", True, w)
    if w := find(text, BPL):
        fill("has_bpl_card", True, w)

    income, why = find_income(text)
    if income is not None:
        fill("annual_income", income, why)

    level, why = find_education(text)
    if level:
        fill("education", level, why)

    for status, words in MARITAL:
        if w := find(text, words):
            fill("marital_status", status, w)
            break

    # --- things the person has or doesn't have ---
    acres, why = find_land_acres(text)
    owns_land, land_why = has_thing(text, LAND)
    if acres is not None:
        fill("owns_land", True, why)
        fill("land_owned_acres", acres, why)
    elif owns_land is not None:
        fill("owns_land", owns_land, land_why)
        if owns_land is False:
            fill("land_owned_acres", 0, land_why)
    for field, nouns in (("has_house", HOUSE), ("has_bank_account", BANK), ("has_aadhaar", AADHAAR)):
        value, why = has_thing(text, nouns)
        if value is not None:
            fill(field, value, why)

    # --- needs: what the person ASKS for ("chahiye") ---
    needs = []

    def add_need(need, because):
        if need not in needs:
            needs.append(need)
            reasons.append(f"needs += {need}   because of \"{because}\"")

    want = find(text, WANT)
    for need, words in NEEDS.items():
        w = find(text, words)
        if w and (want or w in NEED_ALWAYS):
            add_need(need, f"{w} + {want or 'scheme word'}")

    # Not having land or a house is a need too, even without "chahiye"
    if data.get("owns_land") is False:
        add_need("land", land_why)
    if data.get("has_house") is False:
        add_need("housing", "no house")

    # --- skills: what the person CAN do ("aata hai"), vs wants to LEARN ("sikhna hai") ---
    skills = []
    knows, learn = find(text, KNOWS), find(text, LEARN)
    for skill, words in SKILLS.items():
        if w := find(text, words):
            if learn:
                add_need("skill_training", f"{w} + {learn}")
            elif knows:
                skills.append(skill)
                reasons.append(f"skills += {skill}   because of \"{w}\" + \"{knows}\"")
    if "agriculture" in skills and "land" in needs:
        add_need("agriculture", "knows farming but has no land")

    # --- employment status ---
    farmer = find(text, FARMER)
    if not farmer and "agriculture" in skills and data.get("owns_land") is not False \
            and find(text, ["karta", "karti", "karte", "करता", "करती"]):
        farmer = "kheti karta/karti"           # "kheti karta hu" means they farm now
    if farmer:
        fill("is_farmer", True, farmer)
    if w := find(text, UNEMPLOYED):
        fill("employment_status", "unemployed", w)
        add_need("employment", w)
    elif "employment" in needs:
        fill("employment_status", "unemployed", f"{find(text, NEEDS['employment'])} + {want}")
    elif farmer:
        fill("employment_status", "farmer", farmer)
    elif w := find(text, LABOURER):
        fill("employment_status", "wage_labourer", w)
    elif w := find(text, SELF_EMPLOYED):
        fill("employment_status", "self_employed", w)
    elif w := find(text, STUDENT):
        fill("employment_status", "student", w)
    elif w := find(text, HOMEMAKER):
        fill("employment_status", "homemaker", w)
    elif w := find(text, RETIRED):
        fill("employment_status", "retired", w)

    profile = CitizenProfile(**data, needs=needs, skills=skills, need_text=message)
    return profile, reasons


def extract_profile(message: str) -> CitizenProfile:
    """Message in, CitizenProfile out."""
    return extract_profile_with_reasons(message)[0]


# Fields we most want for eligibility checks. If they are missing, ask about them next.
IMPORTANT_FIELDS = ["age", "gender", "state", "area", "annual_income", "category"]


def missing_fields(profile: CitizenProfile) -> list[str]:
    """Important fields we still don't know."""
    return [name for name in IMPORTANT_FIELDS if getattr(profile, name) is None]


if __name__ == "__main__":
    sys.stdout.reconfigure(errors="replace")
    text = " ".join(sys.argv[1:]) or input("Apni situation likhiye: ")
    profile, reasons = extract_profile_with_reasons(text)
    print(profile.model_dump_json(indent=2, exclude_none=True, exclude={"citizen_id"}))
    print("\nWhy:")
    for r in reasons:
        print("  -", r)
