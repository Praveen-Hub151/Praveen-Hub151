"""followup.py: asks a FEW follow-up questions to turn "maybe" schemes into clear answers.

How it picks questions:
    After matching, every "maybe" scheme says which fields it still needs, e.g.
        PM Internship         -> need: annual_income
        Bihar Kaushal Yojana  -> need: state
        ...
    We count how many maybe schemes each field would decide and ask about the
    field that decides the most first. We ask at most MAX_QUESTIONS, and stop
    early when nothing important is missing.

How an answer is stored:
    The answer is read with the same rule-based extractor and merged into the
    SAME profile. A field we already know is never overwritten.
"""
import re

from agent.rule_based_extractor import extract_profile
from schemas.citizen_schema import CitizenProfile

MAX_QUESTIONS = 3

YES = ["haan", "han", "ha", "haa", "yes", "y", "ji", "ji haan", "1", "हाँ", "हां", "जी"]
NO = ["nahi", "nahin", "nhi", "na", "no", "n", "2", "नहीं", "ना"]

# field -> (question, numbered options or None, text template for the extractor)
QUESTIONS = {
    "state": ("Aap kis state mai rehte ho? (jaise Bihar, Uttar Pradesh)", None, "{}"),
    "age": ("Aapki umar kitni hai? (jaise 25)", None, "{} saal"),
    "annual_income": ("Aapke ghar ki saal bhar ki kamai kitni hai? (jaise 1 lakh, ya 8 hazar mahina)",
                      None, "income {}"),
    "category": ("Aapki category kya hai?",
                 {"1": "general", "2": "obc", "3": "sc", "4": "st", "5": "ews"}, "{}"),
    "gender": ("Aap purush ho ya mahila?", {"1": "male", "2": "female"}, "{}"),
    "area": ("Aap gaon mai rehte ho ya shahar mai?", {"1": "rural", "2": "urban"}, "{}"),
    "has_disability": ("Kya aap divyang (disabled) ho?", "yes_no", None),
    "has_bpl_card": ("Kya aapke paas BPL card hai?", "yes_no", None),
}
OPTION_LABELS = {"general": "General", "obc": "OBC", "sc": "SC", "st": "ST", "ews": "EWS",
                 "male": "Purush (male)", "female": "Mahila (female)",
                 "rural": "Gaon (rural)", "urban": "Shahar (urban)"}


def question_text(field: str) -> str:
    question, options, _ = QUESTIONS[field]
    if options == "yes_no":
        return f"{question}  1) Haan  2) Nahi"
    if options:
        return question + "  " + "  ".join(f"{k}) {OPTION_LABELS[v]}" for k, v in options.items())
    return question


def pick_questions(schemes: dict, profile: CitizenProfile) -> list[str]:
    """Fields to ask about, most useful first (how many maybe schemes each one decides)."""
    counts: dict[str, int] = {}
    for scheme in schemes["maybe"]:
        for field in scheme.get("missing", []):
            if field in QUESTIONS and getattr(profile, field) is None:
                counts[field] = counts.get(field, 0) + 1
    return sorted(counts, key=counts.get, reverse=True)


def parse_answer(field: str, answer: str):
    """Read one answer. Returns (value, other_profile) where other_profile has any
    extra details the person mentioned (e.g. "Bihar ke gaon mai")."""
    answer = answer.strip()
    _, options, template = QUESTIONS[field]
    low = answer.lower()

    if options == "yes_no":
        if low in YES:
            return True, None
        if low in NO:
            return False, None
        return None, None
    if isinstance(options, dict) and low in options:
        return options[low], None

    if field == "age" and low.isdigit():
        return int(low), None
    if field == "annual_income" and re.fullmatch(r"[\d,]+", low):
        amount = float(low.replace(",", ""))
        return (amount if amount >= 1000 else None), None   # "2" alone is unclear: 2 lakh? 2 hazar?

    extra = extract_profile(template.format(answer))
    value = getattr(extra, field)
    if hasattr(value, "value"):
        value = value.value
    return value, extra


def merge(profile: CitizenProfile, new: CitizenProfile | None) -> CitizenProfile:
    """Copy fields from new into profile, but never overwrite something we already know."""
    if new is None:
        return profile
    data = profile.model_dump()
    for field, value in new.model_dump(exclude={"citizen_id", "need_text"}).items():
        if isinstance(value, list):
            data[field] = data[field] + [v for v in value if v not in data[field]]
        elif value is not None and data[field] is None:
            data[field] = value
    return CitizenProfile(**data)


def ask_followups(profile, match, ask=input, say=print, max_questions=MAX_QUESTIONS):
    """The question loop.

    profile:  the CitizenProfile from the first message
    match:    a function profile -> {"eligible": [...], "maybe": [...], ...}
    ask/say:  input/print by default; tests pass fake ones

    Returns (profile, schemes, conversation) where conversation is a list of
    {"field", "question", "answer", "value"} to store.
    """
    conversation = []
    schemes = match(profile)
    asked = set()
    while len(conversation) < max_questions:
        fields = [f for f in pick_questions(schemes, profile) if f not in asked]
        if not fields:
            break                                   # nothing important missing: stop early
        field = fields[0]
        asked.add(field)

        question = question_text(field)
        answer = ask(f"\nQ{len(conversation) + 1}. {question}\n> ")
        if not answer.strip() or answer.strip().lower() in ("skip", "pata nahi", "nahi pata"):
            conversation.append({"field": field, "question": question, "answer": answer, "value": None})
            continue

        value, extra = parse_answer(field, answer)
        if value is not None:
            profile = merge(profile, CitizenProfile(**{field: value}))
        profile = merge(profile, extra)             # keep anything else they mentioned
        conversation.append({"field": field, "question": question, "answer": answer, "value": value})
        if value is None:
            say("   (Samajh nahi aaya, isko chhod ke aage badhte hain)")
        schemes = match(profile)                    # re-check with the new information
    return profile, schemes, conversation
