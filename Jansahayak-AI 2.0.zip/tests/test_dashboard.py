"""test_dashboard.py: checks the dashboard API against the real jansahayak_db.

Run from the JanSahayak-AI folder (database must be loaded):
    python tests/test_dashboard.py
or  python -m pytest tests/test_dashboard.py

It only reads from the database. It checks that the dashboard gives the same
answers as the project's own engine (engine/scheme_matcher.py, engine/db_rules.py),
that admin routes are protected, that connections are read-only, and that the
Groq key never reaches the browser.
"""
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import psycopg2  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from dashboard import ai  # noqa: E402
from dashboard.app import app  # noqa: E402
from dashboard.auth import hash_password  # noqa: E402
from dashboard.config import settings  # noqa: E402
from dashboard.db import get_conn  # noqa: E402
from engine.db_rules import check_scheme, get_connection  # noqa: E402
from engine.scheme_matcher import match_schemes  # noqa: E402
from schemas.citizen_schema import CitizenProfile  # noqa: E402

client = TestClient(app)
API = settings.api_prefix
BIHAR_YOUTH = {"age": 23, "area": "rural", "state": "Bihar", "employment_status": "unemployed", "needs": ["employment"]}


def db_value(query, params=None):
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(query, params)
            return cur.fetchone()[0]
    finally:
        conn.close()


def test_health():
    r = client.get(f"{API}/health")
    assert r.status_code == 200 and r.json()["database"] == "ok"


def test_counts_match_database():
    counts = client.get(f"{API}/public-counts").json()
    for table in ("schemes", "scheme_purposes", "scheme_documents", "eligibility_rules"):
        assert counts[table] == db_value(f"SELECT count(*) FROM {table}"), table


def test_summary_levels_add_up():
    s = client.get(f"{API}/dashboard/summary").json()
    assert s["central_schemes"] + s["state_schemes"] == s["total_schemes"]
    assert s["central_schemes"] == db_value("SELECT count(*) FROM schemes WHERE level = 'central'")


def test_search_is_paginated_and_capped():
    r = client.get(f"{API}/schemes", params={"page_size": 5000})
    body = r.json()
    assert r.status_code == 200
    assert len(body["items"]) == settings.max_page_size
    assert body["total"] == db_value("SELECT count(*) FROM schemes")


def test_search_filters():
    body = client.get(f"{API}/schemes", params={"state": "Bihar", "level": "state", "page_size": 50}).json()
    assert body["total"] == db_value("SELECT count(*) FROM schemes WHERE state = 'Bihar'")
    assert all(i["state"] == "Bihar" for i in body["items"])
    body = client.get(f"{API}/schemes", params={"purpose": "education", "page_size": 1}).json()
    assert body["total"] == db_value("SELECT count(DISTINCT scheme_id) FROM scheme_purposes WHERE purpose = 'education'")


def test_search_keyword_and_injection_safe():
    body = client.get(f"{API}/schemes", params={"q": "scholarship"}).json()
    assert body["total"] > 0
    body = client.get(f"{API}/schemes", params={"q": "'; DROP TABLE schemes; --"}).json()
    assert body["total"] == 0
    assert db_value("SELECT count(*) FROM schemes") > 0


def test_search_validation():
    assert client.get(f"{API}/schemes", params={"level": "planet"}).status_code == 422
    assert client.get(f"{API}/schemes", params={"page": 0}).status_code == 422


def test_scheme_detail_and_404():
    sid = db_value("SELECT scheme_id FROM eligibility_rules GROUP BY 1 ORDER BY count(*) DESC LIMIT 1")
    d = client.get(f"{API}/schemes/{sid}").json()
    assert d["scheme"]["scheme_id"] == sid
    assert len(d["documents"]) == db_value("SELECT count(*) FROM scheme_documents WHERE scheme_id = %s", (sid,))
    assert d["rules"], "rules should be explained"
    assert client.get(f"{API}/schemes/no-such-scheme-xyz").status_code == 404


def test_eligibility_check_matches_project_engine():
    """For many schemes, the dashboard status equals engine/db_rules.check_scheme()."""
    mapping = {"eligible": "eligible", "not_eligible": "not_eligible", "maybe": "needs_more_info"}
    profile = {"age": 30, "gender": "female", "annual_income": 150000, "category": "sc", "area": "rural"}
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT DISTINCT scheme_id FROM eligibility_rules e JOIN schemes s USING (scheme_id) "
                        "WHERE s.level = 'central' ORDER BY 1 LIMIT 60")
            ids = [r[0] for r in cur.fetchall()]
        citizen = CitizenProfile(**profile)
        for sid in ids:
            expected = mapping[check_scheme(conn, citizen, sid)]
            got = client.post(f"{API}/eligibility/check", json={"scheme_id": sid, "profile": profile}).json()
            assert got["status"] == expected, (sid, got["status"], expected)
    finally:
        conn.close()


def test_eligibility_validation():
    r = client.post(f"{API}/eligibility/check", json={"scheme_id": "x", "profile": {"age": 500}})
    assert r.status_code == 422 and r.json()["errors"][0]["field"] == "age"
    r = client.post(f"{API}/eligibility/check", json={"scheme_id": "x", "profile": {"favourite_colour": "blue"}})
    assert r.status_code == 422
    r = client.post(f"{API}/eligibility/check", json={"scheme_id": "no-such-scheme-xyz", "profile": {"age": 30}})
    assert r.status_code == 404


def test_match_equals_match_schemes():
    body = client.post(f"{API}/citizen/match", json={"profile": BIHAR_YOUTH, "status": "all", "page_size": 50}).json()
    conn = get_connection()
    try:
        native = match_schemes(conn, CitizenProfile(**BIHAR_YOUTH))
    finally:
        conn.close()
    assert body["counts"]["eligible"] == len(native["eligible"])
    assert body["counts"]["maybe"] == len(native["maybe"])
    assert body["counts"]["no_rules"] == len(native["no_rules"])
    assert body["counts"]["not_eligible"] == len(native["not_eligible"])
    assert body["total"] == sum(len(v) for v in native.values())
    assert len(body["items"]) <= 50


def test_match_needs_a_profile():
    assert client.post(f"{API}/citizen/match", json={"profile": {}}).status_code == 422


def test_admin_requires_login():
    fresh = TestClient(app)
    for path in ("/admin/overview", "/admin/system", "/admin/schemes", "/admin/rules/stats"):
        assert fresh.get(API + path).status_code in (401, 503), path


def test_admin_login_and_stats():
    old = (settings.admin_username, settings.admin_password_hash, settings.secret_key)
    settings.admin_username, settings.admin_password_hash, settings.secret_key = "tester", hash_password("pw-for-tests-123"), "k" * 40
    try:
        c = TestClient(app)
        assert c.post(f"{API}/admin/login", json={"username": "tester", "password": "wrong"}).status_code == 401
        assert c.post(f"{API}/admin/login", json={"username": "tester", "password": "pw-for-tests-123"}).status_code == 200
        o = c.get(f"{API}/admin/overview").json()
        assert o["rules"]["total_rules"] == db_value("SELECT count(*) FROM eligibility_rules")
        assert sum(s["count"] for s in o["by_state"]) == db_value("SELECT count(*) FROM schemes WHERE level = 'state'")
        assert c.get(f"{API}/admin/system").json()["database"]["read_only"] == "on"
        sid = db_value("SELECT scheme_id FROM eligibility_rules LIMIT 1")
        d = c.get(f"{API}/admin/schemes/{sid}").json()
        assert len(d["raw_rules"]) == db_value("SELECT count(*) FROM eligibility_rules WHERE scheme_id = %s", (sid,))
        c.post(f"{API}/admin/logout")
        c.cookies.clear()
        assert c.get(f"{API}/admin/overview").status_code == 401
    finally:
        settings.admin_username, settings.admin_password_hash, settings.secret_key = old


def test_connections_are_read_only():
    try:
        with get_conn() as conn, conn.cursor() as cur:
            cur.execute("CREATE TEMP TABLE dashboard_should_not_write (x int)")
    except psycopg2.errors.ReadOnlySqlTransaction:
        return
    raise AssertionError("dashboard connection accepted a write")


def test_chat_without_ai_still_returns_schemes():
    old = settings.groq_api_key
    settings.groq_api_key = None
    try:
        r = client.post(f"{API}/chat", json={"message": "scholarship for girl students"}).json()
        assert r["ai_available"] is False and r["schemes"]
        r = client.post(f"{API}/chat", json={"message": "विधवा पेंशन"}).json()
        assert r["language"] == "hi" and r["schemes"]
    finally:
        settings.groq_api_key = old


def test_chat_with_mocked_groq_and_no_key_leak():
    secret = "gsk_test_secret_value_123"
    old_key, old_post = settings.groq_api_key, ai.httpx.post
    sent = {}

    class Resp:
        status_code = 200
        text = ""

        @staticmethod
        def json():
            return {"choices": [{"message": {"content": "Here are some schemes."}}]}

    def fake_post(url, headers=None, json=None, timeout=None):
        sent.update(url=url, headers=headers, body=json)
        return Resp()

    settings.groq_api_key, ai.httpx.post = secret, fake_post
    try:
        r = client.post(f"{API}/chat", json={"message": "mai 23 saal ka hoon Bihar ke gaon mai rehta hu mujhe kaam chahiye"})
        body = r.json()
        assert body["ai_available"] is True and body["answer"] == "Here are some schemes."
        assert sent["headers"]["Authorization"] == f"Bearer {secret}"
        assert "CONTEXT" in sent["body"]["messages"][-1]["content"]   # records were retrieved first
        assert body["understood"]["profile"]["state"] == "Bihar"     # project's extractor was used
        assert secret not in r.text
        for path in ("/", "/admin", f"{API}/health", f"{API}/ai/status", "/dashboard-static/js/citizen.js"):
            assert secret not in client.get(path).text, path
    finally:
        settings.groq_api_key, ai.httpx.post = old_key, old_post


def test_pages_served_with_security_headers():
    for path in ("/", "/admin"):
        r = client.get(path)
        assert r.status_code == 200 and "Content-Security-Policy" in r.headers


def test_database_url_wins_over_db_settings():
    from unittest import mock
    from engine.db_rules import connection_settings
    with mock.patch.dict(os.environ, {"DATABASE_URL": "postgresql://u:p@db.example:5432/x"}):
        assert connection_settings() == {"dsn": "postgresql://u:p@db.example:5432/x"}
    with mock.patch.dict(os.environ, {"DATABASE_URL": ""}):
        assert "host" in connection_settings()


def test_plain_admin_password_fallback():
    from unittest import mock
    from dashboard.auth import verify_password
    from dashboard.config import Settings
    env = {"ADMIN_USERNAME": "admin", "ADMIN_PASSWORD": "plain-pw-123", "ADMIN_PASSWORD_HASH": "",
           "DASHBOARD_SECRET_KEY": ""}
    with mock.patch.dict(os.environ, env):
        s = Settings()
    assert s.admin_configured and verify_password("plain-pw-123", s.admin_password_hash)


def test_client_ip_behind_proxy():
    from starlette.requests import Request
    from dashboard.auth import client_ip
    req = Request({"type": "http", "client": ("10.0.0.1", 1), "headers": [(b"x-forwarded-for", b"6.6.6.6, 1.2.3.4")]})
    old = settings.trust_proxy
    try:
        settings.trust_proxy = True
        assert client_ip(req) == "1.2.3.4"          # the entry the proxy added, not the faked one
        settings.trust_proxy = False
        assert client_ip(req) == "10.0.0.1"
    finally:
        settings.trust_proxy = old


def test_huge_request_body_refused():
    r = client.post(f"{API}/chat", content=b"x", headers={"content-type": "application/json",
                                                           "content-length": str(500 * 1024 * 1024)})
    assert r.status_code == 413


def test_document_upload_rate_limited():
    from dashboard.routes_documents import upload_limiter
    sid = db_value("SELECT scheme_id FROM scheme_documents LIMIT 1")
    upload_limiter.hits.clear()
    codes = [client.post(f"{API}/schemes/{sid}/verify-documents", json={"profile": {}, "files": []}).status_code
             for _ in range(settings.upload_rate_per_minute + 1)]
    upload_limiter.hits.clear()
    assert codes[-1] == 429 and 429 not in codes[:-1], codes


if __name__ == "__main__":
    tests = [(n, f) for n, f in sorted(globals().items()) if n.startswith("test_") and callable(f)]
    passed = 0
    for name, fn in tests:
        try:
            fn()
            passed += 1
            print(f"  ok    {name}")
        except Exception as exc:  # noqa: BLE001
            print(f"  FAIL  {name}: {exc!r}")
    print(f"{passed}/{len(tests)} tests passed")
    sys.exit(0 if passed == len(tests) else 1)
