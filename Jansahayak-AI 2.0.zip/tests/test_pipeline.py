"""test_pipeline.py: tests main.py end to end (extractor + database + matcher).

Run from the JanSahayak-AI folder:
    python tests/test_pipeline.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(errors="replace")

from main import run, show

MESSAGE = "mai 23 saal ka hoon gaon mai rehta hu mujhe kaam chahiye"


def main():
    output = run(MESSAGE)
    show(output)
    eligible = {s["scheme_id"] for s in output["schemes"]["eligible"]}

    checks = [
        ("asks for state, income and category",
         output["ask_next"] == ["state", "annual_income", "category"]),
        ("MGNREGA is eligible", "mgnrega" in eligible),
        ("some schemes are maybe because info is missing", len(output["schemes"]["maybe"]) > 0),
    ]
    print()
    passed = 0
    for label, ok in checks:
        passed += ok
        print(f"[{'PASS' if ok else 'FAIL'}] {label}")
    print(f"\n{passed}/{len(checks)} tests passed")
    return passed == len(checks)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
