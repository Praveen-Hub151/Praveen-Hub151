"""test_document_verifier.py: per-scheme document upload + verification checkmarks.

Uses real schemes from the database and the SAMPLE files in tests/sample_documents.

Run from the JanSahayak-AI folder:
    python tests/test_document_verifier.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(errors="replace")

from documents.document_profile import read_document
from engine.db_rules import get_connection
from services.document_verifier import (classify_requirement, required_documents, same_person,
                                        verify_scheme_documents)

S = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_documents")
AADHAAR = read_document(os.path.join(S, "aadhaar_sample.txt"))
INCOME = read_document(os.path.join(S, "income_certificate_sample.txt"))
BANK = read_document(os.path.join(S, "bank_passbook_sample.txt"))
CASTE = read_document(os.path.join(S, "caste_certificate_sample.txt"))
RATION = read_document(os.path.join(S, "ration_card_sample.txt"))
PHOTO = {"file": "me.jpg", "type": "unknown", "details": {}, "profile": {}}   # a plain photo: no text


def status(result, number):
    return next(r["status"] for r in result["items"] if r["number"] == number)


def main():
    conn = get_connection()
    checks = []

    # Sorting myScheme document names into types
    kind = lambda name: classify_requirement(name)["kind"]                    # noqa: E731
    checks += [
        ("'Aadhaar Card.' -> aadhaar", kind("Aadhaar Card.") == "aadhaar"),
        ("'Passport-size photograph' -> photo", kind("Passport-size photograph") == "photo"),
        ("'Caste Certificate (if applicable)' -> caste, optional",
         kind("Caste Certificate (if applicable)") == "caste_certificate"
         and classify_requirement("Caste Certificate (if applicable)")["optional"]),
        ("'Bank Pass Book/Cancelled Cheque' -> bank", kind("Bank Pass Book/Cancelled Cheque.") == "bank_passbook"),
        ("'Mobile Number' -> info (no file)", kind("Mobile Number") == "info"),
        ("'Any other documents as required' -> optional",
         classify_requirement("Any other documents as required")["optional"]),
        ("'Proof of Identity (Ration card, Voter ID, Aadhaar)' accepts ration card too",
         "ration_card" in classify_requirement("Proof of Identity (Ration card, Voter ID Card, Aadhaar)")["accepts"]),
    ]

    # Real scheme: PM Internship needs Aadhaar, education, age proof, bank, (other)
    items = required_documents(conn, "pmis")
    checks.append(("PM Internship has its 5 documents from myScheme", len(items) == 5))

    ok = verify_scheme_documents(conn, "pmis", {1: AADHAAR, 4: BANK, 2: PHOTO})
    checks += [
        ("Aadhaar fails PM Internship age check (26 > 24)", status(ok, 1) == "check_failed"),
        ("bank passbook verified", status(ok, 4) == "verified"),
        ("education file -> manual review", status(ok, 2) == "manual_review"),
        ("proof of age covered by the same Aadhaar (and fails age too)", status(ok, 3) == "check_failed"),
        ("'any other documents' -> optional", status(ok, 5) == "optional"),
        ("not ready while something fails or is missing", ok["ready"] is False),
    ]

    # Wrong document in the wrong slot
    wrong = verify_scheme_documents(conn, "pmis", {1: BANK})
    checks.append(("passbook uploaded as Aadhaar -> wrong_document", status(wrong, 1) == "wrong_document"))
    checks.append(("nothing for proof of age -> missing", status(wrong, 3) == "missing"))

    # MGNREGA: everything needed uploaded -> ready
    mg = verify_scheme_documents(conn, "mgnrega", {1: PHOTO, 4: AADHAAR})
    checks += [
        ("MGNREGA photo -> manual review", status(mg, 1) == "manual_review"),
        ("MGNREGA Aadhaar as identity proof -> verified", status(mg, 4) == "verified"),
        ("MGNREGA ready to apply", mg["ready"] is True),
        ("ration card accepted as identity (family name not checked)",
         status(verify_scheme_documents(conn, "mgnrega", {4: RATION, 1: PHOTO}), 4) == "verified"),
    ]

    # Name check across documents
    other_person = {**INCOME, "details": {**INCOME["details"], "name": "Sita Devi"}}
    named = verify_scheme_documents(conn, "pmis", {1: AADHAAR, 4: {**BANK, "details": {**BANK["details"],
                                                                                        "name": "Sita Devi"}}})
    checks += [
        ("same_person('Ramesh Kumar', 'RAMESH KUMAR SINGH')", same_person("Ramesh Kumar", "RAMESH KUMAR SINGH")),
        ("different person -> name check fails", status(named, 4) == "check_failed"),
        ("unknown name never fails", same_person(None, "Ramesh Kumar")),
    ]

    # Profile filled from documents (caste certificate -> category)
    with_caste = verify_scheme_documents(conn, "pmis", {1: AADHAAR, 2: CASTE})
    checks.append(("caste certificate fills category obc", with_caste["profile"].category.value == "obc"))
    conn.close()

    passed = 0
    for label, ok_ in checks:
        passed += bool(ok_)
        print(f"[{'PASS' if ok_ else 'FAIL'}] {label}")
    print(f"\n{passed}/{len(checks)} tests passed")
    return passed == len(checks)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
