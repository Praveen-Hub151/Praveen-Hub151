"""test_extension.py: safety checks on the autofill browser extension (browser_extension/).

The filling itself is tested in a browser on dashboard/static/test_portal.html (see RUN_STEPS.md).
These checks make sure the extension stays safe:

Run from the JanSahayak-AI folder:
    python tests/test_extension.py
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXT = os.path.join(ROOT, "browser_extension")
sys.stdout.reconfigure(errors="replace")


def read(name):
    with open(os.path.join(EXT, name), encoding="utf-8") as f:
        return f.read()


def main():
    manifest = json.loads(read("manifest.json"))
    fill = read("fill.js")
    files = ["manifest.json", "fill.js", "run.js", "popup.html", "popup.js", "sync_from_dashboard.js",
             "icons/icon16.png", "icons/icon48.png", "icons/icon128.png"]
    # The test portal is served by the dashboard, not packaged in the extension.
    portal = os.path.join(ROOT, "dashboard", "static", "test_portal.html")
    checks = [
        ("all extension files and dashboard test portal present",
         all(os.path.exists(os.path.join(EXT, f)) for f in files) and os.path.isfile(portal)),
        ("Manifest V3", manifest.get("manifest_version") == 3),
        ("only activeTab / scripting / storage permissions",
         set(manifest.get("permissions", [])) <= {"activeTab", "scripting", "storage"}
         and not manifest.get("host_permissions")),
        ("auto-runs only on the local dashboard or one exact https site (no wildcards)",
         all(m.startswith(("http://127.0.0.1", "http://localhost"))
             or (m.startswith("https://") and "*" not in m.split("/")[2])
             for cs in manifest["content_scripts"] for m in cs["matches"])),
        ("never submits a form", not re.search(r"\.submit\(\)|requestSubmit", fill)),
        ("never clicks a submit button", not re.search(r"type=.?submit.?\]?[^\n]*\.click\(", fill)),
        ("skips password / OTP / captcha boxes", all(w in fill for w in ("captcha", "otp", "password"))),
        ("masked numbers are not filled", "XXXX" in fill),
        ("only mobile and email can be remembered", 'new Set(["mobile", "email"])' in fill),
        ("no outside network calls", not re.search(r"fetch\(|XMLHttpRequest|sendBeacon", fill + read("run.js"))),
    ]
    passed = 0
    for label, ok in checks:
        passed += bool(ok)
        print(f"[{'PASS' if ok else 'FAIL'}] {label}")
    print(f"\n{passed}/{len(checks)} tests passed")
    return passed == len(checks)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
