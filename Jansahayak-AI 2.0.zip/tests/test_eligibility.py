"""test_eligibility.py: runs every test case and prints PASS or FAIL.

Run from the JanSahayak-AI folder:
    python tests/test_eligibility.py
"""
import os
import sys

# Let Python find schemas/, engine/ and data/ (they sit one folder up).
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from schemas.citizen_schema import Area, Category, CitizenProfile
from engine.eligibility_engine import evaluate_eligibility
from data.test_schemes import (CATEGORY_RULES, CATEGORY_SCHEME_NAME,
                               TEST_RULES, TEST_SCHEME_NAME)


# (label, citizen, rules, expected result)
CASES = [
    # AND logic: age >= 18 AND rural AND income <= 2 lakh
    ("23, rural, Rs 1L",  CitizenProfile(age=23, area=Area.rural, annual_income=100000), TEST_RULES, "eligible"),
    ("17, rural, Rs 1L",  CitizenProfile(age=17, area=Area.rural, annual_income=100000), TEST_RULES, "not_eligible"),
    ("23, urban, Rs 1L",  CitizenProfile(age=23, area=Area.urban, annual_income=100000), TEST_RULES, "not_eligible"),
    ("23, rural, Rs 3L",  CitizenProfile(age=23, area=Area.rural, annual_income=300000), TEST_RULES, "not_eligible"),

    # MAYBE: income not known yet
    ("23, rural, income unknown",  CitizenProfile(age=23, area=Area.rural), TEST_RULES, "maybe"),
    # Unknown income can't save someone who already fails another rule
    ("17, rural, income unknown",  CitizenProfile(age=17, area=Area.rural), TEST_RULES, "not_eligible"),

    # OR logic: category SC OR ST
    ("SC",               CitizenProfile(category=Category.sc),      CATEGORY_RULES, "eligible"),
    ("ST",               CitizenProfile(category=Category.st),      CATEGORY_RULES, "eligible"),
    ("General",          CitizenProfile(category=Category.general), CATEGORY_RULES, "not_eligible"),
    ("category unknown", CitizenProfile(),                          CATEGORY_RULES, "maybe"),
]


def main():
    passed = 0
    current_rules = None
    for label, citizen, rules, expected in CASES:
        if rules is not current_rules:
            name = TEST_SCHEME_NAME if rules is TEST_RULES else CATEGORY_SCHEME_NAME
            print(f"\n{name}")
            print("-" * 72)
            current_rules = rules

        result = evaluate_eligibility(citizen, rules)
        ok = result == expected
        passed += ok
        mark = "PASS" if ok else "FAIL"
        print(f"[{mark}] {label:28} expected={expected:13} got={result}")

    print(f"\n{passed}/{len(CASES)} tests passed")
    return passed == len(CASES)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
