"""Regression tests for the upload -> extract -> profile part of the dashboard flow.
Uses only the repository's synthetic sample documents; no database or DigiLocker is needed.
Run: python -m unittest tests.test_document_profile_flow
"""
import unittest
from pathlib import Path

from documents.document_profile import read_document, apply_documents
from schemas.citizen_schema import CitizenProfile

SAMPLES = Path(__file__).parent / "sample_documents"


class DocumentProfileFlowTests(unittest.TestCase):
    def test_multiple_documents_populate_profile_and_keep_manual_fields(self):
        docs = [
            read_document(str(SAMPLES / "aadhaar_sample.txt")),
            read_document(str(SAMPLES / "income_certificate_sample.txt")),
            read_document(str(SAMPLES / "bank_passbook_sample.txt")),
        ]
        profile, changes = apply_documents(CitizenProfile(area="rural"), docs)
        self.assertEqual(profile.age, 26)
        self.assertEqual(profile.state, "Bihar")
        self.assertEqual(profile.annual_income, 120000)
        self.assertTrue(profile.has_aadhaar)
        self.assertTrue(profile.has_bank_account)
        self.assertEqual(profile.area.value, "rural")
        self.assertTrue(changes)

    def test_sensitive_identifiers_are_masked_in_extraction(self):
        aadhaar = read_document(str(SAMPLES / "aadhaar_sample.txt"))
        bank = read_document(str(SAMPLES / "bank_passbook_sample.txt"))
        self.assertEqual(aadhaar["details"].get("aadhaar_number"), "XXXX XXXX 0123")
        self.assertEqual(bank["details"].get("account_number"), "XXXXXXX7890")
        self.assertNotIn("2345 6789", str(aadhaar))


if __name__ == "__main__":
    unittest.main()
