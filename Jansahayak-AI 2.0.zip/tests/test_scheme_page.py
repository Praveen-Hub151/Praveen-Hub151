"""test_scheme_page.py: the dashboard's scheme page (eligibility + document upload + verify).

Calls the dashboard API the same way the browser does, with Sunita Devi's SAMPLE documents.
Needs the database and Tesseract (for the photos).

Run from the JanSahayak-AI folder:
    python tests/test_scheme_page.py
"""
import base64
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.stdout.reconfigure(errors="replace")

from fastapi.testclient import TestClient

from dashboard.app import app
from documents.ocr import find_tesseract

PERSON = os.path.join(ROOT, "tests", "sample_person")


def upload(item, name):
    with open(os.path.join(PERSON, name), "rb") as f:
        return {"item": item, "filename": name, "data": base64.b64encode(f.read()).decode()}


def main():
    c = TestClient(app)
    checks = []

    r = c.get("/api/schemes/pmis/required-documents")
    checks.append(("document list for PM Internship", r.status_code == 200 and r.json()["needed"] == 4))
    checks.append(("unknown scheme -> 404", c.get("/api/schemes/no-such-scheme/required-documents").status_code == 404))

    bad = c.post("/api/schemes/pmis/verify-documents",
                 json={"files": [{"item": 1, "filename": "virus.exe", "data": "AAAA"}]})
    checks.append((".exe upload refused", bad.status_code == 422))
    wrong_item = c.post("/api/schemes/pmis/verify-documents",
                        json={"files": [{"item": 99, "filename": "a.png", "data": "AAAA"}]})
    checks.append(("upload for a document number that doesn't exist refused", wrong_item.status_code == 422))

    if not find_tesseract():
        print("[SKIP] photo uploads (install Tesseract to run them)")
    else:
        full = c.post("/api/schemes/pmis/verify-documents", json={"profile": {}, "files": [
            upload(1, "aadhaar.png"), upload(2, "marksheet_class12.png"),
            upload(4, "bank_passbook.png"), upload(1000, "income_certificate.png")]}).json()
        status = {i["number"]: i["status"] for i in full["documents"]["items"]}
        checks += [
            ("Aadhaar verified", status[1] == "verified"),
            ("same Aadhaar also proves age", status[3] == "verified"),
            ("marksheet -> a person checks it", status[2] == "manual_review"),
            ("bank passbook verified", status[4] == "verified"),
            ("browser file names shown, not temporary ones",
             {i["file"] for i in full["documents"]["items"] if i["file"]} >= {"aadhaar.png", "bank_passbook.png"}),
            ("eligibility from documents: all criteria met", full["eligibility"]["status"] == "eligible"),
            ("READY FOR FILLING THE FORM", full["ready_for_form"] and "Ready for filling the form" in full["message"]),
            ("age and income read from documents",
             {f["field"] for f in full["found_in_documents"]} >= {"age", "annual_income"}),
        ]
        fields = {f["label"]: f for f in full["form_data"]}
        checks += [
            ("form: name from Aadhaar", fields["Applicant name (as in Aadhaar)"]["value"] == "Sunita Devi"
             and fields["Applicant name (as in Aadhaar)"]["source"] == "Aadhaar"),
            ("form: date of birth + PIN code", fields["Date of birth"]["value"] == "12/03/2004"
             and fields["PIN code"]["value"] == "844101"),
            ("form: income from income certificate", fields["Annual family income (Rs)"]["value"] == "90,000"),
            ("form: bank + IFSC from passbook", fields["IFSC code"]["value"] == "PUNB0123400"),
            ("form: account number only masked", fields["Bank account number"]["value"].startswith("XXXX")),
            ("upload guide: Aadhaar file for the Aadhaar line",
             {"document": "Aadhaar Card", "file": "aadhaar.png"} in full["upload_guide"]),
        ]
        partial = c.post("/api/schemes/pmis/verify-documents",
                         json={"files": [upload(1, "aadhaar.png")]}).json()
        checks += [
            ("only Aadhaar -> not ready", partial["ready_for_form"] is False),
            ("missing bank passbook reported", any(i["number"] == 4 and i["status"] == "missing"
                                                   for i in partial["documents"]["items"])),
        ]

    passed = 0
    for label, ok in checks:
        passed += bool(ok)
        print(f"[{'PASS' if ok else 'FAIL'}] {label}")
    print(f"\n{passed}/{len(checks)} tests passed")
    return passed == len(checks)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
