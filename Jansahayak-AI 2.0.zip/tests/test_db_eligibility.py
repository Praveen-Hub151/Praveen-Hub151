"""test_db_eligibility.py: checks REAL schemes whose rules come from PostgreSQL.

Run from the JanSahayak-AI folder (after database/import_schemes.py has loaded the data):
    python tests/test_db_eligibility.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(errors="replace")   # some scheme names have special characters

from schemas.citizen_schema import Area, CitizenProfile
from engine.db_rules import check_scheme, get_connection, load_rules, load_scheme


# (scheme_id, label, citizen, expected result)
CASES = [
    # MGNREGA: age >= 18 AND rural
    ("mgnrega", "23, rural",         CitizenProfile(age=23, area=Area.rural), "eligible"),
    ("mgnrega", "17, rural",         CitizenProfile(age=17, area=Area.rural), "not_eligible"),
    ("mgnrega", "23, urban",         CitizenProfile(age=23, area=Area.urban), "not_eligible"),
    ("mgnrega", "23, area unknown",  CitizenProfile(age=23),                  "maybe"),

    # PM Internship Scheme: age 21 to 24 AND income <= Rs 8 lakh
    ("pmis", "22, Rs 5L",            CitizenProfile(age=22, annual_income=500000), "eligible"),
    ("pmis", "26, Rs 5L",            CitizenProfile(age=26, annual_income=500000), "not_eligible"),
    ("pmis", "22, Rs 10L",           CitizenProfile(age=22, annual_income=1000000), "not_eligible"),
    ("pmis", "22, income unknown",   CitizenProfile(age=22),                       "maybe"),
]


def main():
    try:
        conn = get_connection()
    except Exception as e:
        print("Could not connect to PostgreSQL:", str(e).strip().splitlines()[-1])
        print("Run  python database/check_connection.py  and fix .env first.")
        return False

    passed = 0
    current = None
    for scheme_id, label, citizen, expected in CASES:
        if scheme_id != current:
            scheme = load_scheme(conn, scheme_id)
            if scheme is None:
                print(f"\nScheme '{scheme_id}' not found. Did you run database/import_schemes.py?")
                return False
            print(f"\n{scheme['scheme_name']}  ({scheme_id})")
            for rule in load_rules(conn, scheme_id):
                print(f"   rule: {rule.description}")
            print("-" * 72)
            current = scheme_id

        result = check_scheme(conn, citizen, scheme_id)
        ok = result == expected
        passed += ok
        print(f"[{'PASS' if ok else 'FAIL'}] {label:24} expected={expected:13} got={result}")

    conn.close()
    print(f"\n{passed}/{len(CASES)} tests passed")
    return passed == len(CASES)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
