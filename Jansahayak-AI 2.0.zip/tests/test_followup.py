"""test_followup.py: tests the follow-up questions and the saving of answers.

Uses fake answers instead of typing, so it runs by itself. Needs the database.

Run from the JanSahayak-AI folder:
    python tests/test_followup.py
"""
import os
import sys
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(errors="replace")

from agent.followup import MAX_QUESTIONS, merge, parse_answer
from agent.rule_based_extractor import extract_profile
from engine import profile_store
from engine.db_rules import get_connection
from engine.scheme_matcher import match_schemes
from schemas.citizen_schema import CitizenProfile
from agent.followup import ask_followups


def fake_user(answers):
    """Pretends to be the user: returns the next answer each time a question is asked."""
    asked = []

    def ask(question):
        asked.append(question.strip())
        return answers.get(len(asked), "")
    return ask, asked


def main():
    checks = []
    conn = get_connection()
    match = lambda p: match_schemes(conn, p)                  # noqa: E731

    # 1) First question is the one that decides the most schemes (state), and answers get stored
    profile = extract_profile("mai 23 saal ka hoon gaon mai rehta hu mujhe kaam chahiye")
    ask, asked = fake_user({1: "Bihar", 2: "2", 3: "1 lakh"})
    profile, schemes, conversation = ask_followups(profile, match, ask=ask, say=lambda *a: None)
    print("Questions asked:")
    for q in asked:
        print("  ", q.splitlines()[0])
    checks.append(("asks at most 3 questions", len(asked) <= MAX_QUESTIONS))
    checks.append(("first question is about state", conversation[0]["field"] == "state"))
    checks.append(("answer 'Bihar' stored as state", profile.state == "Bihar"))
    checks.append(("answer '2' stored as category obc", profile.category == "obc"))
    checks.append(("answer '1 lakh' stored as income 100000", profile.annual_income == 100000))
    checks.append(("age 23 from first message kept", profile.age == 23))
    checks.append(("MGNREGA still eligible", "mgnrega" in {s["scheme_id"] for s in schemes["eligible"]}))

    # 2) Stops early when nothing is missing
    full = CitizenProfile(age=23, gender="male", state="Bihar", area="rural", annual_income=50000,
                          category="obc", has_disability=False, has_bpl_card=False,
                          needs=["employment"])
    ask, asked = fake_user({})
    ask_followups(full, match, ask=ask, say=lambda *a: None)
    checks.append(("no questions when profile is complete", len(asked) == 0))

    # 3) Reading answers
    checks.append(("'25' -> age 25", parse_answer("age", "25")[0] == 25))
    checks.append(("'8 hazar mahina' -> income 96000", parse_answer("annual_income", "8 hazar mahina")[0] == 96000))
    checks.append(("option '3' -> category sc", parse_answer("category", "3")[0] == "sc"))
    checks.append(("bare '2' for income is not guessed", parse_answer("annual_income", "2")[0] is None))
    checks.append(("'haan' -> yes", parse_answer("has_bpl_card", "haan")[0] is True))
    checks.append(("'uttar pradesh' -> state", parse_answer("state", "uttar pradesh")[0] == "Uttar Pradesh"))

    # 4) Merging never overwrites a known field
    merged = merge(CitizenProfile(age=23), CitizenProfile(age=40, state="Bihar"))
    checks.append(("merge keeps known age, adds state", merged.age == 23 and merged.state == "Bihar"))

    # 5) Saving and loading: PostgreSQL ...
    where = profile_store.save_profile(profile, conversation, conn)
    saved = profile_store.load_profile(profile.citizen_id, conn)
    checks.append(("saved in PostgreSQL", where.startswith("PostgreSQL")))
    checks.append(("loaded back from PostgreSQL", saved and saved["profile"]["state"] == "Bihar"))
    with conn, conn.cursor() as cur:                           # remove the test row again
        cur.execute("DELETE FROM citizen_profiles WHERE session_id = %s", (profile.citizen_id,))

    # ... and the JSON file backup when the database is down
    with mock.patch.object(profile_store, "get_connection", side_effect=Exception("db down")):
        where = profile_store.save_profile(profile, conversation)
        saved = profile_store.load_profile(profile.citizen_id)
    checks.append(("saved to JSON file when DB is down", where.endswith(".json")))
    checks.append(("loaded back from JSON file", saved and saved["profile"]["state"] == "Bihar"))
    os.remove(where)
    conn.close()

    print()
    passed = 0
    for label, ok in checks:
        passed += bool(ok)
        print(f"[{'PASS' if ok else 'FAIL'}] {label}")
    print(f"\n{passed}/{len(checks)} tests passed")
    return passed == len(checks)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
