"""make_sample_person.py: creates FAKE documents of one test person, as photos and a PDF.

    Sunita Devi, 22, female, village in Vaishali (Bihar), OBC, family income Rs 90,000 a year

Run from the JanSahayak-AI folder (only needed again if you delete the folder):
    python tests/make_sample_person.py
Files go to tests/sample_person/. Every document says "SAMPLE - NOT A REAL DOCUMENT".
"""
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).resolve().parent / "sample_person"
FONTS = "C:/Windows/Fonts/"


def font(name, size):
    try:
        return ImageFont.truetype(FONTS + name, size)
    except OSError:
        return ImageFont.load_default()


REGULAR, BOLD, HINDI = font("arial.ttf", 30), font("arialbd.ttf", 36), font("Nirmala.ttc", 32)


def document(filename, lines, size=(1100, 700), border="#1a4c8b"):
    """Draws a simple card/certificate: each line is (text, font) or (text, font, x)."""
    img = Image.new("RGB", size, "white")
    d = ImageDraw.Draw(img)
    d.rectangle([8, 8, size[0] - 8, size[1] - 8], outline=border, width=6)
    y = 30
    for line in lines:
        text, f = line[0], line[1]
        d.text((50, y), text, fill="black", font=f)
        y += int(f.size * 1.9)
    img.save(OUT / filename)
    return img


def photo(filename):
    """A plain passport-style picture (a drawn face, no text)."""
    img = Image.new("RGB", (350, 450), "#dfe9f5")
    d = ImageDraw.Draw(img)
    d.ellipse([105, 80, 245, 240], fill="#c68c53")          # face
    d.rectangle([60, 260, 290, 450], fill="#8b1a4c")         # clothes
    d.ellipse([90, 60, 260, 150], fill="#2b1d0e")            # hair
    img.save(OUT / filename)


def main():
    OUT.mkdir(exist_ok=True)
    sample = ("SAMPLE - NOT A REAL DOCUMENT", REGULAR)

    aadhaar = document("aadhaar.png", [
        sample,
        ("भारत सरकार", HINDI),
        ("Government of India", BOLD),
        ("Sunita Devi", REGULAR),
        ("DOB : 12/03/2004", REGULAR),
        ("FEMALE", REGULAR),
        ("5678 1234 9012", BOLD),
        ("Address: Village Belsar, Vaishali, Bihar - 844101", REGULAR),
    ])
    aadhaar.save(OUT / "aadhaar_scanned.pdf", resolution=150)  # same Aadhaar as a scanned PDF

    document("income_certificate.png", [
        sample,
        ("Government of Bihar", BOLD),
        ("Income Certificate", BOLD),
        ("Certificate No: BRCC/2026/778899", REGULAR),
        ("This is to certify that Smt Sunita Devi, D/O Ramesh Prasad,", REGULAR),
        ("resident of Village Belsar, District Vaishali, Bihar,", REGULAR),
        ("has an annual family income of Rs. 90,000/- from all sources.", REGULAR),
    ], size=(1200, 620))

    document("bank_passbook.png", [
        sample,
        ("Punjab National Bank", BOLD),
        ("Savings Account Passbook", REGULAR),
        ("Branch: Vaishali", REGULAR),
        ("IFSC: PUNB0123400", REGULAR),
        ("Customer Name: Sunita Devi", REGULAR),
        ("Account No: 012345678901", REGULAR),
    ])

    document("caste_certificate.png", [
        sample,
        ("Government of Bihar", BOLD),
        ("Caste Certificate", BOLD),
        ("This is to certify that Smt Sunita Devi, D/O Ramesh Prasad,", REGULAR),
        ("resident of Village Belsar, District Vaishali, Bihar,", REGULAR),
        ("belongs to the Other Backward Class (OBC) community.", REGULAR),
    ], size=(1200, 560))

    document("ration_card.png", [
        sample,
        ("Food and Civil Supplies Department, Bihar", BOLD),
        ("Ration Card - Priority Household (PHH)", REGULAR),
        ("Name of Head: Ramesh Prasad", REGULAR),
        ("Members: Ramesh Prasad, Sunita Devi", REGULAR),
    ], size=(1100, 480))

    document("marksheet_class12.png", [
        sample,
        ("Bihar School Examination Board", BOLD),
        ("Senior Secondary Examination 2022 - Marksheet", REGULAR),
        ("Name: Sunita Devi", REGULAR),
        ("Roll No: 22-123456", REGULAR),
        ("Result: PASS - First Division", REGULAR),
    ], size=(1100, 540))

    photo("photo.png")

    (OUT / "README.txt").write_text(
        "FAKE test person for JanSahayak AI (all documents say SAMPLE - NOT A REAL DOCUMENT)\n\n"
        "Name     : Sunita Devi\n"
        "Age      : 22 (born 12/03/2004), female\n"
        "Lives in : Village Belsar, Vaishali, Bihar (rural)\n"
        "Category : OBC\n"
        "Income   : Rs 90,000 a year (family)\n"
        "Needs    : a job / internship\n\n"
        "Sentence to type in main.py:\n"
        "  mai 22 saal ki hoon, Bihar ke gaon mai rehti hu, OBC hoon, ghar ki kamai 90 hazar saal ki hai, "
        "mujhe naukri chahiye\n", encoding="utf-8")
    print("Sample person created in", OUT)


if __name__ == "__main__":
    main()
