"""test_apply_mode.py: tests the online / offline / both / unknown detection.

Run from the JanSahayak-AI folder:
    python tests/test_apply_mode.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(errors="replace")

from engine.db_rules import get_connection
from services.apply_mode import classify, first_url, next_step, where_to_submit

ONLINE = "[Online]\nStep 1: Visit https://pmkisan.gov.in/ and click New Farmer Registration.\nStep 2: Fill the form."
OFFLINE = ("[Offline]\nStep 1: Download the application form.\nStep 2: Fill it.\n"
           "Step 3: Submit the form along with the documents at the Block Development Office.")
CSC = "[Online - via CSC]\nStep 1: Visit your nearest Common Service Centre."


def main():
    checks = [
        ("[Online] text -> online", classify(ONLINE)["apply_mode"] == "online"),
        ("[Offline] text -> offline", classify(OFFLINE)["apply_mode"] == "offline"),
        ("both sections -> both", classify(ONLINE + "\n" + OFFLINE)["apply_mode"] == "both"),
        ("no sections -> unknown", classify("Contact the office.")["apply_mode"] == "unknown"),
        ("empty text -> unknown", classify(None)["apply_mode"] == "unknown"),
        ("[Online - via CSC] -> online + via_csc",
         classify(CSC) == {"apply_mode": "online", "apply_via_csc": True, "online_url": None}),
        ("portal link found in online text", classify(ONLINE)["online_url"] == "https://pmkisan.gov.in/"),
        ("'visit pmkisan.gov.in' without https found", first_url("visit pmkisan.gov.in now") == "https://pmkisan.gov.in"),
        ("PDF link is not a portal", first_url("download https://x.gov.in/form.pdf") is None),
        ("email address is not a portal", first_url("mail abc@nic.in or x@gmail.com") is None),
        ("where to submit found",
         where_to_submit(OFFLINE) == "Submit the form along with the documents at the Block Development Office"),
        ("offline next step mentions the form and office",
         "Block Development Office" in next_step("offline", False, None, None, "https://x/f.pdf",
                                                 where_to_submit(OFFLINE))[0]),
        ("unknown next step points to myScheme",
         "myscheme" in next_step("unknown", False, None, "https://www.myscheme.gov.in/schemes/x", None, None)[0]),
    ]

    # Database: the column exists and every scheme has a mode
    conn = get_connection()
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) FILTER (WHERE apply_mode IS NULL), COUNT(*) FROM schemes")
        empty, total = cur.fetchone()
        cur.execute("SELECT apply_mode FROM schemes WHERE scheme_id = 'pm-kisan'")
        pm_kisan = cur.fetchone()[0]
    conn.close()
    checks.append(("every scheme in the database has apply_mode", empty == 0 and total > 0))
    checks.append(("PM-KISAN is online", pm_kisan in ("online", "both")))

    passed = 0
    for label, ok in checks:
        passed += bool(ok)
        print(f"[{'PASS' if ok else 'FAIL'}] {label}")
    print(f"\n{passed}/{len(checks)} tests passed")
    return passed == len(checks)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
