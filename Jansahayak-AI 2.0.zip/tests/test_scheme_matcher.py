"""test_scheme_matcher.py: checks scheme_matcher.py against the real database.

Run from the JanSahayak-AI folder (after database/import_schemes.py):
    python tests/test_scheme_matcher.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from schemas.citizen_schema import CitizenProfile
from engine.db_rules import get_connection
from engine.scheme_matcher import match_schemes


def ids(results, status):
    return {s["scheme_id"] for s in results[status]}


def maybe_missing(results, scheme_id):
    for s in results["maybe"]:
        if s["scheme_id"] == scheme_id:
            return s["missing"]
    return None


def main():
    try:
        conn = get_connection()
    except Exception as e:
        print("Could not connect to PostgreSQL:", str(e).strip().splitlines()[-1])
        return False

    rural = match_schemes(conn, CitizenProfile(age=23, area="rural", state="Bihar", needs=["employment"]))
    urban = match_schemes(conn, CitizenProfile(age=23, area="urban", state="Bihar", needs=["employment"]))
    teen = match_schemes(conn, CitizenProfile(age=17, area="rural", state="Bihar", needs=["employment"]))
    conn.close()

    checks = [
        ("23, rural, Bihar: MGNREGA is eligible",           "mgnrega" in ids(rural, "eligible")),
        ("23, urban, Bihar: MGNREGA is not eligible",       "mgnrega" in ids(urban, "not_eligible")),
        ("17, rural, Bihar: MGNREGA is not eligible",       "mgnrega" in ids(teen, "not_eligible")),
        ("23, income unknown: PM Internship is maybe",      maybe_missing(rural, "pmis") == ["annual_income"]),
        ("Every scheme lands in exactly one list",
         sum(len(v) for v in rural.values()) == len(set().union(*(ids(rural, k) for k in rural)))),
    ]

    passed = 0
    for label, ok in checks:
        passed += ok
        print(f"[{'PASS' if ok else 'FAIL'}] {label}")
    print(f"\n{passed}/{len(checks)} tests passed")
    return passed == len(checks)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
