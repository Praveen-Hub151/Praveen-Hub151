"""test_rule_based_extractor.py: checks the free extractor on Hindi, Hinglish and English.

Run from the JanSahayak-AI folder:
    python tests/test_rule_based_extractor.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(errors="replace")

from agent.rule_based_extractor import extract_profile

# (message, fields we expect; any field not listed must stay empty)
CASES = [
    ("mai 23 saal ka hoon gaon mai rehta hu mujhe kaam chahiye",
     {"age": 23, "gender": "male", "area": "rural", "employment_status": "unemployed",
      "needs": ["employment"]}),

    ("मैं 45 साल की विधवा महिला हूँ, बिहार के गाँव में रहती हूँ, मुझे पेंशन चाहिए",
     {"age": 45, "gender": "female", "state": "Bihar", "area": "rural", "marital_status": "widowed",
      "needs": ["pension"]}),

    ("I am a 30 year old SC farmer from Uttar Pradesh, my income is 1.5 lakh per year, I need a loan",
     {"age": 30, "state": "Uttar Pradesh", "category": "sc", "annual_income": 150000,
      "is_farmer": True, "employment_status": "farmer", "needs": ["loan"]}),

    ("meri umar 19 hai, delhi shahar mai rehti hu, mahine ka 8 hazar kamati hu, padhai ke liye scholarship chahiye",
     {"age": 19, "gender": "female", "state": "Delhi", "area": "urban", "annual_income": 96000,
      "needs": ["education"]}),

    # "1 lakh" here is the loan amount, NOT income, so income must stay empty
    ("mujhe 1 lakh ka loan chahiye",
     {"needs": ["loan"]}),

    ("main berozgar hoon, rajasthan ke dehat se, divyang hoon, obc category",
     {"state": "Rajasthan", "area": "rural", "employment_status": "unemployed",
      "has_disability": True, "category": "obc", "needs": ["employment"]}),

    # "st" inside "1st" or "stay" must not become category ST
    ("I stay in Pune city, 1st year student, 20 years old",
     {"age": 20, "area": "urban", "employment_status": "student"}),

    # ----- skills vs needs, and "nahi" (negation) -----
    # "aata hai" = a skill they have; "jamin nhi hai" = no land, so land is a need
    ("mujhe agriculture ka kaam aata hai lekin mere pass jamin nhi hai",
     {"skills": ["agriculture"], "owns_land": False, "land_owned_acres": 0,
      "needs": ["land", "agriculture"]}),

    ("main 10th pass hoon, silai aati hai, ghar nahi hai, pakka makaan chahiye",
     {"education": "class_10", "skills": ["tailoring"], "has_house": False, "needs": ["housing"]}),

    ("mere pass 2 acre khet hai, kheti karta hu, bank khata nahi hai, beej ke liye loan chahiye",
     {"gender": "male", "owns_land": True, "land_owned_acres": 2, "has_bank_account": False,
      "skills": ["agriculture"], "is_farmer": True, "employment_status": "farmer",
      "needs": ["loan", "agriculture"]}),

    # "sikhna hai" = wants to LEARN it, so it is a training need, not a skill
    ("meri shaadi ho gayi hai, mujhe computer sikhna hai, graduate hoon",
     {"marital_status": "married", "education": "graduate", "needs": ["skill_training"]}),

    # "ghar mai rehta hu" says nothing about owning a house, so has_house stays empty
    ("main dihadi mazdoor hoon, ghar mai rehta hu",
     {"gender": "male", "employment_status": "wage_labourer"}),
]

FIELDS = ["age", "gender", "state", "area", "employment_status", "annual_income", "category",
          "has_disability", "is_farmer", "has_bpl_card", "education", "marital_status",
          "owns_land", "land_owned_acres", "has_house", "has_bank_account", "skills", "needs"]
LIST_FIELDS = ["needs", "skills"]


def main():
    passed = 0
    for message, expected in CASES:
        profile = extract_profile(message)
        wrong = []
        for field in FIELDS:
            got = getattr(profile, field)
            if hasattr(got, "value"):                  # enum -> plain text
                got = got.value
            if field in LIST_FIELDS:
                got = [n.value for n in got]
            want = expected.get(field, [] if field in LIST_FIELDS else None)
            if got != want:
                wrong.append(f"{field}: expected {want}, got {got}")
        ok = not wrong
        passed += ok
        print(f"[{'PASS' if ok else 'FAIL'}] {message[:70]}")
        for w in wrong:
            print("        ", w)
    print(f"\n{passed}/{len(CASES)} tests passed")
    return passed == len(CASES)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
