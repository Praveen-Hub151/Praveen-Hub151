"""test_scheme_service.py: tests services/scheme_matcher.py on the real database,
including the edge cases from the plan.

Run from the JanSahayak-AI folder:
    python tests/test_scheme_service.py
"""
import os
import sys
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(errors="replace")

from engine import scheme_matcher as engine_matcher
from engine.db_rules import get_connection
from schemas.citizen_schema import CitizenProfile
from services.scheme_matcher import (apply_link, get_schemes_for_citizen, is_document,
                                     load_details, scheme_links)

ALL = ("eligible", "maybe", "needs_review", "not_eligible")


def find(results, scheme_id):
    return [r for r in results if r["scheme_id"] == scheme_id]


def main():
    conn = get_connection()
    checks = []

    # 1) A real match comes back with its details
    worker = CitizenProfile(age=23, area="rural", state="Bihar", annual_income=100000,
                            needs=["employment", "skill_training"])
    results = get_schemes_for_citizen(worker, conn, statuses=ALL)
    mgnrega = find(results, "mgnrega")
    checks.append(("MGNREGA is eligible", mgnrega and mgnrega[0]["status"] == "eligible"))
    checks.append(("MGNREGA has benefits text", mgnrega and bool(mgnrega[0]["benefits"])))
    checks.append(("MGNREGA has its 6 documents", mgnrega and len(mgnrega[0]["documents"]) == 6))
    checks.append(("MGNREGA has an apply link", mgnrega and "nrega.nic.in" in mgnrega[0]["apply_link"]))

    # 2) Same scheme with several purposes is listed only once
    checks.append(("scheme with 2 purposes appears once", len(mgnrega) == 1))
    checks.append(("its purposes are both listed",
                   mgnrega and {"employment", "skill_training"} <= set(mgnrega[0]["purposes"])))

    # 3) No rules -> needs_review, never eligible
    anyone = CitizenProfile(age=30, state="Bihar")       # no needs -> every scheme is checked
    results = get_schemes_for_citizen(anyone, conn, statuses=ALL)
    astpss = find(results, "astpss")
    checks.append(("scheme with no rules -> needs_review", astpss and astpss[0]["status"] == "needs_review"))

    # 4) Different state -> not eligible
    gujarat = find(results, "fpgsdau")
    checks.append(("Gujarat scheme for a Bihar citizen -> not_eligible",
                   gujarat and gujarat[0]["status"] == "not_eligible"))

    # ... also when that state scheme has no rules at all
    fake = {"scheme_id": "x", "scheme_name": "Some Gujarat scheme", "level": "state",
            "state": "Gujarat", "official_website": None, "official_application_url": None}
    with mock.patch.object(engine_matcher, "load_schemes", return_value=[fake]), \
         mock.patch.object(engine_matcher, "load_rules_for", return_value={"x": []}):
        out = engine_matcher.match_schemes(conn, anyone)
    checks.append(("other-state scheme without rules -> not_eligible", len(out["not_eligible"]) == 1))

    # 5) Missing application URL -> falls back to the info page, with a note
    cmegp = find(results, "cmegp")
    checks.append(("missing form link -> uses myScheme page",
                   cmegp and cmegp[0]["apply_link"].startswith("https://www.myscheme.gov.in")))
    checks.append(("missing form link -> note says so", cmegp and "missing" in cmegp[0]["link_note"]))
    link, note = apply_link({"official_website": None, "official_application_url": None})
    checks.append(("no links at all -> None + 'Link missing' note", link is None and "Link missing" in note))

    # 6) PDF links: never shown as the apply link
    details = load_details(conn, ["bydbta", "mgnrega", "pm-kisan"])
    pdf_scheme = scheme_links(details["bydbta"])               # dataset link is a .pdf
    checks.append(("PDF apply link -> myScheme page instead",
                   pdf_scheme["apply_link"] == "https://www.myscheme.gov.in/schemes/bydbta"))
    checks.append(("PDF kept as guidelines", pdf_scheme["guidelines_link"].endswith(".pdf")))
    checks.append(("PDF's website offered as official site",
                   pdf_scheme["portal_link"] == "https://www.handicrafts.nic.in/"))
    checks.append(("override used for MGNREGA", scheme_links(details["mgnrega"])["apply_link"] == "https://nrega.nic.in/"))
    checks.append(("override used for PM-KISAN", scheme_links(details["pm-kisan"])["apply_link"] == "https://pmkisan.gov.in/"))
    checks.append(("'...?id=form.pdf&x' counts as a PDF", is_document("https://a.gov.in/ViewFile/?id=form.pdf&path=x")))
    checks.append(("normal portal page is not a PDF", not is_document("https://pmkisan.gov.in/RegistrationFormNew.aspx")))

    # 7) Default list hides not_eligible
    default = get_schemes_for_citizen(worker, conn)
    checks.append(("default list has no not_eligible", all(r["status"] != "not_eligible" for r in default)))
    checks.append(("eligible schemes come first", default[0]["status"] == "eligible"))
    conn.close()

    passed = 0
    for label, ok in checks:
        passed += bool(ok)
        print(f"[{'PASS' if ok else 'FAIL'}] {label}")
    print(f"\n{passed}/{len(checks)} tests passed")
    return passed == len(checks)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
