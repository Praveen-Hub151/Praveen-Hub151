"""test_documents.py: tests reading Aadhaar / income certificate / bank passbook.

Uses the SAMPLE files in tests/sample_documents (fake data). The photo test only
runs once Tesseract OCR is installed; until then it shows SKIP.

Run from the JanSahayak-AI folder:
    python tests/test_documents.py
"""
import os
import sys
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.stdout.reconfigure(errors="replace")

from documents import document_profile
from documents.document_profile import apply_documents, document_checklist, read_document
from documents.extractors import age_on, detect_type, extract, mask
from documents.ocr import find_tesseract
from schemas.citizen_schema import CitizenProfile
from datetime import date

SAMPLES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_documents")


def sample(name):
    return os.path.join(SAMPLES, name)


def main():
    aadhaar = read_document(sample("aadhaar_sample.txt"))
    income = read_document(sample("income_certificate_sample.txt"))
    bank = read_document(sample("bank_passbook_sample.txt"))

    checks = [
        # Which document is it?
        ("Aadhaar recognised", aadhaar["type"] == "aadhaar"),
        ("income certificate recognised", income["type"] == "income_certificate"),
        ("bank passbook recognised", bank["type"] == "bank_passbook"),
        ("random text -> unknown", detect_type("Hello, this is a letter.") == "unknown"),

        # Aadhaar details
        ("Aadhaar name", aadhaar["details"].get("name") == "Ramesh Kumar"),
        ("Aadhaar date of birth", aadhaar["details"].get("date_of_birth") == "15/08/2000"),
        ("Aadhaar gender", aadhaar["details"].get("gender") == "male"),
        ("Aadhaar state + pincode", aadhaar["details"].get("state") == "Bihar"
         and aadhaar["details"].get("pincode") == "842001"),
        ("Aadhaar number is MASKED", aadhaar["details"].get("aadhaar_number") == "XXXX XXXX 0123"),
        ("full Aadhaar number never kept", "2345" not in str(aadhaar)),
        ("age from DOB is correct", age_on(date(2000, 8, 15), date(2026, 8, 14)) == 25
         and age_on(date(2000, 8, 15), date(2026, 8, 15)) == 26),

        # Income certificate
        ("income Rs. 1,20,000/- -> 120000", income["details"].get("annual_income") == 120000),
        ("income '1.5 lakh' -> 150000",
         extract("Income Certificate\nannual income: Rs 1.5 lakh")["profile"].get("annual_income") == 150000),
        ("certificate holder name", income["details"].get("name") == "Ramesh Kumar"),

        # Bank passbook
        ("IFSC found", bank["details"].get("ifsc") == "SBIN0001234"),
        ("bank name found", bank["details"].get("bank") == "State Bank of India"),
        ("account number MASKED", bank["details"].get("account_number") == "XXXXXXX7890"),
        ("mask keeps last 4 only", mask("1234 5678 9012") == "XXXX XXXX 9012"),

        # Filling the profile
    ]
    profile, changes = apply_documents(CitizenProfile(age=23, area="rural"), [aadhaar, income, bank])
    checks += [
        ("document age replaces chat age", profile.age == aadhaar["details"]["age"]),
        ("the change is reported", any(c.startswith("age: 23 ->") for c in changes)),
        ("income, state, Aadhaar, bank filled", profile.annual_income == 120000
         and profile.state == "Bihar" and profile.has_aadhaar and profile.has_bank_account),
        ("chat-only fields kept (area)", profile.area.value == "rural"),
    ]

    # Document checkmarks for a scheme
    required = ["Aadhaar Card", "Income Certificate", "Bank Passbook copy", "Caste Certificate", "Photo"]
    ticks = dict((name, done) for done, name in document_checklist(required, {"aadhaar", "bank_passbook"}))
    checks.append(("checklist ticks Aadhaar + bank, not income/caste/photo",
                   ticks == {"Aadhaar Card": True, "Income Certificate": False, "Bank Passbook copy": True,
                             "Caste Certificate": False, "Photo": False}))

    # Saving: JSON backup when the database is down (nothing is written to the DB here)
    with mock.patch("engine.db_rules.get_connection", side_effect=Exception("db down")):
        where = document_profile.save_documents("test-session", [aadhaar])
    checks.append(("saved to JSON when DB is down", where.endswith("test-session_documents.json")))
    with open(where, encoding="utf-8") as f:
        checks.append(("saved file has only the masked number", "2345 6789" not in f.read()))
    os.remove(where)

    passed = 0
    for label, ok in checks:
        passed += bool(ok)
        print(f"[{'PASS' if ok else 'FAIL'}] {label}")

    # Photo OCR: only when Tesseract is installed
    if find_tesseract():
        photo = read_document(sample("aadhaar_sample.png"))
        ok = photo["type"] == "aadhaar" and photo["details"].get("date_of_birth") == "15/08/2000"
        passed += ok
        checks.append(("photo", ok))
        print(f"[{'PASS' if ok else 'FAIL'}] photo of Aadhaar read with OCR")
    else:
        print("[SKIP] photo OCR test (install Tesseract to run it)")

    print(f"\n{passed}/{len(checks)} tests passed")
    return passed == len(checks)


if __name__ == "__main__":
    sys.exit(0 if main() else 1)
