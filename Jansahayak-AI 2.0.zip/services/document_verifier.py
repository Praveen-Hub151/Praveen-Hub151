"""document_verifier.py: required documents of ONE scheme, upload per document, verification checkmarks.

This is the part your website will call when someone clicks a scheme:

    required_documents(conn, scheme_id)
        -> the scheme's document list from myScheme (scheme_documents table),
           each sorted into a type: aadhaar, income_certificate, caste_certificate, photo ...

    verify_scheme_documents(conn, scheme_id, uploads)
        uploads = {item_number: file_path}   (one file per required document)
        -> a status per required document:
             verified        right document, details readable and they pass the checks
             wrong_document  e.g. a bank passbook uploaded where Aadhaar was asked
             check_failed    right document, but a check failed (name differs from Aadhaar,
                             income above the scheme's limit, other state, age too low ...)
             manual_review   uploaded, but this type can't be read automatically (photo,
                             marksheet ...) so a person must look at it
             missing         not uploaded yet
             optional        "any other document" / "(if applicable)": not needed to be ready
             info            not a file (mobile number, email): typed into the form

Try it in the terminal (asks you to drag a file for each document):
    python services/document_verifier.py mgnrega
    python services/document_verifier.py pmis --password RAME2000     # locked e-Aadhaar PDF
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agent.rule_based_extractor import find
from documents.document_profile import apply_documents, read_document
from schemas.citizen_schema import CitizenProfile
from schemas.eligibility_schema import Result, check_rule

# Required-document name -> type. Checked top to bottom; first match wins.
KINDS = [
    ("identity_proof", ["photo id", "photo identity"]),
    ("info", ["mobile number", "mobile no", "email", "e-mail", "phone number", "contact number",
              "name of", "name, age", "details of", "specimen signature", "signature", "thumb impression"]),
    ("photo", ["photograph", "photo", "photos"]),
    ("aadhaar", ["aadhaar", "aadhar", "uid", "आधार"]),
    ("income_certificate", ["income", "आय"]),
    ("caste_certificate", ["caste", "community certificate", "tribe certificate", "jati", "जाति"]),
    ("disability_certificate", ["disability", "disabled", "divyang", "udid", "handicap"]),
    ("ration_card", ["ration", "bpl", "antyodaya"]),
    ("bank_passbook", ["bank", "passbook", "pass book", "cheque", "ifsc", "account details"]),
    ("domicile_certificate", ["domicile", "permanent residence", "permanent resident", "niwas",
                              "residence certificate", "residential certificate"]),
    ("address_proof", ["address proof", "proof of address", "residence proof", "proof of residence",
                       "address"]),
    ("age_proof", ["age", "birth", "dob"]),
    ("identity_proof", ["identity", "id proof", "voter", "pan card", "passport", "driving licence",
                        "driving license", "samagra"]),
    ("education", ["mark sheet", "marksheet", "marks", "qualification", "degree", "education",
                   "educational", "certificates of education",
                   "school", "college", "admission", "bonafide", "10th", "12th"]),
]
OPTIONAL_WORDS = ["any other", "other supporting", "other relevant", "if applicable", "if required",
                  "if any", "as required", "as applicable", "wherever applicable"]

# Which uploaded document type can stand for which required type
SATISFIES = {
    "aadhaar": {"aadhaar", "identity_proof", "age_proof", "address_proof"},
    "income_certificate": {"income_certificate"},
    "bank_passbook": {"bank_passbook"},
    "caste_certificate": {"caste_certificate"},
    "disability_certificate": {"disability_certificate"},
    "ration_card": {"ration_card", "address_proof"},
    "domicile_certificate": {"domicile_certificate", "address_proof"},
}
AUTO_CHECK = set().union(*SATISFIES.values())        # types we can read and check ourselves

LABELS = {"verified": "[OK]    ", "wrong_document": "[WRONG] ", "check_failed": "[FAIL]  ",
          "manual_review": "[REVIEW]", "missing": "[ ]     ", "optional": "[opt]   ", "info": "[info]  "}


def classify_requirement(name: str) -> dict:
    low = name.lower()
    kind = next((k for k, words in KINDS if find(low, words)), "other")
    optional = bool(find(low, OPTIONAL_WORDS)) or low.startswith("any other")
    # "Proof of Identity (Ration card, Voter ID, Aadhaar, PAN)" accepts ANY of the documents it names
    accepts = {kind} if kind in ("info", "photo") else \
        {k for k, words in KINDS if k not in ("info", "photo") and find(low, words)} or {kind}
    return {"name": name, "kind": kind, "accepts": sorted(accepts), "optional": optional,
            "auto_check": bool(accepts & AUTO_CHECK)}


def required_documents(conn, scheme_id: str) -> list[dict]:
    """The scheme's document list, numbered from 1, each with its type."""
    with conn.cursor() as cur:
        cur.execute("SELECT document_name FROM scheme_documents WHERE scheme_id = %s ORDER BY document_id",
                    (scheme_id,))
        names = [r[0] for r in cur.fetchall()]
    return [{"number": i, **classify_requirement(n)} for i, n in enumerate(names, start=1)]


def load_scheme(conn, scheme_id: str) -> dict | None:
    with conn.cursor() as cur:
        cur.execute("SELECT scheme_id, scheme_name, state FROM schemes WHERE scheme_id = %s", (scheme_id,))
        row = cur.fetchone()
        if not row:
            return None
        cur.execute("""SELECT rule_id, scheme_id, field, operator, value, required, condition_group,
                              description FROM eligibility_rules WHERE scheme_id = %s""", (scheme_id,))
        from schemas.eligibility_schema import EligibilityRule
        rules = [EligibilityRule(rule_id=r[0], scheme_id=r[1], field=r[2], operator=r[3], value=r[4],
                                 required=r[5], condition_group=r[6], description=r[7] or "")
                 for r in cur.fetchall()]
    return {"scheme_id": row[0], "scheme_name": row[1], "state": row[2], "rules": rules}


def same_person(a: str | None, b: str | None) -> bool:
    """'Ramesh Kumar' vs 'RAMESH KUMAR SINGH' -> True. Unknown names never fail."""
    if not a or not b:
        return True
    x, y = set(a.lower().split()), set(b.lower().split())
    return x <= y or y <= x or len(x & y) >= 2


def verify_scheme_documents(conn, scheme_id: str, uploads: dict, profile: CitizenProfile | None = None,
                            password: str | None = None, progress=None) -> dict:
    """uploads = {item_number: file_path or an already-read document dict}."""
    scheme = load_scheme(conn, scheme_id)
    if scheme is None:
        raise ValueError(f"No scheme with id '{scheme_id}'")
    items = required_documents(conn, scheme_id)

    # 1) Read every uploaded file (the same file uploaded twice is read only once)
    read: dict[int, dict] = {}
    cache: dict[str, dict] = {}
    for number, upload in uploads.items():
        if isinstance(upload, dict):
            read[number] = upload
            continue
        key = os.path.abspath(upload)
        if key not in cache:
            if progress:
                progress(f"Reading {os.path.basename(upload)} ...")
            try:
                cache[key] = read_document(upload, password)
            except Exception as e:                   # unreadable file -> manual review with reason
                cache[key] = {"file": os.path.basename(str(upload)), "type": "unknown",
                              "details": {}, "profile": {}, "error": str(e)}
        read[number] = cache[key]

    # 2) Profile from the documents (documents win over what was typed in the chat)
    docs = list(read.values())
    doc_profile, _ = apply_documents(profile or CitizenProfile(), docs)
    citizen = doc_profile.model_dump()
    reference_name = next((d["details"].get("name") for d in docs if d["type"] == "aadhaar"), None) \
        or next((d["details"].get("name") for d in docs if d["details"].get("name")), None)

    def fits(doc, item):
        return doc and not doc.get("error") and doc["type"] in SATISFIES \
            and bool(SATISFIES[doc["type"]] & set(item["accepts"]))

    def check(doc):
        """Checks on a document of the right type: same person, right state, scheme rules."""
        status, reason = "verified", f"{doc['type'].replace('_', ' ')} recognised"
        name = doc["details"].get("name")
        family_doc = doc["type"] == "ration_card"         # made out to the head of the family
        if not family_doc and not same_person(name, reference_name):
            status, reason = "check_failed", f"Name '{name}' differs from '{reference_name}'"
        for field, value in doc["profile"].items():
            if field == "state" and scheme["state"] and value != scheme["state"]:
                status, reason = "check_failed", f"Document is from {value}, scheme is for {scheme['state']}"
            for rule in scheme["rules"]:
                if rule.field == field and check_rule(rule, citizen) == Result.failed:
                    status, reason = "check_failed", f"{rule.description} (document shows {value})"
        return status, reason

    # 3) Status of each required document
    results = []
    for item in items:
        doc = read.get(item["number"])
        status, reason = "missing", ""
        if item["kind"] == "info":
            status, reason = "info", "Type this into the form, no file needed"
        elif doc is None:
            # One upload can cover several items: Aadhaar is also proof of age / identity / address
            other = next((d for d in docs if fits(d, item)), None)
            if other:
                doc = other
                status, reason = check(other)
                if status == "verified":
                    reason = f"Covered by the {other['type'].replace('_', ' ')} you uploaded"
            else:
                status = "optional" if item["optional"] else "missing"
        elif doc.get("error"):
            locked = "password" in doc["error"].lower()
            status = "check_failed" if locked else "manual_review"
            reason = doc["error"].splitlines()[0] if locked else \
                f"Could not read the file: {doc['error'].splitlines()[0]}"
        elif fits(doc, item):
            status, reason = check(doc)
        elif doc["type"] in SATISFIES:               # a document we know, but not the one asked for
            needed = " or ".join(k.replace("_", " ") for k in item["accepts"])
            status, reason = "wrong_document", (f"This looks like: {doc['type'].replace('_', ' ')}. "
                                                f"Needed here: {needed}")
        else:                                        # photo, marksheet, other: a person must check
            status, reason = "manual_review", "Uploaded, will be checked by a person"
        results.append({**item, "file": doc["file"] if doc else None, "status": status, "reason": reason,
                        "details": doc["details"] if doc else {}})

    needed = [r for r in results if r["status"] not in ("optional", "info")]
    done = [r for r in needed if r["status"] in ("verified", "manual_review")]
    return {
        "scheme_id": scheme_id, "scheme_name": scheme["scheme_name"], "items": results,
        "uploaded": [{"number": n, "file": d["file"], "type": d["type"], "details": d["details"]}
                     for n, d in read.items()],
        "profile": doc_profile,
        "summary": f"{len(done)} of {len(needed)} documents ready",
        "ready": len(done) == len(needed) and not any(r["status"] == "check_failed" for r in results),
    }


# ---------- saving (for the website and pgAdmin) ----------

CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS document_checks (
    id                SERIAL PRIMARY KEY,
    session_id        VARCHAR(100) NOT NULL,
    scheme_id         VARCHAR(100) NOT NULL,
    item_number       INT,
    required_document TEXT,
    doc_kind          VARCHAR(30),
    file_name         TEXT,
    status            VARCHAR(20),
    reason            TEXT,
    details           JSONB,               -- numbers masked
    checked_at        TIMESTAMPTZ NOT NULL DEFAULT now()
)"""


def save_checks(conn, session_id: str, result: dict) -> None:
    with conn, conn.cursor() as cur:
        cur.execute(CREATE_TABLE)
        cur.execute("DELETE FROM document_checks WHERE session_id = %s AND scheme_id = %s",
                    (session_id, result["scheme_id"]))      # keep only the latest check
        cur.executemany(
            """INSERT INTO document_checks (session_id, scheme_id, item_number, required_document,
                   doc_kind, file_name, status, reason, details) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            [(session_id, result["scheme_id"], r["number"], r["name"], r["kind"], r["file"], r["status"],
              r["reason"], json.dumps(r["details"], ensure_ascii=False)) for r in result["items"]])


def print_result(result: dict) -> None:
    print(f"\n{result['scheme_name']}: {result['summary']}"
          f"{'  -> READY TO APPLY' if result['ready'] else ''}")
    for r in result["items"]:
        file = f"  <- {r['file']}" if r["file"] else ""
        print(f"  {LABELS[r['status']]} {r['number']:>2}. {r['name'][:70]}{file}")
        if r["reason"] and r["status"] not in ("verified", "info"):
            print(f"              {r['reason']}")


if __name__ == "__main__":
    sys.stdout.reconfigure(errors="replace")
    from engine.db_rules import get_connection

    args = sys.argv[1:]
    password = None
    if "--password" in args:                     # for a locked e-Aadhaar PDF
        i = args.index("--password")
        password = args[i + 1]
        args = args[:i] + args[i + 2:]
    if not args:
        print(__doc__)
        sys.exit(1)
    scheme_id = args[0]
    conn = get_connection()
    scheme = load_scheme(conn, scheme_id)
    if not scheme:
        print(f"No scheme with id '{scheme_id}'. Find ids in pgAdmin: "
              "SELECT scheme_id, scheme_name FROM schemes WHERE scheme_name ILIKE '%kisan%';")
        sys.exit(1)

    items = required_documents(conn, scheme_id)
    print(f"{scheme['scheme_name']}\nDocuments needed:")
    for it in items:
        tag = " (optional)" if it["optional"] else " (no file, type it)" if it["kind"] == "info" else ""
        print(f"  {it['number']:>2}. {it['name']}  [{it['kind']}]{tag}")

    print("\nHar document ke liye file ko yahan drag karo aur Enter dabao (skip: sirf Enter).")
    uploads = {}
    for it in items:
        if it["kind"] == "info":
            continue
        path = input(f"  {it['number']:>2}. {it['name'][:60]} > ").strip()
        path = path.removeprefix("& ").strip().strip("'\"")
        if path:
            uploads[it["number"]] = path

    print("\nChecking documents (photos and scanned PDFs take a few seconds each) ...")
    result = verify_scheme_documents(conn, scheme_id, uploads, password=password,
                                     progress=lambda msg: print("  " + msg, flush=True))
    print_result(result)
    conn.close()
