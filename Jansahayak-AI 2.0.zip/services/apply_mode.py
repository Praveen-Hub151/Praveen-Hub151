"""apply_mode.py: works out HOW a person applies for a scheme.

    online    apply on a website / portal
    offline   fill a paper form and submit it at an office
    both      either way works
    unknown   the text doesn't say

How it decides:
    myScheme writes the application_process text in sections, like
        [Online]  Step 1: Visit https://... Step 2: Register ...
        [Offline] Step 1: Download the form ... Step 3: Submit it at the Block Office
    so we read those section names. "[Online - via CSC]" means online, done for you
    at a Common Service Centre (CSC).

It also pulls out:
    online_url     the first website link written in the [Online] part (not a PDF)
    where_submit   the sentence that says where to submit the form (offline)
"""
import os
import re

SECTION = re.compile(r"\[([^\]\n]{2,40})\]")
URL = re.compile(r"https?://[^\s<>\"')\]]+")
# "visit pmkisan.gov.in" (no https://) also counts
DOMAIN = re.compile(r"(?<![@\w.-])(?:www\.)?[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:gov\.in|nic\.in|org\.in|co\.in|in|org|com)\b"
                    r"(?:/[^\s<>\"')\]]*)?", re.I)
DOCUMENT = re.compile(r"\.(pdf|docx?|xlsx?|odt|pptx?|zip|rar)(?=$|[?#&/])|\.pdf|"
                      r"/(download|downloadfile|viewfile|writereaddata|uploaded|uploads|uploadfile|upload)/",
                      re.I)
SUBMIT = re.compile(r"[^.\n]*\b(submit|hand over|deposit)\b[^.\n]*", re.I)


def sections(text: str | None) -> dict[str, str]:
    """'[Online] a [Offline] b' -> {'online': 'a', 'offline': 'b'} (only online/offline parts)."""
    parts = SECTION.split(text or "")
    found: dict[str, str] = {}
    for i in range(1, len(parts) - 1, 2):
        name = parts[i].strip().lower()
        if name.startswith("online") or name.startswith("offline"):
            found[name] = found.get(name, "") + parts[i + 1]
    return found


NOT_PORTALS = ("gov.in", "nic.in", "org.in", "co.in", "gmail.com", "yahoo.com", "yahoo.co.in",
               "hotmail.com", "outlook.com", "rediffmail.com")


BROKEN_TXT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "broken_links.txt")
_broken = None


def broken_links() -> set[str]:
    """Links found broken by database/fix_links.py (data/broken_links.txt)."""
    global _broken
    if _broken is None:
        _broken = set()
        if os.path.exists(BROKEN_TXT):
            with open(BROKEN_TXT, encoding="utf-8") as f:
                _broken = {line.strip() for line in f if line.strip()}
    return _broken


def first_url(text: str) -> str | None:
    for url in URL.findall(text or "") + ["https://" + d for d in DOMAIN.findall(text or "")]:
        url = url.rstrip(".,;:")
        if url in broken_links():
            continue
        host = url.split("://", 1)[-1].split("/", 1)[0].lower().removeprefix("www.")
        if not DOCUMENT.search(url) and "@" not in url and host not in NOT_PORTALS:
            return url
    return None


def classify(application_process: str | None) -> dict:
    """Returns {"apply_mode", "apply_via_csc", "online_url"} for one scheme."""
    found = sections(application_process)
    online = [k for k in found if k.startswith("online")]
    offline = "offline" in found

    if online and offline:
        mode = "both"
    elif online:
        mode = "online"
    elif offline:
        mode = "offline"
    else:
        mode = "unknown"

    online_text = " ".join(found[k] for k in online)
    return {
        "apply_mode": mode,
        "apply_via_csc": any("csc" in k for k in online),
        "online_url": first_url(online_text) if online else None,
    }


def where_to_submit(application_process: str | None) -> str | None:
    """The sentence from the [Offline] part that says where to submit the form."""
    offline = sections(application_process).get("offline", "")
    m = SUBMIT.search(offline)
    if not m:
        return None
    sentence = m.group(0).strip()
    if sentence.endswith(":"):                    # "...to the following address:" -> add the next line
        rest = offline[m.end():].lstrip(" :\n")
        sentence += " " + rest.split("\n", 1)[0]
    sentence = re.sub(r"^\s*(step\s*0?\d+\s*[:.-]\s*)", "", sentence, flags=re.I)
    return " ".join(sentence.split())


def next_step(mode: str, via_csc: bool, online_url: str | None, apply_link: str | None,
              guidelines_link: str | None, where: str | None, portal_link: str | None = None) -> list[str]:
    """Plain lines telling the person what to do next."""
    lines = []
    if mode in ("online", "both"):
        if online_url:
            line = f"Apply online: {online_url}"
        elif portal_link:
            line = f"Apply online on the official website {portal_link} (step-by-step guide: {apply_link})"
        else:
            line = f"Apply online: steps and link on {apply_link or 'myscheme.gov.in'}"
        if via_csc:
            line += "  (or ask your nearest CSC / Jan Seva Kendra to apply for you)"
        lines.append(line)
    if mode in ("offline", "both"):
        form = (f"get the form (guidelines PDF: {guidelines_link})" if guidelines_link
                else "get the form from the office")
        lines.append(f"Apply offline: {form}, fill it, attach the documents above, then: "
                     f"{where or 'submit it at the office named on the myScheme page'}")
    if mode == "unknown":
        lines.append(f"How to apply is not written here, check: {apply_link or 'myscheme.gov.in'}")
    return lines
