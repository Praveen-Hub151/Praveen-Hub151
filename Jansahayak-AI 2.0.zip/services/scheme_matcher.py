"""services/scheme_matcher.py: matched schemes WITH their details, ready to show a user.

engine/scheme_matcher.py already decides eligible / maybe / not_eligible for every
scheme. This file adds what a user needs next for each matched scheme:

    description, benefits, required documents, how to apply, apply link

Statuses returned:
    eligible       passes every rule
    maybe          nothing failed, but some details are missing (see "missing")
    not_eligible   fails a rule, or is a state scheme for another state
    needs_review   the scheme has no structured rules, so a person must read its eligibility text

Run from the JanSahayak-AI folder:
    python services/scheme_matcher.py
"""
import csv
import html
import os
import re
import sys
from urllib.parse import urlparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine.db_rules import get_connection
from engine.scheme_matcher import match_schemes
from schemas.citizen_schema import CitizenProfile
from services.apply_mode import classify, next_step, where_to_submit

STATUSES = {"eligible": "eligible", "maybe": "maybe",
            "not_eligible": "not_eligible", "no_rules": "needs_review"}


def load_details(conn, scheme_ids: list[str]) -> dict[str, dict]:
    """Details, documents and purposes for many schemes, in 3 queries."""
    details = {}
    with conn.cursor() as cur:
        cur.execute("SELECT column_name FROM information_schema.columns WHERE table_name = 'schemes'")
        have = {r[0] for r in cur.fetchall()}
        extra = "".join(f", {c}" for c in ("original_application_url", "link_status") if c in have)
        cur.execute(
            f"""SELECT scheme_id, description, benefits, application_process,
                      official_website, official_application_url, ministry, level, state{extra}
               FROM schemes WHERE scheme_id = ANY(%s)""",
            (scheme_ids,),
        )
        columns = [c.name for c in cur.description]
        for row in cur.fetchall():
            d = dict(zip(columns, row))
            details[d["scheme_id"]] = {**d, "documents": [], "purposes": []}

        cur.execute("""SELECT scheme_id, document_name FROM scheme_documents
                       WHERE scheme_id = ANY(%s) ORDER BY document_id""", (scheme_ids,))
        for sid, name in cur.fetchall():
            details[sid]["documents"].append(name)

        cur.execute("""SELECT DISTINCT scheme_id, purpose FROM scheme_purposes
                       WHERE scheme_id = ANY(%s) AND purpose IS NOT NULL""", (scheme_ids,))
        for sid, purpose in cur.fetchall():
            details[sid]["purposes"].append(purpose)
    return details


OVERRIDES_CSV = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                             "data", "link_overrides.csv")

# A link is a DOCUMENT (not a page where you can apply) if it ends in .pdf/.doc/...,
# contains ".pdf", or sits in a typical download folder.
DOCUMENT = re.compile(r"\.(pdf|docx?|xlsx?|odt|pptx?|zip|rar)(?=$|[?#&/])|\.pdf|"
                      r"/(download|downloadfile|viewfile|writereaddata|uploaded|uploads|uploadfile|upload)/",
                      re.I)

_overrides = None


def is_document(url: str | None) -> bool:
    return bool(url) and bool(DOCUMENT.search(url))


def load_overrides() -> dict[str, dict]:
    """Hand-checked links from data/link_overrides.csv (scheme_id, apply_url, note)."""
    global _overrides
    if _overrides is None:
        _overrides = {}
        if os.path.exists(OVERRIDES_CSV):
            with open(OVERRIDES_CSV, encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    if row.get("scheme_id") and row.get("apply_url"):
                        _overrides[row["scheme_id"].strip()] = row
    return _overrides


def site_home(url: str | None) -> str | None:
    """https://pmkisan.gov.in/Documents/x.pdf -> https://pmkisan.gov.in/"""
    if not url:
        return None
    parts = urlparse(url)
    return f"{parts.scheme}://{parts.netloc}/" if parts.netloc else None


def scheme_links(d: dict) -> dict:
    """Which link to show for applying, plus guidelines and official site.

    Order:
      1. a hand-checked link in data/link_overrides.csv
      2. the dataset's apply link, if it is a real page (not a PDF)
      3. otherwise the scheme's myScheme page, which lists the steps to apply;
         the PDF is kept as "Guidelines" and its website as "Official site"
    """
    sid = d.get("scheme_id")
    url, page = d.get("official_application_url"), d.get("official_website")
    original, status = d.get("original_application_url"), d.get("link_status") or ""
    # after database/fix_links.py the PDF is kept in original_application_url
    guidelines = url if is_document(url) else         (original if original and (is_document(original) or status.startswith("pdf")) else None)
    portal = site_home(url) if is_document(url) else None

    if sid in load_overrides():
        o = load_overrides()[sid]
        return {"apply_link": o["apply_url"], "link_note": o.get("note") or "Checked by hand",
                "guidelines_link": guidelines, "portal_link": None}
    if url and not is_document(url):
        notes = {"pdf->site": "Official website of the scheme (the dataset only had a PDF)",
                 "broken->site": "Official website of the scheme (the old link no longer works)",
                 "pdf->myscheme": "The official website did not open, so this is the myScheme page",
                 "broken->myscheme": "The official link no longer works, so this is the myScheme page",
                 "missing->myscheme": "Official link missing in the data, so this is the myScheme page"}
        return {"apply_link": url, "link_note": notes.get(status, ""), "guidelines_link": guidelines,
                "portal_link": None}
    if page:
        note = ("Dataset link is a PDF, so this is the myScheme page with the steps to apply"
                if guidelines else "Official form link missing, this is the scheme's info page")
        return {"apply_link": page, "link_note": note, "guidelines_link": guidelines, "portal_link": portal}
    return {"apply_link": None, "link_note": "Link missing: search the scheme name on myscheme.gov.in",
            "guidelines_link": guidelines, "portal_link": portal}


def apply_link(d: dict) -> tuple[str | None, str]:
    """Short form: (link, note)."""
    links = scheme_links(d)
    return links["apply_link"], links["link_note"]


def get_schemes_for_citizen(citizen: CitizenProfile, conn=None,
                            statuses=("eligible", "maybe", "needs_review")) -> list[dict]:
    """Every matching scheme as one dict with status + details. Eligible first, then maybe."""
    own_conn = conn is None
    conn = conn or get_connection()
    try:
        matched = match_schemes(conn, citizen)
        picked = [(STATUSES[k], s) for k, schemes in matched.items() for s in schemes
                  if STATUSES[k] in statuses]
        details = load_details(conn, [s["scheme_id"] for _, s in picked])
    finally:
        if own_conn:
            conn.close()

    order = {s: i for i, s in enumerate(("eligible", "maybe", "needs_review", "not_eligible"))}
    results = []
    for status, s in picked:
        d = details.get(s["scheme_id"], {})
        links = scheme_links(d)
        how = classify(d.get("application_process"))
        if s["scheme_id"] in load_overrides():        # a hand-checked link wins
            how["online_url"] = links["apply_link"]
        where = where_to_submit(d.get("application_process"))
        results.append({
            "scheme_id": s["scheme_id"],
            "scheme_name": s["scheme_name"],
            "status": status,
            "missing": s.get("missing", []),
            "description": d.get("description"),
            "benefits": d.get("benefits"),
            "documents": d.get("documents", []),
            "purposes": sorted(d.get("purposes", [])),
            "application_process": d.get("application_process"),
            "official_website": d.get("official_website"),
            "official_application_url": d.get("official_application_url"),
            **links,
            **how,
            "where_submit": where,
            "next_steps": next_step(how["apply_mode"], how["apply_via_csc"], how["online_url"],
                                    links["apply_link"], links["guidelines_link"], where,
                                    links["portal_link"]),
        })
    results.sort(key=lambda r: order[r["status"]])
    return results


def short(text, n=160):
    text = " ".join(html.unescape(text or "-").split())   # "&amp;" -> "&"
    return text if len(text) <= n else text[:n - 3] + "..."


def print_scheme(r: dict, number: int, uploaded: set[str] | None = None) -> None:
    """Print one scheme. If uploaded document types are given, show [x] / [ ] per document."""
    print(f"\n  {number}. {r['scheme_name']}   [{r['status'].upper()}]")
    if r["missing"]:
        print(f"     Still need     : {', '.join(r['missing'])}")
    print(f"     Benefits       : {short(r['benefits'])}")
    if uploaded is not None and r["documents"]:
        from documents.document_profile import document_checklist
        checklist = document_checklist(r["documents"], uploaded)
        print(f"     Documents      : {sum(done for done, _ in checklist)} of {len(checklist)} ready")
        for done, name in checklist[:8]:
            print(f"        [{'x' if done else ' '}] {short(name, 90)}")
        if len(checklist) > 8:
            print(f"        ... and {len(checklist) - 8} more")
    else:
        docs = r["documents"][:5]
        more = f" (+{len(r['documents']) - 5} more)" if len(r["documents"]) > 5 else ""
        print(f"     Documents      : {short('; '.join(docs), 200) if docs else 'not listed'}{more}")
    print(f"     Apply here     : {r['apply_link'] or '-'}")
    if r.get("portal_link"):
        print(f"     Official site  : {r['portal_link']}")
    if r.get("guidelines_link"):
        print(f"     Guidelines(PDF): {r['guidelines_link']}")
    if r["link_note"]:
        print(f"     Note           : {r['link_note']}")
    if r.get("apply_mode"):
        print(f"     How to apply   : {r['apply_mode'].upper()}")
        for line in r["next_steps"]:
            print(f"       -> {short(line, 260)}")


if __name__ == "__main__":
    sys.stdout.reconfigure(errors="replace")
    citizen = CitizenProfile(age=23, area="rural", state="Bihar", annual_income=100000,
                             needs=["employment"])
    results = get_schemes_for_citizen(citizen)
    counts = {s: sum(r["status"] == s for r in results) for s in ("eligible", "maybe", "needs_review")}
    print("Citizen: age 23, rural, Bihar, income 1 lakh, needs employment")
    print("Found:", counts)
    for i, r in enumerate(results[:3], start=1):
        print_scheme(r, i)
