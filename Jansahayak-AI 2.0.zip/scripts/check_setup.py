"""Read-only setup check for the dashboard. Changes nothing.

Run from the JanSahayak-AI folder:
    python scripts/check_setup.py
"""
import importlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

REQUIRED_MODULES = ["fastapi", "uvicorn", "httpx", "psycopg2", "pydantic", "dotenv"]
PROJECT_MODULES = ["schemas.citizen_schema", "schemas.eligibility_schema", "engine.db_rules",
                   "engine.eligibility_engine", "engine.scheme_matcher", "services.scheme_matcher",
                   "services.apply_mode", "agent.rule_based_extractor"]


def main() -> int:
    ok = True
    print("JanSahayak-AI dashboard setup check (read-only)\n")
    for name in REQUIRED_MODULES:
        try:
            importlib.import_module(name)
            print(f"  [ok]   library {name}")
        except ImportError:
            ok = False
            print(f"  [FAIL] library {name} missing: pip install -r requirements-dashboard.txt")
    for name in PROJECT_MODULES:
        try:
            importlib.import_module(name)
            print(f"  [ok]   project module {name}")
        except Exception as exc:
            ok = False
            print(f"  [FAIL] project module {name}: {exc} (is the dashboard folder inside the JanSahayak-AI folder?)")
    if not ok:
        return 1

    from dashboard.config import settings
    from dashboard.db import TABLES, DatabaseUnavailable, fetch_value, get_schema

    print(f"\nDatabase {settings.db_user}@{settings.db_host}:{settings.db_port}/{settings.db_name}")
    try:
        print("  connected:", fetch_value("SELECT version()").split(",")[0])
    except DatabaseUnavailable as exc:
        print("  [FAIL] cannot connect:", exc)
        return 1
    schema = get_schema()
    for t in TABLES:
        if schema.has(t):
            print(f"  [ok]   {t:18} {fetch_value(f'SELECT count(*) FROM {t}'):>6} rows")
        else:
            ok = False
            print(f"  [FAIL] {t} table missing: run database/import_schemes.py")
    print("  [ok]   apply_mode column present" if schema.has("schemes", "apply_mode")
          else "  [info] apply_mode column missing (optional): python database/add_apply_mode.py")
    print(f"  read-only dashboard connections: {settings.db_read_only}")
    print(f"\nGroq: {'GROQ_API_KEY set' if settings.groq_api_key else 'GROQ_API_KEY not set (assistant shows database matches only)'}, model {settings.groq_model}")
    print(f"Admin login: {'configured' if settings.admin_configured else 'NOT configured: run python scripts/hash_admin_password.py'}")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
