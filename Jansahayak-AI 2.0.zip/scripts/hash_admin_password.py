"""Create the admin password hash and a secret key for .env.

    python scripts/hash_admin_password.py

Prints lines to paste into .env. The plain password is never stored.
"""
import getpass
import secrets
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dashboard.auth import hash_password  # noqa: E402


def main() -> None:
    username = input("Admin username [admin]: ").strip() or "admin"
    while True:
        pw = getpass.getpass("Admin password (min 10 characters): ")
        if len(pw) < 10:
            print("Password too short, try again.")
            continue
        if pw != getpass.getpass("Repeat password: "):
            print("Passwords do not match, try again.")
            continue
        break
    print("\nAdd these lines to your .env file:\n")
    print(f"ADMIN_USERNAME={username}")
    # '$' is escaped so python-dotenv does not try to expand it as a variable.
    print(f"ADMIN_PASSWORD_HASH='{hash_password(pw)}'")
    print(f"DASHBOARD_SECRET_KEY={secrets.token_urlsafe(48)}")


if __name__ == "__main__":
    main()
