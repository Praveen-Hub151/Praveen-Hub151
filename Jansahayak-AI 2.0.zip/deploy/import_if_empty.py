"""Load data/Schemes.csv into the database if the schemes table is missing or empty.

Render's free plan has no shell, so the container does the first import itself
(deploy/start.sh). Later starts skip it. To reload on purpose, run
database/import_schemes.py against the External Database URL from your computer.
"""
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import psycopg2  # noqa: E402

from engine.db_rules import get_connection  # noqa: E402


def scheme_count() -> int:
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT to_regclass('public.schemes') IS NOT NULL")
            if not cur.fetchone()[0]:
                return 0
            cur.execute("SELECT count(*) FROM schemes")
            return cur.fetchone()[0]
    finally:
        conn.close()


def main() -> None:
    try:
        count = scheme_count()
    except psycopg2.OperationalError as exc:
        print(f"Database not reachable, skipping the import: {exc}".strip())
        return
    if count:
        print(f"Database already has {count} schemes, skipping the import.")
        return
    print("Empty database: importing data/Schemes.csv ...")
    for script in ("database/import_schemes.py", "database/add_apply_mode.py"):
        subprocess.run([sys.executable, str(ROOT / script)], cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
