#!/bin/sh
# Container start: load the scheme data the first time (empty database), then run the dashboard.
set -e
if [ "${AUTO_IMPORT:-true}" = "true" ]; then
  python deploy/import_if_empty.py
fi
exec python run_dashboard.py --host 0.0.0.0 --port "${PORT:-10000}"
